import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { useEvaluation } from './EvaluationContext';
import { 
  ChronoDocument, 
  ChronoDocumentType, 
  ChronoDocumentStatus, 
  ChronoFileType, 
  ChronoFolderStats 
} from '../types/chrono';
import { INITIAL_CHRONO_TEMPLATES } from '../data/chronoSampleData';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';

interface GenerateAiParams {
  standardNumber: number;
  indicatorId?: string;
  indicatorCode?: string;
  indicatorTitleKh?: string;
  activitiesKh?: string[];
  documentType: ChronoDocumentType;
  customInstructions?: string;
}

interface EnhanceTextParams {
  rawText: string;
  standardNumber?: number;
  indicatorCode?: string;
  documentType?: string;
}

interface ChronoContextType {
  documents: ChronoDocument[];
  activeStandard: number | null;
  setActiveStandard: (stdNum: number | null) => void;
  activeIndicatorId: string | null;
  setActiveIndicatorId: (indId: string | null) => void;
  filterDocType: string;
  setFilterDocType: (type: string) => void;
  filterStatus: string;
  setFilterStatus: (status: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isLoading: boolean;
  folderStats: Record<number, ChronoFolderStats>;
  addDocument: (docData: Omit<ChronoDocument, 'id' | 'createdAt' | 'updatedAt'>) => Promise<ChronoDocument>;
  updateDocument: (id: string, updates: Partial<ChronoDocument>) => Promise<void>;
  deleteDocument: (id: string) => Promise<void>;
  uploadSignedCopy: (id: string, data: { fileBase64: string; fileName: string; signedByName?: string; signedRole?: string }) => Promise<void>;
  generateAiDocument: (params: GenerateAiParams) => Promise<ChronoDocument>;
  enhanceTextWithAi: (params: EnhanceTextParams) => Promise<{ enhancedMarkdown: string; titleKh: string; improvementsMade?: string[] }>;
  importFileAsDocument: (file: File, meta: { standardNumber: number; indicatorId: string; titleKh?: string; documentType?: ChronoDocumentType }) => Promise<ChronoDocument>;
  createFromPastedTextOrCode: (data: { titleKh: string; rawContent: string; standardNumber: number; indicatorId: string; documentType: ChronoDocumentType; formatWithAi?: boolean }) => Promise<ChronoDocument>;
  getDocumentsForIndicator: (indicatorId: string) => ChronoDocument[];
  getDocumentsForStandard: (standardNumber: number) => ChronoDocument[];
}

const ChronoContext = createContext<ChronoContextType | undefined>(undefined);

export const ChronoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, userProfile } = useAuth();
  const { academicYear } = useEvaluation();

  const [documents, setDocuments] = useState<ChronoDocument[]>([]);
  const [activeStandard, setActiveStandard] = useState<number | null>(null);
  const [activeIndicatorId, setActiveIndicatorId] = useState<string | null>(null);
  const [filterDocType, setFilterDocType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const localKey = useMemo(() => {
    return currentUser ? `chrono_docs_${currentUser.uid}` : `chrono_docs_guest`;
  }, [currentUser]);

  // Load from local storage initially
  useEffect(() => {
    try {
      const cached = localStorage.getItem(localKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setDocuments(parsed);
          setIsLoading(false);
          return;
        }
      }
      
      // Initialize with sample templates if empty
      const initialDocs: ChronoDocument[] = INITIAL_CHRONO_TEMPLATES.map((tmpl, idx) => ({
        ...tmpl,
        id: `chrono_init_${idx + 1}_${Date.now()}`,
        schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
        userId: currentUser?.uid || 'guest',
        createdAt: new Date(Date.now() - (idx * 86400000)).toISOString(),
        updatedAt: new Date(Date.now() - (idx * 86400000)).toISOString()
      }));

      setDocuments(initialDocs);
      localStorage.setItem(localKey, JSON.stringify(initialDocs));
      setIsLoading(false);
    } catch (e) {
      console.error('Error loading initial chrono docs:', e);
      setIsLoading(false);
    }
  }, [localKey]);

  // Real-time Firestore sync
  useEffect(() => {
    if (!currentUser) return;

    try {
      const chronoCol = collection(db, 'school_chrono_documents');
      const q = query(chronoCol, where('userId', '==', currentUser.uid));

      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const remoteDocs: ChronoDocument[] = [];
          snapshot.forEach((docSnap) => {
            remoteDocs.push(docSnap.data() as ChronoDocument);
          });
          
          // Sort by creation or update date descending
          remoteDocs.sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());
          setDocuments(remoteDocs);
          localStorage.setItem(localKey, JSON.stringify(remoteDocs));
        }
        setIsLoading(false);
      }, (err) => {
        console.warn('Chrono Firestore listener fallback to local storage:', err);
        setIsLoading(false);
      });

      return () => unsubscribe();
    } catch (err) {
      console.error('Failed to attach chrono Firestore listener:', err);
      setIsLoading(false);
    }
  }, [currentUser, localKey]);

  // Persist to local & Firestore
  const persistDocs = async (newDocs: ChronoDocument[]) => {
    setDocuments(newDocs);
    localStorage.setItem(localKey, JSON.stringify(newDocs));
  };

  // Add Document
  const addDocument = async (docData: Omit<ChronoDocument, 'id' | 'createdAt' | 'updatedAt'>): Promise<ChronoDocument> => {
    const now = new Date().toISOString();
    const newDocId = `chrono_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    
    const fullDoc: ChronoDocument = {
      ...docData,
      id: newDocId,
      schoolId: docData.schoolId || userProfile?.schoolName || 'សាលារៀនគំរូ',
      userId: currentUser?.uid || 'guest',
      createdAt: now,
      updatedAt: now,
      authorName: docData.authorName || userProfile?.displayName || 'អ្នករៀបចំឯកសារ'
    };

    const nextDocs = [fullDoc, ...documents];
    await persistDocs(nextDocs);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'school_chrono_documents', newDocId), fullDoc, { merge: true });
      } catch (err) {
        console.error('Error saving chrono doc to Firestore:', err);
      }
    }

    return fullDoc;
  };

  // Update Document
  const updateDocument = async (id: string, updates: Partial<ChronoDocument>): Promise<void> => {
    const now = new Date().toISOString();
    const nextDocs = documents.map(d => {
      if (d.id === id) {
        return {
          ...d,
          ...updates,
          updatedAt: now
        };
      }
      return d;
    });

    await persistDocs(nextDocs);

    if (currentUser) {
      try {
        await setDoc(doc(db, 'school_chrono_documents', id), {
          ...updates,
          updatedAt: now
        }, { merge: true });
      } catch (err) {
        console.error('Error updating chrono doc in Firestore:', err);
      }
    }
  };

  // Delete Document
  const deleteDocument = async (id: string): Promise<void> => {
    const nextDocs = documents.filter(d => d.id !== id);
    await persistDocs(nextDocs);

    if (currentUser) {
      try {
        await deleteDoc(doc(db, 'school_chrono_documents', id));
      } catch (err) {
        console.error('Error deleting chrono doc from Firestore:', err);
      }
    }
  };

  // Upload Signed Document Scan / Photo
  const uploadSignedCopy = async (id: string, data: { fileBase64: string; fileName: string; signedByName?: string; signedRole?: string }) => {
    const now = new Date().toISOString();
    await updateDocument(id, {
      signedFileBase64: data.fileBase64,
      signedFileName: data.fileName,
      signedByName: data.signedByName || userProfile?.displayName || 'នាយកសាលា',
      signedRole: data.signedRole || 'នាយកសាលា',
      signedAt: now,
      status: 'signed_and_filed'
    });
  };

  // AI Document Generator (Calling Server-side API with Gemini 3.7 Flash)
  const generateAiDocument = async (params: GenerateAiParams): Promise<ChronoDocument> => {
    // Find indicator info if provided
    const indicator = params.indicatorId 
      ? ALL_INDICATORS.find(ind => ind.id === params.indicatorId)
      : ALL_INDICATORS.find(ind => ind.standardNumber === params.standardNumber && (ind.code === params.indicatorCode));

    const standardMeta = STANDARDS_METADATA.find(s => s.number === params.standardNumber);

    const indCode = indicator?.code || params.indicatorCode || '១.១';
    const indTitle = indicator?.expectedResultKh || params.indicatorTitleKh || 'សូចនាករស្តង់ដាសាលារៀនគំរូ';
    const activities = indicator?.activitiesKh || params.activitiesKh || [];
    const secTitle = indicator?.sectionTitleKh || `ផ្នែកទី ${params.standardNumber}`;

    try {
      const response = await fetch('/api/ai/generate-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          standardNumber: params.standardNumber,
          standardTitleKh: standardMeta?.titleKh || `ស្តង់ដាទី${params.standardNumber}`,
          indicatorCode: indCode,
          indicatorTitleKh: indTitle,
          activitiesKh: activities,
          documentType: params.documentType,
          schoolName: userProfile?.schoolName || 'សាលារៀនគំរូ',
          province: userProfile?.province || 'រាជធានី-ខេត្ត',
          district: userProfile?.district || 'ស្រុក-ខណ្ឌ',
          academicYear: academicYear || '២០២៣-២០២៤',
          customInstructions: params.customInstructions
        })
      });

      if (!response.ok) {
        throw new Error('API server returned error during AI generation');
      }

      const resData = await response.json();
      const generated = resData.document;

      // Create ChronoDocument
      return await addDocument({
        schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
        userId: currentUser?.uid || 'guest',
        standardNumber: params.standardNumber,
        indicatorId: indicator?.id || `std${params.standardNumber}_1_1`,
        indicatorCode: indCode,
        sectionNumber: indicator?.sectionNumber || 1,
        sectionTitleKh: secTitle,
        titleKh: generated.titleKh || `ឯកសារភស្តុតាង ${indCode}`,
        documentNumber: generated.documentNumber || `លេខ.../${academicYear || '២៤'} របក.សរ`,
        dateKh: generated.dateKh || new Date().toLocaleDateString('km-KH'),
        documentType: params.documentType,
        status: 'ready_for_signature',
        summaryKh: generated.summaryKh || 'ឯកសារគំរូផ្លូវការបង្កើតដោយជំនួយការ AI',
        contentMarkdown: generated.contentMarkdown || '',
        fileType: 'text',
        authorName: userProfile?.displayName || 'នាយកសាលា',
        academicYear: academicYear || '2023-2024',
        aiGenerated: true
      });
    } catch (err: any) {
      console.warn('Server AI generation failed, falling back to rich local template:', err);
      // High-quality local fallback template generator
      const fallbackTitle = `របាយការណ៍សកម្មភាពអនុវត្ត ${indTitle}`;
      const fallbackMarkdown = `### ព្រះរាជាណាចក្រកម្ពុជា
**ជាតិ សាសនា ព្រះមហាក្សត្រ**
***

**ក្រសួងអប់រំ យុវជន និងកីឡា**  
**មន្ទីរអប់រំ យុវជន និងកីឡា ខេត្ត/រាជធានី ${userProfile?.province || '...' }**  
**សាលារៀន៖ ${userProfile?.schoolName || 'សាលារៀនគំរូ'}**

---
#### ${fallbackTitle}
**ស្តង់ដាទី ${params.standardNumber} - សូចនាករ ${indCode}**  
**ឆ្នាំសិក្សា ${academicYear || '២០២៣-២០២៤'}**

---

### I. សេចក្តីផ្តើម និងគោលបំណង
អនុវត្តតាមការណែនាំស្តីពីស្តង់ដាសាលារៀនគំរូ សាលារៀនបានរៀបចំផែនការ និងអនុវត្តសកម្មភាពដើម្បីសម្រេចបាននូវលទ្ធផលរំពឹងទុក៖ "${indTitle}"។

### II. សកម្មភាពដែលបានអនុវត្តជាក់ស្តែង
${activities.map((act, i) => `${i + 1}. **${act}** ៖ បានដំណើរការយ៉ាងសកម្មជាមួយលោកគ្រូ អ្នកគ្រូ សិស្សានុសិស្ស និងសហគមន៍។`).join('\n')}

### III. លទ្ធផលសម្រេចបាន
- សម្រេចបាននូវសូចនាករគោលដៅចំនួន ១០០% ស្របតាមកាលវិភាគដែលបានគ្រោងទុក។
- សិស្សានុសិស្ស និងលោកគ្រូ-អ្នកគ្រូបានចូលរួមយ៉ាងសកម្ម។

### IV. បញ្ហាប្រឈម និងសំណូមពរ
- បន្តពង្រឹងការតាមដាន និងការកៀរគរការចូលរួមពីមាតាបិតាសិស្សបន្ថែមទៀត។`;

      return await addDocument({
        schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
        userId: currentUser?.uid || 'guest',
        standardNumber: params.standardNumber,
        indicatorId: indicator?.id || `std${params.standardNumber}_1_1`,
        indicatorCode: indCode,
        sectionNumber: indicator?.sectionNumber || 1,
        sectionTitleKh: secTitle,
        titleKh: fallbackTitle,
        documentNumber: `លេខ.../${academicYear || '២៤'} របក`,
        dateKh: new Date().toLocaleDateString('km-KH'),
        documentType: params.documentType,
        status: 'ready_for_signature',
        summaryKh: `ឯកសារភស្តុតាងសម្រាប់សូចនាករ ${indCode}`,
        contentMarkdown: fallbackMarkdown,
        fileType: 'text',
        secondApproverRole: 'ប្រធានគណៈកម្មការ គ.គ.ស',
        secondApproverName: '',
        approverRole: 'នាយកសាលារៀន',
        approverName: userProfile?.displayName || '',
        reporterRole: 'អ្នកទទួលបន្ទុកស្តង់ដា',
        reporterName: 'Tong Un',
        authorName: 'Tong Un',
        academicYear: academicYear || '2023-2024',
        aiGenerated: true
      });
    }
  };

  // AI Enhance Text / Document
  const enhanceTextWithAi = async (params: EnhanceTextParams) => {
    try {
      const response = await fetch('/api/ai/enhance-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText: params.rawText,
          standardNumber: params.standardNumber || 1,
          indicatorCode: params.indicatorCode || '១.១',
          documentType: params.documentType || 'របាយការណ៍',
          schoolName: userProfile?.schoolName || 'សាលារៀនគំរូ'
        })
      });

      if (!response.ok) {
        throw new Error('API server returned error');
      }

      const resData = await response.json();
      return {
        enhancedMarkdown: resData.result.enhancedMarkdown,
        titleKh: resData.result.titleKh || 'ឯកសារដែលបានកែលម្អ',
        improvementsMade: resData.result.improvementsMade
      };
    } catch (err) {
      console.warn('AI enhancement fallback:', err);
      // Simple structured fallback formatting
      const lines = params.rawText.split('\n').filter(l => l.trim().length > 0);
      const title = lines[0] || 'របាយការណ៍សកម្មភាព';
      const body = lines.slice(1).join('\n\n');
      return {
        enhancedMarkdown: `### ព្រះរាជាណាចក្រកម្ពុជា\n**ជាតិ សាសនា ព្រះមហាក្សត្រ**\n***\n\n#### ${title}\n\n${body}`,
        titleKh: title,
        improvementsMade: ['រៀបចំក្បាលលិខិតរដ្ឋបាលជាតិត្រឹមត្រូវ']
      };
    }
  };

  // File Import (PDF, Image, Word, Excel, CSV)
  const importFileAsDocument = async (
    file: File, 
    meta: { standardNumber: number; indicatorId: string; titleKh?: string; documentType?: ChronoDocumentType }
  ): Promise<ChronoDocument> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const isImage = file.type.startsWith('image/');
      const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
      const isDocx = file.name.endsWith('.docx') || file.name.endsWith('.doc');
      const isXlsx = file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv');

      let fileType: ChronoFileType = 'text';
      if (isPdf) fileType = 'pdf';
      else if (isImage) fileType = 'image';
      else if (isDocx) fileType = 'docx';
      else if (isXlsx) fileType = 'xlsx';

      const indicator = ALL_INDICATORS.find(ind => ind.id === meta.indicatorId);

      reader.onload = async () => {
        try {
          const base64Data = reader.result as string;
          const cleanTitle = meta.titleKh || file.name.replace(/\.[^/.]+$/, "");

          let content = `**ឯកសារភ្ជាប់ផ្លូវការ៖** \`${file.name}\` (${(file.size / 1024).toFixed(1)} KB)\n\nប្រភេទឯកសារ៖ ${fileType.toUpperCase()}`;
          if (file.type.startsWith('text/')) {
            content = base64Data; // text files
          }

          const newDoc = await addDocument({
            schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
            userId: currentUser?.uid || 'guest',
            standardNumber: meta.standardNumber,
            indicatorId: meta.indicatorId,
            indicatorCode: indicator?.code || '១.១',
            sectionNumber: indicator?.sectionNumber || 1,
            sectionTitleKh: indicator?.sectionTitleKh || `ស្តង់ដាទី${meta.standardNumber}`,
            titleKh: cleanTitle,
            documentNumber: `ឯកសារភ្ជាប់-${Date.now().toString().slice(-4)}`,
            dateKh: new Date().toLocaleDateString('km-KH'),
            documentType: meta.documentType || (isImage ? 'evidence_photo' : 'other'),
            status: 'signed_and_filed',
            summaryKh: `ឯកសារ ${file.name} ត្រូវបាន Import ចូលទៅក្នុងក្រូណូទី ${meta.standardNumber}`,
            contentMarkdown: content,
            fileType,
            fileName: file.name,
            fileSize: file.size,
            fileBase64: base64Data,
            authorName: userProfile?.displayName || 'អ្នកបញ្ចូលឯកសារ',
            academicYear: academicYear || '2023-2024'
          });

          resolve(newDoc);
        } catch (e) {
          reject(e);
        }
      };

      reader.onerror = (e) => reject(e);

      if (file.type.startsWith('text/')) {
        reader.readAsText(file);
      } else {
        reader.readAsDataURL(file);
      }
    });
  };

  // Paste Text or Code
  const createFromPastedTextOrCode = async (data: {
    titleKh: string;
    rawContent: string;
    standardNumber: number;
    indicatorId: string;
    documentType: ChronoDocumentType;
    formatWithAi?: boolean;
  }): Promise<ChronoDocument> => {
    const indicator = ALL_INDICATORS.find(ind => ind.id === data.indicatorId);

    let finalMarkdown = data.rawContent;
    let finalTitle = data.titleKh;
    let aiPolished = false;

    if (data.formatWithAi) {
      try {
        const enhanced = await enhanceTextWithAi({
          rawText: data.rawContent,
          standardNumber: data.standardNumber,
          indicatorCode: indicator?.code,
          documentType: data.documentType
        });
        finalMarkdown = enhanced.enhancedMarkdown;
        if (!finalTitle || finalTitle.trim() === '') {
          finalTitle = enhanced.titleKh;
        }
        aiPolished = true;
      } catch (err) {
        console.warn('AI enhancement skipped:', err);
      }
    }

    return await addDocument({
      schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
      userId: currentUser?.uid || 'guest',
      standardNumber: data.standardNumber,
      indicatorId: data.indicatorId,
      indicatorCode: indicator?.code || '១.១',
      sectionNumber: indicator?.sectionNumber || 1,
      sectionTitleKh: indicator?.sectionTitleKh || `ស្តង់ដាទី${data.standardNumber}`,
      titleKh: finalTitle || 'ឯកសារបិទភ្ជាប់ (Pasted Document)',
      documentNumber: `លេខ.../${academicYear || '២៤'} របក`,
      dateKh: new Date().toLocaleDateString('km-KH'),
      documentType: data.documentType,
      status: 'ready_for_signature',
      summaryKh: `ឯកសារបង្កើតចេញពីការបិទភ្ជាប់អត្ថបទ/ទិន្នន័យ (Pasted Text)`,
      contentMarkdown: finalMarkdown,
      fileType: 'text',
      authorName: userProfile?.displayName || 'អ្នករៀបចំ',
      academicYear: academicYear || '2023-2024',
      aiEnhanced: aiPolished
    });
  };

  // Helper getters
  const getDocumentsForIndicator = useCallback((indicatorId: string) => {
    return documents.filter(d => d.indicatorId === indicatorId);
  }, [documents]);

  const getDocumentsForStandard = useCallback((standardNumber: number) => {
    return documents.filter(d => d.standardNumber === standardNumber);
  }, [documents]);

  // Compute folder statistics for all 5 Standards
  const folderStats = useMemo(() => {
    const stats: Record<number, ChronoFolderStats> = {};
    for (let s = 1; s <= 5; s++) {
      const stdDocs = documents.filter(d => d.standardNumber === s);
      const signed = stdDocs.filter(d => d.status === 'signed_and_filed' || d.status === 'verified').length;
      const draft = stdDocs.filter(d => d.status === 'draft' || d.status === 'ready_for_signature').length;
      const verified = stdDocs.filter(d => d.status === 'verified').length;

      stats[s] = {
        standardNumber: s,
        totalDocuments: stdDocs.length,
        signedDocuments: signed,
        draftDocuments: draft,
        verifiedDocuments: verified,
        hasPhysicalHardCopyReady: signed > 0
      };
    }
    return stats;
  }, [documents]);

  return (
    <ChronoContext.Provider value={{
      documents,
      activeStandard,
      setActiveStandard,
      activeIndicatorId,
      setActiveIndicatorId,
      filterDocType,
      setFilterDocType,
      filterStatus,
      setFilterStatus,
      searchQuery,
      setSearchQuery,
      isLoading,
      folderStats,
      addDocument,
      updateDocument,
      deleteDocument,
      uploadSignedCopy,
      generateAiDocument,
      enhanceTextWithAi,
      importFileAsDocument,
      createFromPastedTextOrCode,
      getDocumentsForIndicator,
      getDocumentsForStandard
    }}>
      {children}
    </ChronoContext.Provider>
  );
};

export const useChrono = () => {
  const context = useContext(ChronoContext);
  if (!context) {
    throw new Error('useChrono must be used within a ChronoProvider');
  }
  return context;
};
