import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  auth, 
  db, 
  googleProvider,
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  firebaseSignOut, 
  sendPasswordResetEmail,
  updateProfile,
  signInAnonymously,
  onAuthStateChanged,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
  User
} from '../lib/firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  clearError: () => void;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  registerWithEmail: (email: string, pass: string, profileData: Partial<UserProfile>) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginAsGuest: () => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateUserProfileData: (updatedFields: Partial<UserProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  // Sync user profile from Firestore or local fallback
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const userSnap = await getDoc(userDocRef);

          if (userSnap.exists()) {
            setUserProfile(userSnap.data() as UserProfile);
          } else {
            // Create default profile for newly authenticated user
            const defaultProfile: UserProfile = {
              uid: user.uid,
              email: user.email || `guest_${user.uid.slice(0, 5)}@moeys.gov.kh`,
              displayName: user.displayName || (user.isAnonymous ? 'អ្នកប្រើប្រាស់សាកល្បង (Guest)' : 'មន្ត្រីអប់រំ / នាយកសាលា'),
              photoURL: user.photoURL || '',
              role: user.isAnonymous ? 'evaluator' : 'director',
              schoolName: 'សាលាបឋមសិក្សា ហ៊ុន សែន មិត្តភាព',
              schoolCode: 'KH-' + Math.floor(100000 + Math.random() * 900000),
              province: 'រាជធានីភ្នំពេញ',
              district: 'ខណ្ឌដូនពេញ',
              phoneNumber: '012 345 678',
              bio: 'ការលើកកម្ពស់គុណភាពអប់រំ តាមរយៈស្តង់ដាសាលារៀនគំរូទាំង៥',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              isAnonymous: user.isAnonymous
            };

            await setDoc(userDocRef, {
              ...defaultProfile,
              serverCreatedAt: serverTimestamp()
            });

            setUserProfile(defaultProfile);
          }
        } catch (err: any) {
          console.error('Error fetching/creating user profile from Firestore:', err);
          // Local fallback in case of Firestore network delay
          const fallbackProfile: UserProfile = {
            uid: user.uid,
            email: user.email || 'user@moeys.gov.kh',
            displayName: user.displayName || 'អ្នកប្រើប្រាស់',
            photoURL: user.photoURL || '',
            role: 'director',
            schoolName: 'សាលាបឋមសិក្សា ហ៊ុន សែន',
            province: 'រាជធានីភ្នំពេញ',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            isAnonymous: user.isAnonymous
          };
          setUserProfile(fallbackProfile);
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithEmail = async (email: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (err: any) {
      console.error('Login error:', err);
      let msg = err.message;
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវទេ (Invalid email or password)';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'ទម្រង់អ៊ីមែលមិនត្រឹមត្រូវ (Invalid email address)';
      }
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const registerWithEmail = async (email: string, pass: string, profileData: Partial<UserProfile>) => {
    setError(null);
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      if (cred.user) {
        if (profileData.displayName) {
          await updateProfile(cred.user, { displayName: profileData.displayName });
        }

        const newProfile: UserProfile = {
          uid: cred.user.uid,
          email: email,
          displayName: profileData.displayName || 'មន្ត្រីអប់រំ / នាយកសាលា',
          photoURL: profileData.photoURL || '',
          role: (profileData.role as UserRole) || 'director',
          schoolName: profileData.schoolName || 'សាលាបឋមសិក្សាគំរូ',
          schoolCode: profileData.schoolCode || 'KH-' + Math.floor(100000 + Math.random() * 900000),
          province: profileData.province || 'រាជធានីភ្នំពេញ',
          district: profileData.district || 'ខណ្ឌដូនពេញ',
          phoneNumber: profileData.phoneNumber || '',
          bio: profileData.bio || 'ចូលរួមលើកកម្ពស់ស្តង់ដាសាលារៀនគំរូ',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          isAnonymous: false
        };

        const userDocRef = doc(db, 'users', cred.user.uid);
        await setDoc(userDocRef, {
          ...newProfile,
          serverCreatedAt: serverTimestamp()
        });

        setUserProfile(newProfile);
      }
    } catch (err: any) {
      console.error('Registration error:', err);
      let msg = err.message;
      if (err.code === 'auth/email-already-in-use') {
        msg = 'អ៊ីមែលនេះមានគណនីរួចហើយ សូមចូលប្រើ (Email is already registered)';
      } else if (err.code === 'auth/weak-password') {
        msg = 'ពាក្យសម្ងាត់ត្រូវមានយ៉ាងតិច ៦ តួអក្សរ (Password should be at least 6 characters)';
      }
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        const userDocRef = doc(db, 'users', res.user.uid);
        const snap = await getDoc(userDocRef);
        if (!snap.exists()) {
          const profile: UserProfile = {
            uid: res.user.uid,
            email: res.user.email || '',
            displayName: res.user.displayName || 'មន្ត្រីអប់រំ / លោកគ្រូ',
            photoURL: res.user.photoURL || '',
            role: 'director',
            schoolName: 'សាលាបឋមសិក្សា ហ៊ុន សែន មិត្តភាព',
            schoolCode: 'KH-' + Math.floor(100000 + Math.random() * 900000),
            province: 'រាជធានីភ្នំពេញ',
            district: 'ខណ្ឌដូនពេញ',
            phoneNumber: '012 345 678',
            bio: 'សមាជិកគ្រប់គ្រងទិន្នន័យស្តង់ដាសាលារៀន',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            isAnonymous: false
          };
          await setDoc(userDocRef, {
            ...profile,
            serverCreatedAt: serverTimestamp()
          });
          setUserProfile(profile);
        }
      }
    } catch (err: any) {
      console.error('Google Sign In error:', err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'បរាជ័យក្នុងការចូលដោយ Google (Google Sign-In failed)');
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginAsGuest = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInAnonymously(auth);
    } catch (err: any) {
      console.error('Guest login error:', err);
      setError(err.message || 'បរាជ័យក្នុងការចូលប្រើសាកល្បង (Guest login failed)');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
      setUserProfile(null);
    } catch (err: any) {
      console.error('Logout error:', err);
      setError(err.message);
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      console.error('Password reset error:', err);
      setError(err.message || 'មិនអាចផ្ញើតំណភ្ជាប់ប្តូរពាក្យសម្ងាត់បានទេ');
      throw err;
    }
  };

  const updateUserProfileData = async (updatedFields: Partial<UserProfile>) => {
    if (!currentUser || !userProfile) return;
    setError(null);
    try {
      const updated: UserProfile = {
        ...userProfile,
        ...updatedFields,
        updatedAt: new Date().toISOString()
      };

      const userDocRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userDocRef, {
        ...updatedFields,
        updatedAt: new Date().toISOString(),
        serverUpdatedAt: serverTimestamp()
      });

      setUserProfile(updated);
    } catch (err: any) {
      console.error('Error updating user profile in Firestore:', err);
      // Still update local state so user experience is smooth
      setUserProfile(prev => prev ? { ...prev, ...updatedFields } : null);
      setError(err.message);
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        error,
        clearError,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        loginAsGuest,
        logout,
        resetPassword,
        updateUserProfileData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
