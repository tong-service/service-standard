import React, { createContext, useContext, useEffect, useState, useMemo, ReactNode } from 'react';
import { db, doc, getDoc, setDoc, onSnapshot, serverTimestamp } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { 
  ALL_INDICATORS, 
  TOTAL_ACTIVITIES_COUNT, 
  STANDARDS_METADATA, 
  calculateSchoolPerformanceLevel 
} from '../data/standardsData';
import { 
  IndicatorScore, 
  SchoolEvaluationRecord, 
  StandardSummary, 
  ScoreStatus 
} from '../types';

interface EvaluationContextType {
  evaluationRecord: SchoolEvaluationRecord | null;
  academicYear: string;
  setAcademicYear: (year: string) => void;
  evaluationTerm: 'semester_1' | 'semester_2' | 'annual';
  setEvaluationTerm: (term: 'semester_1' | 'semester_2' | 'annual') => void;
  saveScore: (indicatorId: string, scoreData: Partial<IndicatorScore>, options?: { immediate?: boolean }) => Promise<void>;
  toggleActivityCheck: (indicatorId: string, activityIndex: number) => Promise<void>;
  bulkUpdateScores: (newScores: Record<string, IndicatorScore>) => Promise<void>;
  resetAllScores: () => Promise<void>;
  populateSampleData: () => Promise<void>;
  standardsSummaries: StandardSummary[];
  overallPercentage: number;
  overallAverage: number;
  totalCompletedActivities: number;
  totalActivitiesCount: number;
  performanceLevel: ReturnType<typeof calculateSchoolPerformanceLevel>;
  syncStatus: 'synced' | 'saving' | 'error' | 'offline';
  autoSaveStatus: 'idle' | 'saving' | 'saved' | 'error';
  lastSavedAt: string | null;
  autoSaveEnabled: boolean;
  setAutoSaveEnabled: (enabled: boolean) => void;
  selectedStandard: number | null;
  setSelectedStandard: (stdNumber: number | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  statusFilter: 'all' | 'achieved' | 'in_progress' | 'not_started';
  setStatusFilter: (filter: 'all' | 'achieved' | 'in_progress' | 'not_started') => void;
}

const EvaluationContext = createContext<EvaluationContextType | undefined>(undefined);

export function EvaluationProvider({ children }: { children: ReactNode }) {
  const { currentUser, userProfile } = useAuth();
  const [academicYear, setAcademicYear] = useState<string>('2024-2025');
  const [evaluationTerm, setEvaluationTerm] = useState<'semester_1' | 'semester_2' | 'annual'>('annual');
  const [scores, setScores] = useState<Record<string, IndicatorScore>>({});
  const [syncStatus, setSyncStatus] = useState<'synced' | 'saving' | 'error' | 'offline'>('synced');
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('saved');
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(true);
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);
  const [selectedStandard, setSelectedStandard] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'achieved' | 'in_progress' | 'not_started'>('all');

  // Ref to hold pending debounce timer
  const debounceTimerRef = React.useRef<NodeJS.Timeout | null>(null);
  const latestScoresRef = React.useRef<Record<string, IndicatorScore>>(scores);

  useEffect(() => {
    latestScoresRef.current = scores;
  }, [scores]);

  // Document ID for school evaluation in Firestore
  const docId = useMemo(() => {
    if (!currentUser) return 'guest_eval';
    const cleanSchool = (userProfile?.schoolName || 'school').replace(/[^a-zA-Z0-9_\u1780-\u17FF]/g, '_').slice(0, 30);
    return `${currentUser.uid}_${academicYear}_${evaluationTerm}`;
  }, [currentUser?.uid, academicYear, evaluationTerm, userProfile?.schoolName]);

  // Load from Firestore with Real-Time Snapshot
  useEffect(() => {
    if (!currentUser) {
      // Load from local storage for guest
      const local = localStorage.getItem(`eval_${academicYear}_${evaluationTerm}`);
      if (local) {
        try {
          setScores(JSON.parse(local));
        } catch (e) {
          console.error(e);
        }
      } else {
        setScores({});
      }
      return;
    }

    const evalDocRef = doc(db, 'school_evaluations', docId);
    setSyncStatus('saving');

    const unsubscribe = onSnapshot(evalDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data() as SchoolEvaluationRecord;
        if (data.scores) {
          setScores(data.scores);
          setLastSavedAt(data.lastUpdated || new Date().toISOString());
        }
      } else {
        // Init empty default scores or check localStorage fallback
        const localKey = `eval_${currentUser.uid}_${academicYear}_${evaluationTerm}`;
        const cached = localStorage.getItem(localKey);
        if (cached) {
          try {
            const parsed = JSON.parse(cached);
            setScores(parsed);
          } catch (e) {
            setScores({});
          }
        } else {
          setScores({});
        }
      }
      setSyncStatus('synced');
    }, (err) => {
      console.warn('Firestore real-time subscription error:', err);
      setSyncStatus('offline');
      // Load fallback from localStorage
      const cached = localStorage.getItem(`eval_${currentUser.uid}_${academicYear}_${evaluationTerm}`);
      if (cached) {
        try {
          setScores(JSON.parse(cached));
        } catch (e) {}
      }
    });

    return () => unsubscribe();
  }, [currentUser?.uid, docId, academicYear, evaluationTerm]);

  // Summaries calculation
  const { standardsSummaries, overallPercentage, overallAverage, totalCompletedActivities } = useMemo(() => {
    let grandTotalPercentageSum = 0;
    let totalCompletedAct = 0;

    const summaries: StandardSummary[] = STANDARDS_METADATA.map((meta) => {
      const indicatorsInStd = ALL_INDICATORS.filter(i => i.standardNumber === meta.number);
      const totalInd = indicatorsInStd.length;
      let totalActivitiesInStd = 0;
      let scoreSum = 0;
      let completedIndCount = 0;

      indicatorsInStd.forEach((ind) => {
        totalActivitiesInStd += ind.activitiesKh.length;
        const currentScore = scores[ind.id];
        if (currentScore) {
          scoreSum += currentScore.score || 0;
          if (currentScore.score >= 3 || currentScore.status === 'achieved' || currentScore.status === 'exceeded') {
            completedIndCount++;
          }
          if (currentScore.completedActivities) {
            totalCompletedAct += currentScore.completedActivities.length;
          }
        }
      });

      const avgScore = totalInd > 0 ? (scoreSum / totalInd) : 0;
      const pctScore = (avgScore / 5) * 100;
      grandTotalPercentageSum += pctScore;

      let statusLabel = 'មិនទាន់វាយតម្លៃ';
      if (pctScore >= 90) statusLabel = 'ឆ្នើម (Exemplary)';
      else if (pctScore >= 75) statusLabel = 'ល្អប្រសើរ (Advanced)';
      else if (pctScore >= 50) statusLabel = 'មធ្យម (Proficient)';
      else if (pctScore > 0) statusLabel = 'កំពុងអភិវឌ្ឍ (Developing)';

      return {
        standardNumber: meta.number,
        titleKh: meta.titleKh,
        titleEn: meta.titleEn,
        totalIndicators: totalInd,
        totalActivities: totalActivitiesInStd,
        completedIndicators: completedIndCount,
        averageScore: Number(avgScore.toFixed(2)),
        percentageScore: Math.round(pctScore),
        statusLabelKh: statusLabel
      };
    });

    const overallPct = Math.round(grandTotalPercentageSum / 5);
    const overallAvg = Number(((overallPct / 100) * 5).toFixed(2));

    return {
      standardsSummaries: summaries,
      overallPercentage: overallPct,
      overallAverage: overallAvg,
      totalCompletedActivities: totalCompletedAct
    };
  }, [scores]);

  const performanceLevel = useMemo(() => {
    return calculateSchoolPerformanceLevel(overallPercentage);
  }, [overallPercentage]);

  // Persist scores to Firestore and localStorage
  const persistScores = async (newScores: Record<string, IndicatorScore>) => {
    setSyncStatus('saving');
    setAutoSaveStatus('saving');
    const now = new Date().toISOString();
    setLastSavedAt(now);

    // Save to LocalStorage immediately
    const localKey = currentUser 
      ? `eval_${currentUser.uid}_${academicYear}_${evaluationTerm}` 
      : `eval_${academicYear}_${evaluationTerm}`;
    localStorage.setItem(localKey, JSON.stringify(newScores));

    if (currentUser) {
      try {
        const evalDocRef = doc(db, 'school_evaluations', docId);
        const record: Partial<SchoolEvaluationRecord> = {
          id: docId,
          userId: currentUser.uid,
          schoolName: userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ',
          schoolCode: userProfile?.schoolCode || '',
          province: userProfile?.province || 'រាជធានីភ្នំពេញ',
          academicYear,
          term: evaluationTerm,
          scores: newScores,
          overallScore: overallPercentage,
          overallAverage: overallAverage,
          levelKh: performanceLevel.levelKh,
          levelEn: performanceLevel.levelEn,
          lastUpdated: now,
          updatedBy: currentUser.uid,
          updatedByName: userProfile?.displayName || 'អ្នកប្រើប្រាស់'
        };

        await setDoc(evalDocRef, record, { merge: true });
        setSyncStatus('synced');
        setAutoSaveStatus('saved');
      } catch (err) {
        console.error('Error saving to Firestore:', err);
        setSyncStatus('offline');
        setAutoSaveStatus('error');
      }
    } else {
      setSyncStatus('synced');
      setAutoSaveStatus('saved');
    }
  };

  const saveScore = async (
    indicatorId: string, 
    scoreData: Partial<IndicatorScore>, 
    options: { immediate?: boolean } = {}
  ) => {
    const existing = scores[indicatorId] || {
      indicatorId,
      score: 1,
      percentage: 20,
      status: 'not_started',
      notes: '',
      evidenceLinks: [],
      completedActivities: [],
      updatedAt: new Date().toISOString()
    };

    const targetScore = scoreData.score !== undefined ? scoreData.score : existing.score;
    const percentage = scoreData.percentage !== undefined ? scoreData.percentage : Math.round((targetScore / 5) * 100);
    
    let derivedStatus: ScoreStatus = existing.status;
    if (scoreData.status) {
      derivedStatus = scoreData.status;
    } else if (targetScore >= 5) {
      derivedStatus = 'exceeded';
    } else if (targetScore >= 4) {
      derivedStatus = 'achieved';
    } else if (targetScore >= 2) {
      derivedStatus = 'in_progress';
    } else {
      derivedStatus = 'not_started';
    }

    const updatedScore: IndicatorScore = {
      ...existing,
      ...scoreData,
      score: targetScore,
      percentage,
      status: derivedStatus,
      updatedBy: currentUser?.uid || 'guest',
      updatedByName: userProfile?.displayName || 'Guest User',
      updatedAt: new Date().toISOString()
    };

    const newScores = {
      ...scores,
      [indicatorId]: updatedScore
    };

    // 1. Update React state immediately for instant feedback
    setScores(newScores);
    setAutoSaveStatus('saving');

    // 2. Immediate LocalStorage cache
    const localKey = currentUser 
      ? `eval_${currentUser.uid}_${academicYear}_${evaluationTerm}` 
      : `eval_${academicYear}_${evaluationTerm}`;
    localStorage.setItem(localKey, JSON.stringify(newScores));

    // 3. Clear any existing debounce timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }

    // 4. If immediate execution requested or auto-save disabled, persist now
    if (options.immediate) {
      await persistScores(newScores);
    } else {
      // Debounce Firestore write by 400ms for ultra-responsive auto-saving
      debounceTimerRef.current = setTimeout(async () => {
        await persistScores(newScores);
      }, 400);
    }
  };

  const toggleActivityCheck = async (indicatorId: string, activityIndex: number) => {
    const ind = ALL_INDICATORS.find(i => i.id === indicatorId);
    if (!ind) return;

    const existing = scores[indicatorId] || {
      indicatorId,
      score: 1,
      percentage: 20,
      status: 'not_started',
      notes: '',
      evidenceLinks: [],
      completedActivities: [],
      updatedAt: new Date().toISOString()
    };

    const currentCompleted = existing.completedActivities || [];
    let updatedCompleted: number[];

    if (currentCompleted.includes(activityIndex)) {
      updatedCompleted = currentCompleted.filter(i => i !== activityIndex);
    } else {
      updatedCompleted = [...currentCompleted, activityIndex];
    }

    const totalActs = ind.activitiesKh.length;
    const completedRatio = totalActs > 0 ? (updatedCompleted.length / totalActs) : 0;
    
    // Auto-calculate suggested star score based on checked activities
    let suggestedScore = 1;
    if (completedRatio >= 1) suggestedScore = 5;
    else if (completedRatio >= 0.75) suggestedScore = 4;
    else if (completedRatio >= 0.5) suggestedScore = 3;
    else if (completedRatio > 0) suggestedScore = 2;

    await saveScore(indicatorId, {
      completedActivities: updatedCompleted,
      score: suggestedScore,
      percentage: Math.round(completedRatio * 100)
    });
  };

  const bulkUpdateScores = async (newScores: Record<string, IndicatorScore>) => {
    setScores(newScores);
    await persistScores(newScores);
  };

  const resetAllScores = async () => {
    setScores({});
    await persistScores({});
  };

  const populateSampleData = async () => {
    const sampleScores: Record<string, IndicatorScore> = {};
    
    ALL_INDICATORS.forEach((ind, index) => {
      // Produce realistic high-performing school scores between 3 and 5 stars
      const scoreValue = (index % 4 === 0) ? 5 : (index % 3 === 0) ? 4 : (index % 2 === 0) ? 4 : 3;
      const allActs = ind.activitiesKh.map((_, i) => i);
      const checkedActs = scoreValue >= 5 ? allActs : allActs.slice(0, Math.max(1, allActs.length - 1));

      sampleScores[ind.id] = {
        indicatorId: ind.id,
        score: scoreValue,
        percentage: scoreValue * 20,
        status: scoreValue >= 4 ? 'achieved' : 'in_progress',
        notes: `បានអនុវត្តសកម្មភាពស្របតាមគោលការណ៍ណែនាំស្តង់ដា និងមានភស្តុតាងផ្ទៀងផ្ទាត់ត្រឹមត្រូវ។`,
        evidenceLinks: ['https://moeys.gov.kh/documents/report_sample.pdf'],
        completedActivities: checkedActs,
        updatedBy: currentUser?.uid || 'demo',
        updatedByName: userProfile?.displayName || 'គណៈកម្មការវាយតម្លៃ',
        updatedAt: new Date().toISOString()
      };
    });

    setScores(sampleScores);
    await persistScores(sampleScores);
  };

  const evaluationRecord: SchoolEvaluationRecord = {
    id: docId,
    userId: currentUser?.uid || 'guest',
    schoolName: userProfile?.schoolName || 'សាលាបឋមសិក្សា ហ៊ុន សែន មិត្តភាព',
    schoolCode: userProfile?.schoolCode || 'KH-120045',
    province: userProfile?.province || 'រាជធានីភ្នំពេញ',
    academicYear,
    term: evaluationTerm,
    scores,
    overallScore: overallPercentage,
    overallAverage,
    levelKh: performanceLevel.levelKh,
    levelEn: performanceLevel.levelEn,
    lastUpdated: lastSavedAt || new Date().toISOString(),
    updatedBy: currentUser?.uid || 'guest',
    updatedByName: userProfile?.displayName || 'Guest'
  };

  return (
    <EvaluationContext.Provider
      value={{
        evaluationRecord,
        academicYear,
        setAcademicYear,
        evaluationTerm,
        setEvaluationTerm,
        saveScore,
        toggleActivityCheck,
        bulkUpdateScores,
        resetAllScores,
        populateSampleData,
        standardsSummaries,
        overallPercentage,
        overallAverage,
        totalCompletedActivities,
        totalActivitiesCount: TOTAL_ACTIVITIES_COUNT,
        performanceLevel,
        syncStatus,
        autoSaveStatus,
        lastSavedAt,
        autoSaveEnabled,
        setAutoSaveEnabled,
        selectedStandard,
        setSelectedStandard,
        searchQuery,
        setSearchQuery,
        statusFilter,
        setStatusFilter
      }}
    >
      {children}
    </EvaluationContext.Provider>
  );
}

export function useEvaluation() {
  const context = useContext(EvaluationContext);
  if (!context) {
    throw new Error('useEvaluation must be used within an EvaluationProvider');
  }
  return context;
}
