export type UserRole = 
  | 'director'           // នាយកសាលា / Principal
  | 'deputy_director'    // នាយករង / Deputy Principal
  | 'teacher'            // លោកគ្រូ-អ្នកគ្រូ / Teacher
  | 'evaluator'          // អ្នកវាយតម្លៃ / Inspector/Evaluator
  | 'committee'          // គណៈកម្មការ គ.គ.ស. / School Committee
  | 'admin';             // អ្នកគ្រប់គ្រងប្រព័ន្ធ / System Administrator

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  schoolName: string;
  schoolCode?: string;
  province?: string;
  district?: string;
  phoneNumber?: string;
  bio?: string;
  createdAt: string;
  updatedAt: string;
  isAnonymous?: boolean;
}

export type ScoreStatus = 'not_started' | 'in_progress' | 'achieved' | 'exceeded';

export interface ActivityCheckItem {
  id: string;
  textKh: string;
  textEn?: string;
  completed: boolean;
}

export interface IndicatorScore {
  indicatorId: string;
  score: number; // 1 to 5
  percentage: number; // 0 to 100%
  status: ScoreStatus;
  notes: string;
  evidenceLinks?: string[];
  completedActivities?: number[]; // indices of completed sub-activities
  targetScore?: number;
  updatedBy?: string;
  updatedByName?: string;
  updatedAt: string;
}

export interface IndicatorDefinition {
  id: string;                  // e.g. "std1_1_1"
  standardNumber: number;      // 1 to 5
  standardTitleKh: string;
  standardTitleEn: string;
  sectionNumber: number;       // e.g. 1
  sectionTitleKh: string;
  sectionTitleEn: string;
  code: string;                // e.g. "១.១" or "៣.២"
  expectedResultKh: string;
  expectedResultEn: string;
  activitiesKh: string[];
  activitiesEn?: string[];
  maxScore: number;
  weight: number;
}

export interface StandardSummary {
  standardNumber: number;
  titleKh: string;
  titleEn: string;
  totalIndicators: number;
  totalActivities: number;
  completedIndicators: number;
  averageScore: number; // 1 to 5
  percentageScore: number; // 0 to 100%
  statusLabelKh: string;
}

export interface SchoolEvaluationRecord {
  id: string;
  userId: string;
  schoolName: string;
  schoolCode?: string;
  province?: string;
  academicYear: string;
  term: 'semester_1' | 'semester_2' | 'annual';
  scores: Record<string, IndicatorScore>; // indicatorId -> IndicatorScore
  overallScore: number; // 0 to 100
  overallAverage: number; // 1 to 5
  levelKh: string; // កម្រិតសាលា (ឧទាហរណ៍៖ សាលារៀនគំរូ, ល្អប្រសើរ, ល្អ, មធ្យម)
  levelEn: string;
  notes?: string;
  lastUpdated: string;
  updatedBy: string;
  updatedByName: string;
  evaluatorSignatures?: {
    director?: { name: string; signedAt: string; confirmed: boolean };
    inspector?: { name: string; signedAt: string; confirmed: boolean };
    committee?: { name: string; signedAt: string; confirmed: boolean };
  };
}

export interface AuditLogItem {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
}
