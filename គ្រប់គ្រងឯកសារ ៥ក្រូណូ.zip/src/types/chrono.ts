export type ChronoDocumentType = 
  | 'activity_report'       // របាយការណ៍សកម្មភាពអនុវត្ត
  | 'verification_report'   // របាយការណ៍ផ្ទៀងផ្ទាត់ និងវាយតម្លៃ
  | 'action_plan'           // ផែនការសកម្មភាព ឬផែនការកែលម្អ
  | 'meeting_minutes'       // កំណត់ហេតុប្រជុំ គ.គ.ស / លោកគ្រូ-អ្នកគ្រូ
  | 'moeys_decision'        // សេចក្តីសម្រេច / លិខិតបទដ្ឋានផ្ទៃក្នុង
  | 'student_list'          // បញ្ជីស្ថិតិ / លទ្ធផលសិក្សាសិស្ស
  | 'observation_sheet'     // តារាងសង្កេតការបង្រៀន / កិច្ចតែងការ
  | 'evidence_photo'        // កម្រងរូបភាពភស្តុតាងសកម្មភាព
  | 'financial_receipt'     // របាយការណ៍ហិរញ្ញវត្ថុ / វិក្កយបត្រ
  | 'other';                // ឯកសារផ្សេងៗ

export type ChronoDocumentStatus = 
  | 'draft'                 // ឯកសារព្រាង (Draft)
  | 'ready_for_signature'   // រៀបចំរួចរាល់ រង់ចាំចុះហត្ថលេខា (Ready for Sign)
  | 'signed_and_filed'      // បានចុះហត្ថលេខា & តម្កល់ក្នុងក្រូណូ (Signed & Filed in Chrono)
  | 'verified';             // បានផ្ទៀងផ្ទាត់ដោយគណៈកម្មការ/អធិការ (Verified)

export type ChronoFileType = 
  | 'text'                  // អត្ថបទរដ្ឋបាលឌីជីថល (Digital MoEYS Doc)
  | 'pdf'                   // ឯកសារ PDF
  | 'image'                 // រូបភាពភស្តុតាង (JPG, PNG, WebP)
  | 'docx'                  // ឯកសារ Word (.docx, .doc)
  | 'xlsx'                  // ឯកសារ Excel (.xlsx, .xls, .csv)
  | 'raw_code';             // កូដ / Raw Text / Data

export interface ChronoDocument {
  id: string;
  schoolId: string;
  userId: string;
  standardNumber: number;        // 1, 2, 3, 4, 5
  indicatorId: string;          // e.g. "std1_1_1"
  indicatorCode: string;        // e.g. "១.១"
  sectionNumber: number;        // e.g. 1
  sectionTitleKh: string;
  titleKh: string;
  documentNumber?: string;       // e.g. "លេខ ០១៤/២៤ របក"
  dateKh?: string;              // e.g. "ថ្ងៃចន្ទ ទី១២ ខែកុម្ភៈ ឆ្នាំ២០២៤"
  lunarDateKh?: string;         // e.g. "ថ្ងៃសៅរ៍ ១៥កើត ខែផល្គុន ឆ្នាំម្សាញ់ សប្តស័ក ព.ស.២៥៦៩"
  solarDateKh?: string;         // e.g. "រោគ ថ្ងៃទី២៥ ខែមេសា ឆ្នាំ២០២៦"
  locationKh?: string;          // e.g. "ស្រុកភ្នំស្រុក", "រោគ"
  administrationLine1?: string; // e.g. "រដ្ឋបាលស្រុកភ្នំស្រុក" ឬ "ក្រសួងអប់រំ យុវជន និងកីឡា"
  administrationLine2?: string; // e.g. "ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក"
  administrationLine3?: string; // e.g. "កម្រងស្ថានីយស្រែល្អ"
  administrationLine4?: string; // e.g. "សាលាបឋមសិក្សា រោគ"
  secondApproverRole?: string;  // e.g. "ប្រធានគណៈកម្មការ គ.គ.ស"
  secondApproverName?: string;  // e.g. "ឈ្មោះប្រធាន គ.គ.ស"
  approverRole?: string;        // e.g. "នាយកសាលា"
  approverName?: string;        // e.g. "នាយកសាលារៀន"
  reporterRole?: string;        // e.g. "អ្នកធ្វើរបាយការណ៍"
  reporterName?: string;        // e.g. "អ៊ិន ប៊ុនធុង"
  documentType: ChronoDocumentType;
  status: ChronoDocumentStatus;
  summaryKh: string;
  contentMarkdown: string;       // Rich formatted markdown text
  fileType: ChronoFileType;
  fileName?: string;
  fileSize?: number;
  fileBase64?: string;          // For uploaded images/PDFs
  fileUrl?: string;
  signedFileName?: string;
  signedFileBase64?: string;    // Re-uploaded scanned photo/PDF with real physical stamp & signature!
  signedFileUrl?: string;
  signedAt?: string;
  signedByName?: string;
  signedRole?: string;
  tags?: string[];
  aiGenerated?: boolean;
  aiEnhanced?: boolean;
  createdAt: string;
  updatedAt: string;
  authorName: string;
  academicYear: string;
}

export interface ChronoFolderStats {
  standardNumber: number;
  totalDocuments: number;
  signedDocuments: number;
  draftDocuments: number;
  verifiedDocuments: number;
  hasPhysicalHardCopyReady: boolean;
}
