export type SchoolEventCategory = 
  | 'standard_1'        // ស្តង់ដាទី១៖ លទ្ធផលសិក្សាសិស្ស
  | 'standard_2'        // ស្តង់ដាទី២៖ ការបង្រៀន និងរៀន
  | 'standard_3'        // ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍ (គ.គ.ស)
  | 'standard_4'        // ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិការសាលារៀន
  | 'standard_5'        // ស្តង់ដាទី៥៖ គណនេយ្យភាពរបស់សាលារៀន
  | 'meeting'           // កិច្ចប្រជុំរដ្ឋបាល និងបច្ចេកទេស
  | 'exam'              // ការប្រឡង និងវាយតម្លៃសមត្ថភាព
  | 'national_holiday'  // ពិធីបុណ្យជាតិ និងសាសនា
  | 'holy_day';         // ថ្ងៃសីល

export type SchoolEventStatus = 'planned' | 'in_progress' | 'completed' | 'postponed';

export interface SchoolEvent {
  id: string;
  titleKh: string;
  titleEn?: string;
  gregorianDate: string; // YYYY-MM-DD
  lunarDateKh?: string;  // ឧ. "ថ្ងៃច័ន្ទ ១៥កើត ខែមាឃ ឆ្នាំមមី ឆស័ក ព.ស.២៥៧០"
  shortLunarKh?: string; // ឧ. "១៥កើត ខែមាឃ"
  category: SchoolEventCategory;
  standardNumber?: number; // 1 to 5
  indicatorCode?: string;  // e.g. "១.១", "២.៣"
  time?: string;           // e.g. "08:00 - 11:00"
  location?: string;       // e.g. "សាលប្រជុំសាលា", "ទីធ្លាសាលារៀន"
  responsiblePerson?: string; // e.g. "នាយកសាលា", "Tong Un"
  participantsCount?: number;
  status: SchoolEventStatus;
  descriptionKh?: string;
  isHolyDay?: boolean;
  isNationalHoliday?: boolean;
  createdAt: string;
  updatedAt: string;
}
