import { IndicatorDefinition } from '../types';

export const STANDARDS_METADATA = [
  {
    number: 1,
    titleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    titleEn: 'Standard 1: Student Learning Outcomes',
    shortKh: 'លទ្ធផលសិក្សា',
    color: 'emerald',
    iconName: 'GraduationCap',
    descriptionKh: 'ការប្រមូលកុមារចូលរៀន ភាពគង់វង្ស លទ្ធផលសិក្សា អាហារូបត្ថម្ភ សីលធម៌ និងឥរិយាបថរបស់សិស្ស'
  },
  {
    number: 2,
    titleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    titleEn: 'Standard 2: Teaching and Learning Process',
    shortKh: 'បង្រៀន & រៀន',
    color: 'blue',
    iconName: 'BookOpen',
    descriptionKh: 'វិធីសាស្ត្របង្រៀនថ្មី កម្មវិធីសិក្សា សម្ភារឧបទេស បណ្ណាល័យ អធិការកិច្ចផ្ទៃក្នុង និងក្លឹបសិក្សា'
  },
  {
    number: 3,
    titleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    titleEn: 'Standard 3: Community Participation',
    shortKh: 'ការចូលរួមសហគមន៍',
    color: 'amber',
    iconName: 'Users',
    descriptionKh: 'ដំណើរការ គ.គ.ស គ.គ.ថ ភាពជាដៃគូវិនិយោគ ការទប់ស្កាត់ការបោះបង់ និងមូលនិធិសាលារៀន'
  },
  {
    number: 4,
    titleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    titleEn: 'Standard 4: School Operation and Administration',
    shortKh: 'ប្រតិបត្តិ & រដ្ឋបាល',
    color: 'purple',
    iconName: 'Building2',
    descriptionKh: 'រដ្ឋបាលទូទៅ ផែនការអភិវឌ្ឍ ៥ឆ្នាំ ការវាយតម្លៃបុគ្គលិក សុខភាពសិក្សា និងហេដ្ឋារចនាសម្ព័ន្ធ'
  },
  {
    number: 5,
    titleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    titleEn: 'Standard 5: Accountability',
    shortKh: 'គណនេយ្យភាព',
    color: 'rose',
    iconName: 'ShieldCheck',
    descriptionKh: 'វេទិកាសាធារណៈ ការផ្សាយព័ត៌មាន និងការទទួលបានការគាំទ្រ ហ្វឹកហាត់ពីថ្នាក់ជាតិ'
  }
];

export const ALL_INDICATORS: IndicatorDefinition[] = [
  // ==========================================
  // ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស
  // ==========================================
  {
    id: 'std1_1_1',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 1,
    sectionTitleKh: '១. ការប្រមូលកុមារចូលរៀន',
    sectionTitleEn: '1. Student Enrollment and Intake',
    code: '១.១',
    expectedResultKh: 'ភាគរយសិស្សថ្នាក់ទី១ចូលរៀនបានត្រឹមត្រូវតាមអាយុ ១០០%',
    expectedResultEn: 'Percentage of Grade 1 students enrolled at the correct age is 100%',
    activitiesKh: [
      'រៀបចំ ការចុះបញ្ជីសិស្សថ្មី',
      'ផ្សព្វផ្សាយអំពី អត្ថប្រយោជន៍នៃការចូលរៀន តាមសហគមន៍',
      'សហការជាមួយ មាតាបិតា និងអាជ្ញាធរ ដើម្បីធានាថាកុមារទាំងអស់ចូលរៀនតាមអាយុ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_2_1',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 2,
    sectionTitleKh: '២. សិស្សរៀនបានគង់វង្សក្នុងសាលារៀន',
    sectionTitleEn: '2. Student Retention and Progression',
    code: '២.១',
    expectedResultKh: 'ភាគរយសិស្សបោះបង់ការសិក្សាបានថយចុះមកត្រឹម ៣%',
    expectedResultEn: 'Dropout rate reduced down to 3%',
    activitiesKh: [
      'ធ្វើ សម្ភាសន៍សិស្ស និងមាតាបិតា ដើម្បីរកមូលហេតុបោះបង់',
      'ផ្តល់ជំនួយ សម្ភារៈសិក្សា ឬអាហារូបករណ៍',
      'បង្កើត ក្រុមគាំទ្រសិស្សក្នុងសាលា ដើម្បីជួយពង្រឹងចិត្តស្មោះត្រង់ក្នុងការរៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_2_2',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 2,
    sectionTitleKh: '២. សិស្សរៀនបានគង់វង្សក្នុងសាលារៀន',
    sectionTitleEn: '2. Student Retention and Progression',
    code: '២.២',
    expectedResultKh: 'ភាគរយសិស្សរៀនត្រួតថ្នាក់បានថយចុះមកត្រឹម ២%',
    expectedResultEn: 'Repetition rate reduced down to 2%',
    activitiesKh: [
      'រៀបចំ ថ្នាក់បង្រៀនបន្ថែម (Remedial Class) សម្រាប់សិស្សដែលមានលទ្ធផលទាប',
      'តាមដាន លទ្ធផលសិក្សា និងពិន្ទុ ជាប្រចាំ',
      'ប្រើ វិធីសាស្រ្តបង្រៀនចម្រុះ ដើម្បីឲ្យសិស្សយល់បានងាយ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_3_1',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 3,
    sectionTitleKh: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
    sectionTitleEn: '3. Academic Achievement',
    code: '៣.១',
    expectedResultKh: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាភាសាខ្មែរ មានការកើនឡើង',
    expectedResultEn: 'Percentage of students achieving Grades A, B, and C in Khmer Language increased',
    activitiesKh: [
      'ពង្រឹងការបង្រៀនលើការសរសេរអត្ថបទ (រៀបរាប់ ពិពណ៌នា និងរបាយការណ៍) វេយ្យាករណ៍ និងការអានយល់ន័យស៊ីជម្រៅ',
      'រៀបចំថ្នាក់បង្រៀនបំប៉ន (Remedial Teaching) ដល់សិស្សទទួលបាននិទ្ទេស D និង E និងផ្តល់លំហាត់ប្រឈមបន្ថែម (Advanced Tasks) សម្រាប់រក្សាការពារនិទ្ទេស A B C'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_3_2',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 3,
    sectionTitleKh: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
    sectionTitleEn: '3. Academic Achievement',
    code: '៣.២',
    expectedResultKh: 'ភាគរយសិស្សមាននិទ្ទេស A B និង C មុខវិជ្ជាគណិតវិទ្យា មានការកើនឡើង',
    expectedResultEn: 'Percentage of students achieving Grades A, B, and C in Mathematics increased',
    activitiesKh: [
      'ពង្រឹងការបង្រៀនគំនិតវិភាគ ការដោះស្រាយលំហាត់ស្មុគស្មាញ និងការអនុវត្តរូបមន្តជាក់ស្តែងតាមរយៈការប្រើប្រាស់សម្ភារឧបទេស',
      'បង្កើតក្រុមសិក្សារួមគ្នា (Peer Tutoring) និងរៀបចំម៉ោងដោះស្រាយលំហាត់កម្រិតខ្ពស់សម្រាប់សិស្សពូកែ ព្រមទាំងជួយសង្គ្រោះសិស្សខ្សោយ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_3_3',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 3,
    sectionTitleKh: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
    sectionTitleEn: '3. Academic Achievement',
    code: '៣.៣',
    expectedResultKh: 'ភាគរយសិស្សថ្នាក់ទី៣ មានសមត្ថភាពអានតាមស្តង់ដា (៤៥ ទៅ ៦០ពាក្យក្នុង១នាទី) មានការកើនឡើង',
    expectedResultEn: 'Percentage of Grade 3 students reading at benchmark (45-60 wpm) increased',
    activitiesKh: [
      'អនុវត្តវិធីសាស្ត្រអំណានថ្នាក់ដំបូង ដោយផ្តោតលើការផ្សំសំឡេង (ព្យញ្ជនៈ ស្រៈ ជើងពាក្យ និងសញ្ញា) និងការអានអត្ថបទខ្លីៗដដែលៗ (Repeated Reading)',
      'ប្រើប្រាស់បណ្ណអក្សរ (Flashcards) និងសកម្មភាពល្បែងអានអក្សរក្នុងថ្នាក់រៀនដើម្បីជំរុញចំណាប់អារម្មណ៍សិស្ស'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_3_4',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 3,
    sectionTitleKh: '៣. លទ្ធផលសិក្សារបស់សិស្ស',
    sectionTitleEn: '3. Academic Achievement',
    code: '៣.៤',
    expectedResultKh: 'ភាគរយសិស្សថ្នាក់ទី៦ មានសមត្ថភាពអានតាមស្តង់ដា (១០០ ទៅ ១២០ពាក្យក្នុង១នាទី) មានការកើនឡើង',
    expectedResultEn: 'Percentage of Grade 6 students reading at benchmark (100-120 wpm) increased',
    activitiesKh: [
      'ជំរុញទម្លាប់អានសៀវភៅបណ្ណាល័យ រឿងខ្លី ឬអត្ថបទផ្សេងៗ និងបង្រៀនបច្ចេកទេសអានចាប់យកអត្ថន័យលឿន (Skimming and Scanning)',
      'រៀបចំការប្រកួតប្រជែងអានល្បឿន និងការយល់ន័យក្នុងកម្រិតថ្នាក់រៀន ឬកម្រិតសាលារៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_4_1',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 4,
    sectionTitleKh: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រ ផ្នែក សុខភាពនិងសុវត្ថិភាពសិក្សា)',
    sectionTitleEn: '4. Nutrition Status and Health Support',
    code: '៤.១',
    expectedResultKh: 'ភាគរយសិស្សមានស្ថានភាពអាហារូបត្ថម្ភធម្មតា',
    expectedResultEn: 'Percentage of students with normal nutritional status',
    activitiesKh: [
      'សហការជាមួយមណ្ឌលសុខភាព ឬអង្គការដៃគូដើម្បីពិនិត្យសុខភាព និងវាស់កម្ពស់-ទម្ងន់សិស្សជាប្រចាំ',
      'រៀបចំកម្មវិធីអប់រំសុខភាព និងអាហារូបត្ថម្ភដល់សិស្ស និងមាតាបិតា ព្រមទាំងត្រួតពិនិត្យ និងហាមឃាត់ការលក់ចំណីអាហារគ្មានគុណភាព ឬខូចគុណភាពនៅក្បែរ និងក្នុងបរិវេណសាលារៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_4_2',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 4,
    sectionTitleKh: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រ ផ្នែក សុខភាពនិងសុវត្ថិភាពសិក្សា)',
    sectionTitleEn: '4. Nutrition Status and Health Support',
    code: '៤.២',
    expectedResultKh: 'ភាគរយសិស្សដែលមានបញ្ហាអាហារូបត្ថម្ភ ទទួលបានកិច្ចអន្តរាគមន៍',
    expectedResultEn: 'Percentage of malnourished students receiving support and intervention',
    activitiesKh: [
      'បង្កើតបញ្ជីឈ្មោះសិស្សដែលមានបញ្ហាអាហារូបត្ថម្ភ (ក្រិន ស្គមស្គាំង ឬធាត់ជ្រុល) និងផ្តល់អាហារបំប៉ន (ប្រសិនបើមានកម្មវិធីអាហារូបត្ថម្ភរបស់សាលា ឬកាកបាទក្រហម) ព្រមទាំងបញ្ជូនករណីធ្ងន់ធ្ងរទៅមណ្ឌលសុខភាព',
      'ណែនាំដល់អាណាព្យាបាលអំពីរបបអាហារដែលមានជីវជាតិគ្រប់គ្រាន់សម្រាប់កុមារ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_4_3',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 4,
    sectionTitleKh: '៤. ស្ថានភាពអាហារូបត្ថម្ភ (ការគាំទ្រ ផ្នែក សុខភាពនិងសុវត្ថិភាពសិក្សា)',
    sectionTitleEn: '4. Nutrition Status and Health Support',
    code: '៤.៣',
    expectedResultKh: 'ភាគរយសិស្សក្រីក្រទទួលបានអាហារូបករណ៍ ឬការឧបត្ថម្ភនានា',
    expectedResultEn: 'Percentage of underprivileged students receiving scholarships or aid',
    activitiesKh: [
      'បង្កើតគណៈកម្មការពិនិត្យ និងជ្រើសរើសសិស្សក្រីក្រ ឬងាយរងគ្រោះតាមលក្ខខណ្ឌវិនិច្ឆ័យច្បាស់លាស់ និងត្រឹមត្រូវ',
      'រៀបចំកៀរគររកសប្បុរសជន ឬសហការជាមួយក្រសួង-ស្ថាប័ន និងអង្គការដៃគូដើម្បីផ្តល់ថវិកាឧបត្ថម្ភ សម្ភារសិក្សា ឬអង្ករដល់គ្រួសារសិស្សក្រីក្រ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_5_1',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 5,
    sectionTitleKh: '៥. សីលធម៌ និងឥរិយាបថរបស់សិស្ស',
    sectionTitleEn: '5. Student Morals, Values and Behavior',
    code: '៥.១',
    expectedResultKh: 'ភាគរយកុមារទទួលបានការប្រឹក្សាយោបល់',
    expectedResultEn: 'Percentage of children receiving counseling and emotional guidance',
    activitiesKh: [
      'បង្កើតបន្ទប់ប្រឹក្សាយោបល់ ឬចាត់តាំងគ្រូបន្ទុកបន្ទប់ និងគ្រូប្រឹក្សាសុខភាពផ្លូវចិត្ត/អប្សរាសាលារៀន ដើម្បីផ្តល់ការណែនាំដល់សិស្សដែលមានបញ្ហាអាកប្បកិរិយា បញ្ហាគ្រួសារ ឬបញ្ហាស្ត្រេសក្នុងការសិក្សា',
      'អនុវត្តកម្មវិធីអប់រំសីលធម៌ និងការលើកទឹកចិត្តតាមរយៈការប្រជុំគោរពទង់ជាតិ ឬម៉ោងសីលធម៌'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std1_5_2',
    standardNumber: 1,
    standardTitleKh: 'ស្តង់ដាទី១៖ លទ្ធផលសិក្សារបស់សិស្ស',
    standardTitleEn: 'Standard 1: Student Learning Outcomes',
    sectionNumber: 5,
    sectionTitleKh: '៥. សីលធម៌ និងឥរិយាបថរបស់សិស្ស',
    sectionTitleEn: '5. Student Morals, Values and Behavior',
    code: '៥.២',
    expectedResultKh: 'ភាគរយថ្នាក់រៀនដាក់ពិន្ទុ បំណិនសម្បទា និងចរិយាសម្បទាដល់សិស្សប្រចាំឆ្នាំ',
    expectedResultEn: 'Percentage of classes grading student soft skills and moral conduct annually',
    activitiesKh: [
      'ជំរុញ និងណែនាំដល់គ្រូបង្រៀនគ្រប់ថ្នាក់ឱ្យយកចិត្តទុកដាក់ដាក់ពិន្ទុវាយតម្លៃលើផ្នែកចរិយាសម្បទា (សេចក្តីថ្លៃថ្នូរ ការគោរពវិន័យ ការរួសរាយរាក់ទាក់) និងបំណិនសម្បទា (ការងារក្រុម ការដោះស្រាយបញ្ហា) ក្នុងកាតរបាយការណ៍លទ្ធផលសិក្សារបស់សិស្ស',
      'ត្រួតពិនិត្យ និងវាយតម្លៃការកត់ត្រាពិន្ទុទាំងនេះដោយនាយកសាលា ឬនាយករងបច្ចេកទេស'
    ],
    maxScore: 5,
    weight: 1
  },

  // ==========================================
  // ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន
  // ==========================================
  {
    id: 'std2_1_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 1,
    sectionTitleKh: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
    sectionTitleEn: '1. Implementation of Modern Teaching Methodologies',
    code: '១.១',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈអំណាន ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣',
    expectedResultEn: 'Percentage of Grades 1-3 teachers implementing early grade reading packages',
    activitiesKh: [
      'រៀបចំកិច្ចប្រជុំបណ្តុះបណ្តាលផ្ទៃក្នុងសាលា (School-based Training) អំពីរបៀបប្រើប្រាស់កញ្ចប់សម្ភារៈអំណានថ្នាក់ដំបូង (សៀវភៅគោល សៀវភៅរឿង ប័ណ្ណអក្សរ និងសម្ភារឧបទេស)',
      'នាយកសាលា ឬគ្រូឧទ្ទេសប្រចាំសាលា ត្រូវចុះអមថែទាំ (Mentoring) និងជួយគាំទ្រដល់គ្រូក្នុងការអនុវត្តផ្ទាល់ក្នុងថ្នាក់រៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_1_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 1,
    sectionTitleKh: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
    sectionTitleEn: '1. Implementation of Modern Teaching Methodologies',
    code: '១.២',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ អនុវត្តកញ្ចប់សម្ភារៈគណិតវិទ្យា ថ្នាក់ដំបូងកម្រិត២ និងកម្រិត៣',
    expectedResultEn: 'Percentage of Grades 1-3 teachers implementing early grade math packages',
    activitiesKh: [
      'ជំរុញឱ្យគ្រូប្រើប្រាស់សម្ភារឧបទេសរូបវន្ត (គ្រាប់គំនិត គ្រាប់ឡុកឡាក់ ក្តារបន្ទះ និងឧបករណ៍រាប់) ដែលមានក្នុងកញ្ចប់សម្ភារៈគណិតវិទ្យា ដើម្បីឱ្យសិស្សបានស្គាល់ចំនួន និងគណនាបែបបដិបត្តិ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_1_3',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 1,
    sectionTitleKh: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
    sectionTitleEn: '1. Implementation of Modern Teaching Methodologies',
    code: '១.៣',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនចូលរៀនវគ្គអភិវឌ្ឍសមត្ថភាពប្រចាំឆ្នាំ (កញ្ចប់សម្ភារៈអំណាននិងគណិតវិទ្យាថ្នាក់ដំបូង ការប្រឹក្សាគរុកោសល្យ វិធីសាស្ត្របង្រៀននានា ការអប់រំវិន័យបែបវិជ្ជមាន វិធីសាស្ត្រអំណានក្នុងបណ្ណាល័យ...)',
    expectedResultEn: 'Percentage of teachers attending annual Continuous Professional Development (CPD)',
    activitiesKh: [
      'រៀបចំផែនការអភិវឌ្ឍវិជ្ជាជីវៈបន្ត (CPD) ប្រចាំឆ្នាំរបស់សាលា រួមមានការបណ្តុះបណ្តាលលើវិន័យបែបវិជ្ជមាន វិធីសាស្ត្រអំណានក្នុងបណ្ណាល័យ និងការប្រឹក្សាគរុកោសល្យ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_1_4',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 1,
    sectionTitleKh: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
    sectionTitleEn: '1. Implementation of Modern Teaching Methodologies',
    code: '១.៤',
    expectedResultKh: 'ចំនួនកិច្ចការជាគម្រោងដែលគ្រូថ្នាក់ទី៤-៦ បានដាក់ឱ្យសិស្សអនុវត្ត ក្នុង១ឆ្នាំ (គិតជាមធ្យម ក្នុងថ្នាក់/សាលា)',
    expectedResultEn: 'Average number of student project-based learning assignments in Grades 4-6 per year',
    activitiesKh: [
      'ណែនាំគ្រូឱ្យរៀបចំកិច្ចការគម្រោងតូចៗ (Project-based Learning) ស្របតាមកម្មវិធីសិក្សា ដូចជាការធ្វើរបាយការណ៍ស្ដីពីបរិស្ថាន ការចងក្រងអត្ថបទរឿងខ្លី ឬគម្រោងគណិតវិទ្យាជាក់ស្តែង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_1_5',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 1,
    sectionTitleKh: '១. ការអនុវត្តវិធីសាស្ត្របង្រៀនថ្មី',
    sectionTitleEn: '1. Implementation of Modern Teaching Methodologies',
    code: '១.៥',
    expectedResultKh: 'ភាគរយសិស្សបានធ្វើកិច្ចការតាមផ្ទះ មេរៀនភាសាខ្មែរ គណិត និងមានការកែពីគ្រូ',
    expectedResultEn: 'Percentage of students completing homework in Khmer & Math with teacher feedback',
    activitiesKh: [
      'ដាក់កិច្ចការផ្ទះសមស្រប (មិនច្រើនជ្រុលពេក) លើមុខវិជ្ជាភាសាខ្មែរ និងគណិតវិទ្យា និងបង្កើតវិន័យក្នុងការប្រមូលសៀវភៅមកកែតម្រូវ និងផ្តល់មតិយោបល់ (Feedback) ដល់សិស្សវិញ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.១',
    expectedResultKh: 'ភាគរយថ្នាក់រៀនដែលមានបំណែងចែកកម្មវិធីសិក្សា គ្រប់មុខវិជ្ជាសិក្សាគោល',
    expectedResultEn: 'Percentage of classrooms with complete curriculum distribution plans',
    activitiesKh: [
      'ផ្តល់គំរូ និងតម្រូវឱ្យគ្រូបង្រៀនគ្រប់រូបកសាងបំណែងចែកកម្មវិធីសិក្សា (Curriculum Distribution) ឱ្យបានច្បាស់លាស់តាមសប្តាហ៍ និងត្រីមាស មុនពេលបើកបវេសនកាល'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.២',
    expectedResultKh: 'ភាគរយគ្រូដែលបានរៀបចំកិច្ចតែងការបង្រៀនថ្មី ឬបានធ្វើបច្ចុប្បន្នកម្ម គ្រប់មេរៀន និងគ្រប់មុខវិជ្ជា',
    expectedResultEn: 'Percentage of teachers with updated lesson plans for all subjects',
    activitiesKh: [
      'ជំរុញឱ្យគ្រូរៀបចំកិច្ចតែងការបង្រៀន (Lesson Plan) ឱ្យបានទៀងទាត់មុនពេលចូលបង្រៀនក្នុងថ្នាក់ ដោយផ្អែកលើវិធីសាស្ត្របង្រៀនថ្មី'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_3',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.៣',
    expectedResultKh: 'ចំនួនដងថ្នាក់រៀនបិទទ្វារ (សរុបថ្នាក់ទាំងអស់គិតជាមធ្យម)',
    expectedResultEn: 'Average number of unscheduled classroom closures',
    activitiesKh: [
      'ពង្រឹងអភិបាលកិច្ចសាលារៀន ត្រួតពិនិត្យវត្តមានគ្រូនិងសិស្សឱ្យបានតឹងរ៉ឹង និងទប់ស្កាត់ការបិទទ្វារសាលា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_4',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.៤',
    expectedResultKh: 'ចំនួនថ្ងៃសាលាបិទទ្វារមិនស្របតាមប្រតិទិនសិក្សាប្រចាំឆ្នាំ',
    expectedResultEn: 'Number of school closure days not aligned with the official academic calendar',
    activitiesKh: [
      'ពង្រឹងអភិបាលកិច្ចសាលារៀន ត្រួតពិនិត្យវត្តមានគ្រូនិងសិស្សឱ្យបានតឹងរ៉ឹង និងទប់ស្កាត់ការបិទទ្វារសាលាខុសពីច្បាប់'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_5',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.៥',
    expectedResultKh: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនភាសាបរទេស',
    expectedResultEn: 'Percentage of Grades 4-6 classes teaching foreign languages (English/French)',
    activitiesKh: [
      'រៀបចំកាលវិភាគសិក្សាបន្ថែមសម្រាប់មុខវិជ្ជាភាសាបរទេស (អង់គ្លេស/បារាំង) ទៅក្នុងម៉ោងសិក្សា ឬសកម្មភាពក្រៅម៉ោង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_6',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.៦',
    expectedResultKh: 'ភាគរយថ្នាក់ទី ៤-៦ បានបង្រៀនមេរៀន បំណិនជីវិតមូលដ្ឋាន',
    expectedResultEn: 'Percentage of Grades 4-6 classes teaching basic life skills',
    activitiesKh: [
      'រៀបចំកាលវិភាគសិក្សាបន្ថែមសម្រាប់បញ្ចូលមេរៀនបំណិនជីវិត (កសិកម្ម សិប្បកម្ម អនាម័យ សុវត្ថិភាព) ទៅក្នុងម៉ោងសិក្សា ឬសកម្មភាពក្រៅម៉ោង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_2_7',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 2,
    sectionTitleKh: '២. ការអនុវត្តកម្មវិធីសិក្សានិងការរៀបចំផែនការបង្រៀន',
    sectionTitleEn: '2. Curriculum Implementation and Lesson Planning',
    code: '២.៧',
    expectedResultKh: 'ភាគរយសិស្សអវត្តមាន លើសពី៤ដង ក្នុង១ឆ្នាំសិក្សា',
    expectedResultEn: 'Percentage of students absent more than 4 times per academic year',
    activitiesKh: [
      'បង្កើតប្រព័ន្ធតាមដានវត្តមានសិស្សប្រចាំថ្ងៃដោយគ្រូបន្ទុកបន្ទប់ និងទាក់ទងទៅអាណាព្យាបាលភ្លាមៗនៅពេលសិស្សអវត្តមានខុសប្រក្រតី ដើម្បីទប់ស្កាត់ការបោះបង់ការសិក្សា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_3_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 3,
    sectionTitleKh: '៣. សម្ភារៈរៀននិងបង្រៀន',
    sectionTitleEn: '3. Teaching and Learning Materials',
    code: '៣.១',
    expectedResultKh: 'ភាគរយសិស្សមានសៀវភៅសិក្សាគោលតាមនិយាម',
    expectedResultEn: 'Percentage of students with textbooks according to national standards',
    activitiesKh: [
      'ស្នើសុំការបែងចែកសៀវភៅសិក្សាគោលពីមន្ទីរ/ការិយាល័យអប់រំ និងរៀបចំការខ្ចី-ឱ្យខ្ចីសៀវភៅបណ្ណាល័យសាលា ដើម្បីបំពេញបន្ថែមដល់សិស្សដែលខ្វះខាត'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_3_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 3,
    sectionTitleKh: '៣. សម្ភារៈរៀននិងបង្រៀន',
    sectionTitleEn: '3. Teaching and Learning Materials',
    code: '៣.២',
    expectedResultKh: 'ភាគរយសិស្សថ្នាក់ទី១ និង/ឬ ទី២ និង/ឬ ទី៣ មានកញ្ចប់សម្ភារៈអំណាន និងគណិតវិទ្យា ថ្នាក់ដំបូង ដែលមាតាបិតាទិញឱ្យ',
    expectedResultEn: 'Percentage of Grades 1-3 students possessing early grade reading and math packages',
    activitiesKh: [
      'ជួបប្រជុំជាមួយមាតាបិតា/អាណាព្យាបាលសិស្សនៅដើមឆ្នាំ ដើម្បីពន្យល់ពីសារៈសំខាន់នៃកញ្ចប់សម្ភារៈអំណាននិងគណិតវិទ្យាថ្នាក់ដំបូង និងណែនាំពីទីកន្លែង ឬវិធីសាកសមក្នុងការទទួលបានសម្ភារៈទាំងនោះសម្រាប់កូនៗ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_3_3',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 3,
    sectionTitleKh: '៣. សម្ភារៈរៀននិងបង្រៀន',
    sectionTitleEn: '3. Teaching and Learning Materials',
    code: '៣.៣',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនផលិត និងប្រើប្រាស់សម្ភារៈឧបទេសជាប្រចាំ',
    expectedResultEn: 'Percentage of teachers regularly creating and utilizing teaching aids',
    activitiesKh: [
      'ជំរុញ និងផ្តល់ការលើកទឹកចិត្តដល់គ្រូឱ្យច្នៃប្រឌិតសម្ភារៈឧបទេសពីវត្ថុធាតុដើមក្នុងស្រុក (ក្រដាសកាតុង គម្របដប ឈើ…) សម្រាប់យកមកប្រើប្រាស់ក្នុងការបង្រៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_3_4',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 3,
    sectionTitleKh: '៣. សម្ភារៈរៀននិងបង្រៀន',
    sectionTitleEn: '3. Teaching and Learning Materials',
    code: '៣.៤',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនប្រើប្រាស់បច្ចេកវិទ្យាបម្រើឱ្យការរៀន និងបង្រៀន',
    expectedResultEn: 'Percentage of teachers integrating ICT in classroom teaching',
    activitiesKh: [
      'បណ្តុះបណ្តាលគ្រូឱ្យចេះប្រើប្រាស់ឧបករណ៍បច្ចេកវិទ្យា (ថេប្លេត កុំព្យូទ័រ កំពង់ផែវីដេអូអប់រំ ឬប្រព័ន្ធអេនឌ័រ) និងទាញយកវីដេអូបង្រៀនគំរូមកបញ្ចាំងជូនសិស្សមើលក្នុងថ្នាក់រៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_4_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 4,
    sectionTitleKh: '៤. ការជួយគាំទ្រសិស្ស',
    sectionTitleEn: '4. Student Learning Support',
    code: '៤.១',
    expectedResultKh: 'ភាគរយសិស្ស និងមាតាបិតា បានចុះកិច្ចព្រមព្រៀង រៀនសូត្រប្រចាំឆ្នាំជាមួយគ្រូ',
    expectedResultEn: 'Percentage of students and parents signing annual learning agreements',
    activitiesKh: [
      'រៀបចំទម្រង់កិច្ចព្រមព្រៀងរៀនសូត្រ (Learning Agreement) ដែលចែងពីការប្តេជ្ញាចិត្តរបស់សិស្ស អាណាព្យាបាល និងគ្រូបង្រៀន រួចអញ្ជើញមាតាបិតាមកផ្ដិតមេដៃ ឬចុះហត្ថលេខារួមគ្នា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_4_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 4,
    sectionTitleKh: '៤. ការជួយគាំទ្រសិស្ស',
    sectionTitleEn: '4. Student Learning Support',
    code: '៤.២',
    expectedResultKh: 'ភាគរយថ្នាក់រៀនមានការប្រជុំជាមួយ មាតាបិតា ពិនិត្យតាមដានការរៀនសូត្រ ទៀងទាត់',
    expectedResultEn: 'Percentage of classrooms conducting regular parent progress meetings',
    activitiesKh: [
      'កំណត់កាលវិភាគប្រជុំអាណាព្យាបាលសិស្សប្រចាំត្រីមាស ដើម្បីរាយការណ៍ពីវឌ្ឍនភាពសិក្សា បញ្ហាអវត្តមាន និងបញ្ហាប្រឈមផ្សេងៗ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_4_3',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 4,
    sectionTitleKh: '៤. ការជួយគាំទ្រសិស្ស',
    sectionTitleEn: '4. Student Learning Support',
    code: '៤.៣',
    expectedResultKh: 'ភាគរយសិស្សរៀនយឺតបានទទួលការជួយប្រចាំខែ ផ្អែកតាមលទ្ធផល តេស្តស្តង់ដាប្រចាំខែ',
    expectedResultEn: 'Percentage of slow learners receiving monthly remedial support based on test results',
    activitiesKh: [
      'វិភាគលទ្ធផលតេស្តប្រចាំខែ ដើម្បីកំណត់មុខសញ្ញាសិស្សរៀនយឺត និងរៀបចំម៉ោងបង្រៀនបំប៉នពិសេស (Remedial Teaching)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_5_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 5,
    sectionTitleKh: '៥. ដំណើរការបណ្ណាល័យ',
    sectionTitleEn: '5. Library Operations and Reading',
    code: '៥.១',
    expectedResultKh: 'ចំនួនសៀវភៅដែលសិស្សម្នាក់ៗ ខ្ចី-សង ក្នុង១ឆ្នាំ',
    expectedResultEn: 'Average number of books borrowed/returned per student per year',
    activitiesKh: [
      'រៀបចំប្រព័ន្ធគ្រប់គ្រងបណ្ណាល័យងាយស្រួល (មានកាតខ្ចីសៀវភៅ) និងជំរុញសិស្សឱ្យជ្រើសរើសសៀវភៅរឿង ឬសៀវភៅអានក្រៅថ្នាក់យកទៅអាននៅផ្ទះ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_5_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 5,
    sectionTitleKh: '៥. ដំណើរការបណ្ណាល័យ',
    sectionTitleEn: '5. Library Operations and Reading',
    code: '៥.២',
    expectedResultKh: 'ចំនួនដង គ្រូបង្រៀនម្នាក់ៗក្នុង១ឆ្នាំ នាំសិស្សចូលបណ្ណាល័យអនុវត្តសកម្មភាពអាន ដោយប្រើប្រាស់វិធីសាស្ត្រអំណាន',
    expectedResultEn: 'Number of library guided reading sessions conducted per teacher per year',
    activitiesKh: [
      'បញ្ចូលម៉ោងអំណានក្នុងបណ្ណាល័យទៅក្នុងកាលវិភាគបង្រៀនផ្លូវការ ដោយប្រើប្រាស់វិធីសាស្ត្រអំណានជាគូ ឬអំណានស្ងាត់'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_6_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការធ្វើអធិការកិច្ចផ្ទៃក្នុង',
    sectionTitleEn: '6. Internal Pedagogical Inspection',
    code: '៦.១',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនទទួលបានការផ្តល់ប្រឹក្សាគរុកោសល្យ/អធិការកិច្ចថ្នាក់រៀន យ៉ាងតិចម្តង/ខែ',
    expectedResultEn: 'Percentage of teachers receiving classroom observation and feedback at least once a month',
    activitiesKh: [
      'នាយកសាលា នាយករង ឬគ្រូឧទ្ទេសផ្ទៃក្នុង រៀបចំតារាងចុះអងើកការបង្រៀនក្នុងថ្នាក់រៀន (Classroom Observation) និងផ្តល់មតិកែលម្អ (Feedback) បែបស្ថាបនាដល់គ្រូ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_7_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 7,
    sectionTitleKh: '៧. ការប្រជុំ បច្ចេកទេស',
    sectionTitleEn: '7. Technical / Professional Learning Meetings',
    code: '៧.១',
    expectedResultKh: 'ចំនួនដងសាលារៀនបានរៀបចំការប្រជុំបច្ចេកទេស',
    expectedResultEn: 'Frequency of school Teacher Learning Community (TLC) technical meetings',
    activitiesKh: [
      'រៀបចំកិច្ចប្រជុំបណ្តុំវិជ្ជាជីវៈគ្រូបង្រៀន (TLC) ដើម្បីពិភាក្សាពីបញ្ហាគរុកោសល្យ ការដោះស្រាយលំហាត់ពិបាក និងការរៀបចំកិច្ចតែងការបង្រៀនរួមគ្នា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_8_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 8,
    sectionTitleKh: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
    sectionTitleEn: '8. Extracurricular Activities and Learning Clubs',
    code: '៨.១',
    expectedResultKh: 'ចំនួនដងការប្រកួតប្រជែងអំណាន និងធ្វើលំហាត់គណិតវិទ្យាក្នុងមួយឆ្នាំ',
    expectedResultEn: 'Number of annual school reading and mathematics competitions',
    activitiesKh: [
      'រៀបចំកម្មវិធីប្រកួតប្រជែងថ្នាក់រៀន និងថ្នាក់សាលា (ឧ. ការប្រកួតអានលឿន-យល់ន័យ និងប្រកួតដោះស្រាយលំហាត់គណិតវិទ្យាឆ្នើម)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_8_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 8,
    sectionTitleKh: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
    sectionTitleEn: '8. Extracurricular Activities and Learning Clubs',
    code: '៨.២',
    expectedResultKh: 'ចំនួនក្លឹបសិក្សាបានបង្កើតដើម្បីជួយសិស្សរៀនយឺត និងជួយការងារផ្សេងៗរបស់សាលា',
    expectedResultEn: 'Number of active student learning and community clubs established',
    activitiesKh: [
      'បង្កើតក្លឹបសិក្សា (ក្លឹបអំណាន គណិតវិទ្យា និងក្លឹបបរិស្ថាន) ដោយមានការចាត់តាំងសិស្សពូកែជួយសិស្សខ្សោយ (Peer-to-Peer Support)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_8_3',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 8,
    sectionTitleKh: '៨. ការអនុវត្តកម្មវិធីក្រៅម៉ោងសិក្សា',
    sectionTitleEn: '8. Extracurricular Activities and Learning Clubs',
    code: '៨.៣',
    expectedResultKh: 'ចំនួនដងសិស្សានុសិស្សបានចុះទស្សនៈកិច្ចសិក្សានៅតាមទីកន្លែងនានា ក្នុងមួយឆ្នាំសិក្សា',
    expectedResultEn: 'Number of educational study tours conducted per academic year',
    activitiesKh: [
      'រៀបចំផែនការទស្សនកិច្ចសិក្សាទៅកាន់កសិដ្ឋាន វត្តអារាម មជ្ឈមណ្ឌលប្រវត្តិសាស្ត្រ ឬរោងចក្រក្នុងមូលដ្ឋាន ដើម្បីផ្សារភ្ជាប់ទ្រឹស្តីទៅនឹងការអនុវត្តជាក់ស្តែង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_9_1',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 9,
    sectionTitleKh: '៩. ការអនុវត្តការអប់រំសីលធម៌ ចរិយាធម៌',
    sectionTitleEn: '9. Moral and Ethical Education Activities',
    code: '៩.១',
    expectedResultKh: 'សាលារៀនមានកម្មវិធីលើកកម្ពស់ការអប់រំសីលធម៌ និងចរិយាធម៌ (ស្អាត សុភាព របៀប ទៀងពេល និងសមាធិ)',
    expectedResultEn: 'Implementation of the 5 Core Virtues: Clean, Polite, Orderly, Punctual, and Mindful (Meditation)',
    activitiesKh: [
      'អនុវត្តសកម្មភាពប្រចាំថ្ងៃដូចជា ការគោរពទង់ជាតិ ការពិនិត្យអនាម័យផ្ទាល់ខ្លួន ការធ្វើសមាធិ ៥ នាទីមុនចូលរៀន និងការអប់រំវិន័យបែបវិជ្ជមាន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std2_9_2',
    standardNumber: 2,
    standardTitleKh: 'ស្តង់ដាទី២៖ ដំណើរការបង្រៀន និងរៀន',
    standardTitleEn: 'Standard 2: Teaching and Learning Process',
    sectionNumber: 9,
    sectionTitleKh: '៩. ការអនុវត្តការអប់រំសីលធម៌ ចរិយាធម៌',
    sectionTitleEn: '9. Moral and Ethical Education Activities',
    code: '៩.២',
    expectedResultKh: 'ចំនួនដងព្រះសង្ឃនិមន្តមកផ្តល់ធម៌ទេសនាអប់រំ ក្នុង១ឆ្នាំ',
    expectedResultEn: 'Number of visits by monks for moral and ethical sermons per year',
    activitiesKh: [
      'សហការជាមួយវត្តអារាមក្នុងមូលដ្ឋាន ដើម្បីនិមន្តព្រះសង្ឃមកទេសនាអប់រំពីសីលធម៌ កតញ្ញូតាធម៌ និងការប្រព្រឹត្តខ្លួនជាកូនល្អ សិស្សល្អ'
    ],
    maxScore: 5,
    weight: 1
  },

  // ==========================================
  // ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍
  // ==========================================
  {
    id: 'std3_1_1',
    standardNumber: 3,
    standardTitleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    standardTitleEn: 'Standard 3: Community Participation',
    sectionNumber: 1,
    sectionTitleKh: '១. ការបង្កើតនិងដំណើរការគណៈកម្មការគ្រប់គ្រង សាលារៀន(គ.គ.ស)និងគណៈកម្មការគ្រប់គ្រងថ្នាក់រៀន(គ.គ.ថ)',
    sectionTitleEn: '1. School and Classroom Management Committees (SMC & CMC)',
    code: '១.១',
    expectedResultKh: 'ចំនួនដងគណៈកម្មការគ្រប់គ្រងសាលារៀន (គ.គ.ស.) ប្រជុំក្នុងមួយឆ្នាំ',
    expectedResultEn: 'Frequency of School Management Committee (SMC) meetings per year',
    activitiesKh: [
      'រៀបចំកាលវិភាគប្រជុំទៀងទាត់របស់ គ.គ.ស. និងកំណត់របៀបវារៈច្បាស់លាស់ (ពិភាក្សាពីផែនការយុទ្ធសាស្ត្រអភិវឌ្ឍសាលារៀន ការតាមដានការរីកចម្រើនរបស់សិស្ស និងការដោះស្រាយបញ្ហាប្រឈមនានា)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std3_1_2',
    standardNumber: 3,
    standardTitleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    standardTitleEn: 'Standard 3: Community Participation',
    sectionNumber: 1,
    sectionTitleKh: '១. ការបង្កើតនិងដំណើរការគណៈកម្មការគ្រប់គ្រង សាលារៀន(គ.គ.ស)និងគណៈកម្មការគ្រប់គ្រងថ្នាក់រៀន(គ.គ.ថ)',
    sectionTitleEn: '1. School and Classroom Management Committees (SMC & CMC)',
    code: '១.២',
    expectedResultKh: 'ភាគរយថ្នាក់រៀនបង្កើត និងដំណើរការគណៈកម្មការគ្រប់គ្រងថ្នាក់រៀន (គ.គ.ថ)',
    expectedResultEn: 'Percentage of classrooms with functioning Classroom Management Committees (CMC)',
    activitiesKh: [
      'ណែនាំដល់គ្រូបន្ទុកបន្ទប់នីមួយៗឱ្យបង្កើត គ.គ.ថ. (តំណាងមាតាបិតាប្រចាំថ្នាក់) និងផ្តល់តួនាទីភារកិច្ចច្បាស់លាស់ក្នុងការជួយគាំទ្រសកម្មភាពអប់រំក្នុងថ្នាក់រៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std3_2_1',
    standardNumber: 3,
    standardTitleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    standardTitleEn: 'Standard 3: Community Participation',
    sectionNumber: 2,
    sectionTitleKh: '២. ការចូលរួមរបស់សហគមន៍',
    sectionTitleEn: '2. Community and Stakeholder Partnerships',
    code: '២.១',
    expectedResultKh: 'សាលារៀនមានកិច្ចសហប្រតិបត្តិការភាពជាដៃគូវិនិយោគជាមួយវិស័យសាធារណៈ វិស័យឯកជន និងដៃគូអភិវឌ្ឍ',
    expectedResultEn: 'Active multi-sector partnerships with public, private, and development organizations',
    activitiesKh: [
      'រៀបចំសំណើគម្រោងអភិវឌ្ឍសាលារៀន (សាងសង់អគារ បង្គន់អនាម័យ បណ្ណាល័យ ឬបំពាក់សម្ភារបច្ចេកវិទ្យា) និងធ្វើបណ្តាញទំនាក់ទំនងជាមួយអាជ្ញាធរដែនដី សប្បុរសជន និងអង្គការដៃគូ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std3_2_2',
    standardNumber: 3,
    standardTitleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    standardTitleEn: 'Standard 3: Community Participation',
    sectionNumber: 2,
    sectionTitleKh: '២. ការចូលរួមរបស់សហគមន៍',
    sectionTitleEn: '2. Community and Stakeholder Partnerships',
    code: '២.២',
    expectedResultKh: 'ភាគរយសិស្សត្រៀមនឹងបោះបង់ ឬបោះបង់ការសិក្សាបានត្រឡប់មករៀនវិញ ក្រោមការគាំទ្រពីសហគមន៍',
    expectedResultEn: 'Percentage of dropout-risk students brought back to school through community support',
    activitiesKh: [
      'បង្កើតក្រុមការងារចុះអន្តរាគមន៍បន្ទាន់ (នាយកសាលា លោកគ្រូ អ្នកគ្រូ និងអាជ្ញាធរ/គ.គ.ស.) ដើម្បីចុះសួរសុខទុក្ខ និងស្វែងរកមូលហេតុនៅពេលសិស្សអវត្តមានយូរ ឬបោះបង់ការសិក្សា ព្រមទាំងផ្តល់ការឧបត្ថម្ភគាំទ្រដើម្បីទាក់ទាញពួកគាត់ឱ្យចូលរៀនវិញ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std3_3_1',
    standardNumber: 3,
    standardTitleKh: 'ស្តង់ដាទី៣៖ ការចូលរួមរបស់សហគមន៍',
    standardTitleEn: 'Standard 3: Community Participation',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការគាំទ្ររបស់សហគមន៍',
    sectionTitleEn: '3. Community Financial and Resource Contribution',
    code: '៣.១',
    expectedResultKh: 'បរិមាណចំណូលមូលនិធិបង់ចូលសាលារៀន',
    expectedResultEn: 'Volume and transparency of community fund mobilization into school account',
    activitiesKh: [
      'រៀបចំយុទ្ធនាការកៀរគរមូលនិធិសហគមន៍ (Community Fundraising) ប្រកបដោយតម្លាភាព ដោយមានការចូលរួមពីអាណាព្យាបាល សប្បុរសជន និងសហគមន៍មូលដ្ឋាន ដើម្បីយកមកទ្រទ្រង់សកម្មភាពអភិវឌ្ឍសាលារៀន និងជួយសិស្សក្រីក្រ'
    ],
    maxScore: 5,
    weight: 1
  },

  // ==========================================
  // ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន
  // ==========================================
  {
    id: 'std4_1_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 1,
    sectionTitleKh: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
    sectionTitleEn: '1. General Administrative Management',
    code: '១.១',
    expectedResultKh: 'ការរៀបចំទីចាត់ការ ទុកដាក់ឯកសារ មានសណ្តាប់ធ្នាប់ និងមានរបៀបរៀបរយ',
    expectedResultEn: 'Systematic organization and categorization of school office records and documents',
    activitiesKh: [
      'រៀបចំទូដាក់ឯកសារតាមប្រភេទ (ឯកសាររដ្ឋបាល បុគ្គលិក បរទេស និងគណនេយ្យ) បិទស្លាកចំណាំច្បាស់លាស់ និងប្រើប្រាស់ប្រព័ន្ធរក្សាទុកឯកសារឌីជីថល (Soft Copy)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_1_2',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 1,
    sectionTitleKh: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
    sectionTitleEn: '1. General Administrative Management',
    code: '១.២',
    expectedResultKh: 'សាលារៀនប្រើប្រាស់ App សម្រាប់គ្រប់គ្រងទិន្នន័យសាលារៀន',
    expectedResultEn: 'School utilizes digital applications for real-time school data management',
    activitiesKh: [
      'ជំរុញ និងបណ្តុះបណ្តាលនាយកសាលា និងបុគ្គលិករដ្ឋបាលឱ្យប្រើប្រាស់កម្មវិធីគ្រប់គ្រងទិន្នន័យ (Database App) ឬប្រព័ន្ធព័ត៌មានអប់រំផ្សេងៗសម្រាប់កត់ត្រាវត្តមាន ពិន្ទុ និងស្ថិតិសិស្ស'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_1_3',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 1,
    sectionTitleKh: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
    sectionTitleEn: '1. General Administrative Management',
    code: '១.៣',
    expectedResultKh: 'ភាគរយគ្រូលើស-ខ្វះ ត្រូវបានថយចុះ',
    expectedResultEn: 'Teacher surplus/shortage discrepancy successfully reduced and balanced',
    activitiesKh: [
      'ធ្វើបច្ចុប្បន្នភាពតារាងបែងចែកម៉ោងបង្រៀនឱ្យបានច្បាស់លាស់ និងស្នើសុំការអន្តរាគមន៍ ឬការបំពេញបន្ថែមគ្រូបង្រៀនពីការិយាល័យអប់រំស្រុក/ខណ្ឌ ឬមន្ទីរអប់រំ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_1_4',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 1,
    sectionTitleKh: '១. ការគ្រប់គ្រងរដ្ឋបាលទូទៅ',
    sectionTitleEn: '1. General Administrative Management',
    code: '១.៤',
    expectedResultKh: 'សាលារៀនមានកម្មវិធីប្រជុំប្រចាំខែ ត្រីមាស និងឆមាសត្រឹមត្រូវ',
    expectedResultEn: 'Structured monthly, quarterly, and semester staff review meetings',
    activitiesKh: [
      'រៀបចំប្រតិទិនការងារប្រចាំឆ្នាំ ដោយកំណត់ថ្ងៃប្រជុំអធិការកិច្ចផ្ទៃក្នុង ប្រជុំបច្ចេកទេស និងប្រជុំគរុកោសល្យឱ្យបានច្បាស់លាស់'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_2_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 2,
    sectionTitleKh: '២. ការរៀបចំផែនការអភិវឌ្ឍសាលារៀន',
    sectionTitleEn: '2. School Strategic Development Planning',
    code: '២.១',
    expectedResultKh: 'ផែនការយុទ្ធសាស្ត្រអភិវឌ្ឍន៍សាលារៀន ៥ឆ្នាំ ផែនការយុទ្ធសាស្ត្រថវិកា ៣ឆ្នាំ ផែនការថវិកាប្រចាំឆ្នាំ និងផែនការប្រតិបត្តិប្រចាំឆ្នាំ បានរៀបចំតាមការណែនាំ',
    expectedResultEn: '5-Year Strategic Development Plan, 3-Year Budget, and Annual Operational Plan formulated',
    activitiesKh: [
      'បង្កើតក្រុមការងារកសាងផែនការអភិវឌ្ឍសាលារៀន (ដោយមានការចូលរួមពី គ.គ.ស. និងសហគមន៍) ដើម្បីកំណត់គោលដៅ វិភាគតម្រូវការ និងបែងចែកថវិកាឱ្យស្របតាមស្តង់ដាគុណភាពអប់រំ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_3_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការវាយតម្លៃការបំពេញការងាររបស់បុគ្គលិក',
    sectionTitleEn: '3. Staff Performance Appraisal',
    code: '៣.១',
    expectedResultKh: 'ចំនួនគ្រូបង្រៀន និងបុគ្គលិកអប់រំ បានចុះកិច្ចព្រមព្រៀងលទ្ធផលការងារប្រចាំឆ្នាំ',
    expectedResultEn: 'Number of teachers and staff signing annual performance agreements',
    activitiesKh: [
      'រៀបចំកិច្ចព្រមព្រៀងការងារ (Performance Agreement) ដែលកំណត់សូចនាករគោលដៅច្បាស់លាស់សម្រាប់បុគ្គលិកអប់រំ និងថ្នាក់ដឹកនាំសាលា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_3_2',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការវាយតម្លៃការបំពេញការងាររបស់បុគ្គលិក',
    sectionTitleEn: '3. Staff Performance Appraisal',
    code: '៣.២',
    expectedResultKh: 'ចំនួននាយកសាលានិងនាយករង បានចុះកិច្ចព្រមព្រៀងលទ្ធផលការងារប្រចាំឆ្នាំ',
    expectedResultEn: 'Principal and Deputy Principal annual leadership performance agreements signed and evaluated',
    activitiesKh: [
      'ចុះហត្ថលេខាលើកិច្ចព្រមព្រៀងនៅ ដើមឆ្នាំសិក្សា (ខែតុលា) និងធ្វើការវាយតម្លៃលទ្ធផលនៅ ចុងឆ្នាំសិក្សា (ខែឧសភា)'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_4_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 4,
    sectionTitleKh: '៤. រង្វាយតម្លៃលទ្ធផលសិក្សា',
    sectionTitleEn: '4. Standardized Assessment of Student Learning',
    code: '៤.១',
    expectedResultKh: 'ការរៀបចំធ្វើតេស្តស្តង់ដាដើមឆ្នាំ ឬចុងឆ្នាំ ប្រចាំខែ ឆមាស និងតេស្តស្តង់ដា ថ្នាក់ទី៣ និងទី៦ បានរៀបចំទៀងទាត់',
    expectedResultEn: 'Timely administration of standardized baseline, monthly, semester, and Grade 3 & 6 exams',
    activitiesKh: [
      'រៀបចំកាលវិវត្តនៃការធ្វើតេស្ត ការត្រួតពិនិត្យគុណភាពសំណួរ និងការកែសន្លឹកកិច្ចការប្រកបដោយភាពយុត្តិធម៌ និងតម្លាភាព'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.១',
    expectedResultKh: 'ការលើកកម្ពស់សេវាថែទាំសុខភាពបឋម',
    expectedResultEn: 'Promotion and delivery of primary health care services',
    activitiesKh: [
      'មានសៀវភៅសុខភាពសិស្ស និងសហការជាមួយមណ្ឌលសុខភាពដើម្បីពិនិត្យសុខភាពសិស្ស និងចាក់វ៉ាក់សាំង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_2',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.២',
    expectedResultKh: 'សាលារៀនបានរៀបចំកម្មវិធីពិនិត្យសុខភាពសិស្ស',
    expectedResultEn: 'School organizes periodic student health checkup campaigns',
    activitiesKh: [
      'សហការជាមួយមណ្ឌលសុខភាពដើម្បីពិនិត្យសុខភាពសិស្ស និងចាក់វ៉ាក់សាំង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_3',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៣',
    expectedResultKh: 'ការលើកកម្ពស់ទឹកស្អាត និងអនាម័យ',
    expectedResultEn: 'Promotion of clean water, sanitation, and hygiene (WASH)',
    activitiesKh: [
      'មានវេនសម្អាត និងការអនុវត្តអនាម័យជាប្រចាំដោយក្រុមប្រឹក្សាកុមារ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_4',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៤',
    expectedResultKh: 'ការលើកកម្ពស់សុវត្ថិភាពចំណីអាហារ និងអាហារប្រកបដោយសុខភាព',
    expectedResultEn: 'Enforcement of food safety standards and nutritious school snacks',
    activitiesKh: [
      'មានកិច្ចសន្យា និងការលក់ដូរចំណីអាហារមានសុវត្តិភាព'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_5',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៥',
    expectedResultKh: 'ការអនុវត្តមុខវិជ្ជាអប់រំសុខភាព',
    expectedResultEn: 'Implementation of health and hygiene education in curriculum',
    activitiesKh: [
      'មានកម្មវិធីបង្រៀន និងបានបញ្ចូលទៅក្នុងកាលវិភាគ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_6',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៦',
    expectedResultKh: 'ការលើកកម្ពស់បរិស្ថានស្អាត បៃតង សុវត្ថិភាព អនាម័យ និងមេត្រីភាព',
    expectedResultEn: 'Clean, green, child-friendly, safe, and welcoming school environment',
    activitiesKh: [
      'រៀបចំកន្លែងលាងដៃ ធុងទឹកស្អាត បន្ទប់ទឹកស្អាត និងហាមឃាត់ការលក់ចំណីអាហារគ្មានស្លាកសញ្ញា ឬខូចគុណភាពក្នុងសាលា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_7',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៧',
    expectedResultKh: 'ការរក្សាសន្តិសុខ សណ្ដាប់ធ្នាប់ ការការពារកុមារ ការបង្ការគ្រោះមហន្តរាយនានា',
    expectedResultEn: 'Child protection protocols, safety security, and disaster risk reduction',
    activitiesKh: [
      'រៀបចំកន្លែងលាងដៃ ធុងទឹកស្អាត បន្ទប់ទឹកស្អាត និងហាមឃាត់ការលក់ចំណីអាហារគ្មានស្លាកសញ្ញា ឬខូចគុណភាពក្នុងសាលា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_5_8',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 5,
    sectionTitleKh: '៥. ការលើកកម្ពស់សុខភាពសិក្សា និងអាហារូបត្ថម្ភរបស់សិស្ស',
    sectionTitleEn: '5. School Health, WASH, and Nutrition Promotion',
    code: '៥.៨',
    expectedResultKh: 'សាលារៀនបានអនុវត្តសកម្មភាពអប់រំកាយនិងកីឡា',
    expectedResultEn: 'Regular physical education, morning exercises, and sports activities',
    activitiesKh: [
      'រៀបចំសកម្មភាពអនាម័យថ្ងៃសុក្រ បៃតង និងសកម្មភាពកីឡាពេលព្រឹក ឬក្រៅម៉ោង'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_6_1',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
    sectionTitleEn: '6. School Infrastructure Development',
    code: '៦.១',
    expectedResultKh: 'សាលារៀនមានបណ្តាញអគ្គិសនី បំពាក់អ៊ីនធើណិត',
    expectedResultEn: 'School equipped with stable electricity and high-speed internet',
    activitiesKh: [
      'កៀរគររកជំនួយពីសប្បុរសជន អាជ្ញាធរ និងអង្គការដៃគូ ដើម្បីបំពាក់សម្ភារៈបច្ចេកវិទ្យា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_6_2',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
    sectionTitleEn: '6. School Infrastructure Development',
    code: '៦.២',
    expectedResultKh: 'ភាគរយបន្ទប់រៀនបំពាក់ឧបករណ៍សិក្សាទំនើប (LCD, Smart TV, Smart Board)',
    expectedResultEn: 'Percentage of classrooms equipped with modern LCD/Smart TV/Interactive Boards',
    activitiesKh: [
      'កៀរគររកជំនួយពីសប្បុរសជន អាជ្ញាធរ និងអង្គការដៃគូ ដើម្បីបំពាក់សម្ភារៈបច្ចេកវិទ្យា (Smart TV, Internet) និងជួសជុលហេដ្ឋារចនាសម្ព័ន្ធសាលារៀន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_6_3',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
    sectionTitleEn: '6. School Infrastructure Development',
    code: '៦.៣',
    expectedResultKh: 'សាលារៀនមានបណ្ណាល័យ',
    expectedResultEn: 'Functioning school library with operational reading schedule',
    activitiesKh: [
      'រៀបចំកាលវិភាគប្រើប្រាស់បន្ទប់បណ្ណាល័យ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_6_4',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
    sectionTitleEn: '6. School Infrastructure Development',
    code: '៦.៤',
    expectedResultKh: 'សាលារៀនមានបន្ទប់កុំព្យូទ័រសម្រាប់សិស្សរៀន',
    expectedResultEn: 'Dedicated ICT computer lab with active practical sessions for students',
    activitiesKh: [
      'រៀបចំកាលវិភាគប្រើប្រាស់បន្ទប់កុំព្យូទ័រ'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std4_6_5',
    standardNumber: 4,
    standardTitleKh: 'ស្តង់ដាទី៤៖ ដំណើរការប្រតិបត្តិ និងរដ្ឋបាលសាលារៀន',
    standardTitleEn: 'Standard 4: School Operation and Administration',
    sectionNumber: 6,
    sectionTitleKh: '៦. ការអភិវឌ្ឍហេដ្ឋារចនាសម្ព័ន្ធអប់រំ',
    sectionTitleEn: '6. School Infrastructure Development',
    code: '៦.៥',
    expectedResultKh: 'សាលារៀនមានទីលានកីឡារួមមាន៖ តារាបាល់ទះ បាល់ទាត់ បាល់បោះ វាយសី...',
    expectedResultEn: 'School sports facilities (Volleyball, Football, Basketball, Badminton pitch)',
    activitiesKh: [
      'រៀបចំទីលានបាល់ទាត់ និងមានសកម្មភាពជាប្រចាំ'
    ],
    maxScore: 5,
    weight: 1
  },

  // ==========================================
  // ស្តង់ដាទី៥៖ គណនេយ្យភាព
  // ==========================================
  {
    id: 'std5_1_1',
    standardNumber: 5,
    standardTitleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    standardTitleEn: 'Standard 5: Accountability',
    sectionNumber: 1,
    sectionTitleKh: '១. វេទិកាសាធារណៈ',
    sectionTitleEn: '1. Public Forums and Townhalls',
    code: '១.១',
    expectedResultKh: 'សាលារៀនរៀបចំកម្មវិធីជួបប្រជុំជាមួយមាតាបិតា អ្នកអាណាព្យាបាលសិស្ស និងសហគមន៍',
    expectedResultEn: 'Annual and semi-annual public forums for school accountability and stakeholder voice',
    activitiesKh: [
      'រៀបចំវេទិកាសាធារណៈប្រចាំឆ្នាំ ឬប្រចាំឆមាស ដើម្បីរបាយការណ៍ពីសមិទ្ធផលការងារ ថវិកា និងបញ្ហាប្រឈមរបស់សាលារៀន ព្រមទាំងបើកទូលាយឱ្យមាតាបិតា និងសហគមន៍ផ្តល់មតិយោបល់ និងសំណូមពរនានា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std5_2_1',
    standardNumber: 5,
    standardTitleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    standardTitleEn: 'Standard 5: Accountability',
    sectionNumber: 2,
    sectionTitleKh: '២. ការផ្សាយព័ត៌មានជាសាធារណៈ',
    sectionTitleEn: '2. Public Information Disclosure',
    code: '២.១',
    expectedResultKh: 'លទ្ធផលតេស្តវាយតម្លៃស្តង់ដា និងព័ត៌មាននានាត្រូវបានអនុម័តដោយ គ.គ.ស និង/ឬ បិទផ្សាយជាសាធារណៈ',
    expectedResultEn: 'Evaluation scores, finance reports, and school metrics officially posted on public boards',
    activitiesKh: [
      'បង្កើតក្តារខៀន ឬកន្លែងបិទផ្សាយព័ត៌មាន (Notice Board) នៅមុខទីចាត់ការសាលា ដើម្បីបង្ហាញពីរបាយការណ៍ហិរញ្ញវត្ថុ ស្ថិតិសិស្ស និងលទ្ធផលតេស្តវាយតម្លៃស្តង់ដា ដោយមានការពិនិត្យ និងអនុម័តពីគណៈកម្មការគ្រប់គ្រងសាលារៀន (គ.គ.ស.) ជាមុន'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std5_3_1',
    standardNumber: 5,
    standardTitleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    standardTitleEn: 'Standard 5: Accountability',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
    sectionTitleEn: '3. National Support and Cluster Training',
    code: '៣.១',
    expectedResultKh: 'ចំនួនដងនាយកសាលា និងនាយករង បានទទួលការហ្វឹកហាត់អនុវត្តស្តង់ដាសាលារៀនគំរូពីនាយកសាលាផ្សេងៗឬមកពីថ្នាក់លើ',
    expectedResultEn: 'Model School Standard training frequency for Principal and Deputy Principal',
    activitiesKh: [
      'ស្នើសុំ ឬចូលរួមវគ្គបណ្តុះបណ្តាល និងសិក្ខាសាលាស្ដីពីការអនុវត្តស្តង់ដាសាលារៀនគំរូដែលរៀបចំដោយការិយាល័យអប់រំ មន្ទីរអប់រំ ឬចូលរួមក្នុងកម្មវិធីទស្សនកិច្ចសិក្សាស្វែងយល់ពីបទពិសោធន៍នៅសាលារៀនគំរូផ្សេងទៀត'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std5_3_2',
    standardNumber: 5,
    standardTitleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    standardTitleEn: 'Standard 5: Accountability',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
    sectionTitleEn: '3. National Support and Cluster Training',
    code: '៣.២',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនបានទទួលការហ្វឹកហាត់ការអនុវត្តកញ្ចប់សម្ភារៈអំណាន និងគណិតវិទ្យាថ្នាក់ដំបូង ឬវិធីសាស្ត្របង្រៀនភាសាខ្មែរ ឬគណិតវិទ្យា',
    expectedResultEn: 'Percentage of teachers trained on early grade reading and math packages',
    activitiesKh: [
      'រៀបចំវគ្គបណ្តុះបណ្តាលផ្ទៃក្នុងសាលា (School-based Training) ដោយចាត់តាំងគ្រូស្នូលដែលធ្លាប់បានtrainingពីថ្នាក់លើ មកចែករំលែកចំណេះដឹង និងបច្ចេកទេសបង្រៀនថ្មីៗដល់គ្រូបង្រៀនទូទាំងសាលា'
    ],
    maxScore: 5,
    weight: 1
  },
  {
    id: 'std5_3_3',
    standardNumber: 5,
    standardTitleKh: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព',
    standardTitleEn: 'Standard 5: Accountability',
    sectionNumber: 3,
    sectionTitleKh: '៣. ការទទួលបានការគាំទ្រពីថ្នាក់ជាតិ',
    sectionTitleEn: '3. National Support and Cluster Training',
    code: '៣.៣',
    expectedResultKh: 'ភាគរយគ្រូបង្រៀនបំពេញទស្សនៈកិច្ចសិក្សា ទៅសាលាផ្សេងៗក្នុងមួយឆ្នាំ',
    expectedResultEn: 'Percentage of teachers completing peer study visits to cluster schools per year',
    activitiesKh: [
      'រៀបចំផែនការទស្សនកិច្ចសិក្សាសហការគ្នារវាងសាលារៀនក្នុងបណ្តុំសាលាគោលដៅ (Cluster Schools) ដើម្បីឱ្យគ្រូអាចចូលរួមសង្កេតការណ៍បង្រៀនជាក់ស្តែង និងផ្លាស់ប្តរបទពិសោធន៍គរុកោសល្យល្អៗពីគ្នាទៅវិញទៅមក'
    ],
    maxScore: 5,
    weight: 1
  }
];

export const TOTAL_ACTIVITIES_COUNT = ALL_INDICATORS.reduce(
  (sum, ind) => sum + ind.activitiesKh.length, 
  0
);

export function calculateSchoolPerformanceLevel(overallPercentage: number): {
  levelKh: string;
  levelEn: string;
  badgeColor: string;
  isModelSchool: boolean;
} {
  if (overallPercentage >= 90) {
    return {
      levelKh: 'សាលារៀនគំរូ (កម្រិតឆ្នើម)',
      levelEn: 'Model School (Exemplary)',
      badgeColor: 'emerald',
      isModelSchool: true
    };
  } else if (overallPercentage >= 75) {
    return {
      levelKh: 'សាលារៀនកម្រិតល្អប្រសើរ',
      levelEn: 'Advanced School',
      badgeColor: 'blue',
      isModelSchool: false
    };
  } else if (overallPercentage >= 60) {
    return {
      levelKh: 'សាលារៀនកម្រិតល្អ',
      levelEn: 'Proficient School',
      badgeColor: 'amber',
      isModelSchool: false
    };
  } else if (overallPercentage >= 40) {
    return {
      levelKh: 'សាលារៀនកម្រិតមធ្យម (កំពុងអភិវឌ្ឍ)',
      levelEn: 'Developing School',
      badgeColor: 'orange',
      isModelSchool: false
    };
  } else {
    return {
      levelKh: 'សាលារៀនកម្រិតមូលដ្ឋាន (ត្រូវការកែលម្អ)',
      levelEn: 'Basic School (Needs Improvement)',
      badgeColor: 'rose',
      isModelSchool: false
    };
  }
}
