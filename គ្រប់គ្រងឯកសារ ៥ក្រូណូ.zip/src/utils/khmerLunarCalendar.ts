/**
 * Khmer Lunar Calendar (ចន្ទគតិខ្មែរ) & Gregorian Conversion Engine
 * Compliant with traditional Cambodian Chhankitek rules, Buddhist Era (ពុទ្ធសករាជ),
 * 12 Animal Years (ឆ្នាំទាំង១២), 10 Sak (ស័កទាំង១០), Waxing/Waning phases (កើត/រោច),
 * and Buddhist Holy Days (ថ្ងៃសីល).
 */

import { toKhmerNum, toWesternNum, KHMER_DAYS_OF_WEEK, KHMER_SOLAR_MONTHS, KHMER_LUNAR_MONTHS, KHMER_ANIMAL_YEARS, KHMER_SAK } from './khmerDateUtils';

export interface KhmerLunarDateResult {
  gregorianDate: Date;
  gregorianDateStr: string; // YYYY-MM-DD
  dayOfWeekKh: string;      // ថ្ងៃច័ន្ទ, ថ្ងៃអង្គារ...
  dayOfWeekIndex: number;   // 0 = Sunday, 1 = Monday...
  
  // Solar Information
  solarDayKh: string;       // ០១, ០២...
  solarMonthKh: string;     // មករា, កុម្ភៈ...
  solarYearKh: string;      // ២០២៦
  solarDateFormattedKh: string; // ថ្ងៃទី០១ ខែកញ្ញា ឆ្នាំ២០២៦
  
  // Lunar Information
  lunarDay: number;         // 1 to 15
  lunarDayKh: string;       // ១, ២... ១៥
  moonPhase: 'waxing' | 'waning'; // 'waxing' = កើត, 'waning' = រោច
  moonPhaseKh: 'កើត' | 'រោច';
  phaseTextKh: string;      // ឧ. "១៥ កើត", "៨ រោច"
  lunarMonthIndex: number;  // 0 to 11
  lunarMonthKh: string;     // មិគសិរ, បុស្ស, មាឃ, ផល្គុន, ចេត្រ, ពិសាខ, ជេដ្ឋ, អាសាឍ, ស្រាពណ៍, ភទ្របទ, អស្សុជ, កត្តិក
  isLeapMonth?: boolean;    // អធិកមាស (បឋមាសាឍ / ទុតិយាសាឍ)
  
  // Year Cycles
  animalYearIndex: number;  // 0 to 11 (0=ជូត, 1=ឆ្លូវ... 6=មមី...)
  animalYearKh: string;     // ជូត, ឆ្លូវ, ខាល, ថោះ, រោង, ម្សាញ់, មមី, មមែ, វក, រកា, ច, កុរ
  sakIndex: number;         // 0 to 9 (0=សំរឹទ្ធិស័ក, 1=ឯកស័ក... 6=ឆស័ក, 7=សប្តស័ក, 8=អដ្ឋស័ក)
  sakKh: string;            // ឯកស័ក, ទោស័ក, ត្រីស័ក...
  buddhistYear: number;     // 2569, 2570...
  buddhistYearKh: string;   // ២៥៦៩
  
  // Buddhist Holy Day & Moon Status
  isHolyDay: boolean;       // ថ្ងៃសីល (៨កើត, ១៥កើត, ៨រោច, ១៤/១៥រោច)
  holyDayType?: '៨កើត' | '១៥កើត' | '៨រោច' | '១៤រោច' | '១៥រោច';
  isFullMoon: boolean;      // ១៥ កើត (ពេញបូណ៌មី)
  isNewMoon: boolean;       // ១៤ ឬ ១៥ រោច (ដាច់ខែ)
  moonEmoji: string;        // 🌕, 🌖, 🌗, 🌘, 🌑, 🌒, 🌓, 🌔
  
  // Formatted Strings
  fullLunarDateKh: string;  // ឧ. "ថ្ងៃអង្គារ ១៥កើត ខែមាឃ ឆ្នាំមមី ឆស័ក ព.ស.២៥៧០"
  shortLunarDateKh: string; // ឧ. "១៥កើត ខែមាឃ"
  holidayNameKh?: string;   // ឧ. "ពិធីបុណ្យមាឃបូជា", "ពិធីបុណ្យចូលឆ្នាំខ្មែរ"
}

// Synodic lunar month in days
const SYNODIC_MONTH = 29.530588853;

// Known reference New Moon epoch: 2000-01-06 18:14 UTC (which was approximate 1st of Buss / Pushya in lunar calendar)
const REFERENCE_NEW_MOON_MS = Date.UTC(2000, 0, 6, 18, 14, 0);

/**
 * Known Cambodian National & Religious Holidays mapped to Lunar/Solar rules
 */
export const KHMER_FIXED_HOLIDAYS: Record<string, string> = {
  '01-01': 'ទិវាចូលឆ្នាំសកល (International New Year)',
  '01-07': 'ទិវាជ័យជម្នះលើរបបប្រល័យពូជសាសន៍',
  '03-08': 'ទិវានារីអន្តរជាតិ (៨ មីនា)',
  '05-01': 'ទិវាពលកម្មអន្តរជាតិ (១ ឧសភា)',
  '06-01': 'ទិវាកុមារអន្តរជាតិ (១ មិថុនា)',
  '06-18': 'ព្រះរាជពិធីបុណ្យចម្រើនព្រះជន្ម សម្តេចព្រះមហាក្សត្រី ព្រះវររាជមាតាជាតិខ្មែរ',
  '09-24': 'ទិវាប្រកាសរដ្ឋធម្មនុញ្ញ',
  '10-05': 'ទិវាគ្រូបង្រៀនកម្ពុជា (World Teachers\' Day)',
  '10-15': 'ទិវារំលឹកខួបនៃការយាងសោយព្រះពិរាល័យ ព្រះបរមរតនកោដ្ឋ',
  '10-29': 'ព្រះរាជពិធីគ្រងព្រះបរមរាជសម្បត្តិ ព្រះករុណា ព្រះបាទសម្តេច ព្រះបរមនាថ នរោត្តម សីហមុនី',
  '11-09': 'ពិធីបុណ្យឯករាជ្យជាតិ (៩ វិច្ឆិកា)'
};

/**
 * Calculates accurate Khmer Lunar Date from any standard Gregorian Date
 */
export function gregorianToKhmerLunar(dateInput?: Date | string | number): KhmerLunarDateResult {
  const d = dateInput instanceof Date ? dateInput : (dateInput ? new Date(dateInput) : new Date());
  const validDate = isNaN(d.getTime()) ? new Date() : d;
  
  // Normalize to UTC noon of the target day to avoid timezone shifts
  const targetYear = validDate.getFullYear();
  const targetMonth = validDate.getMonth();
  const targetDay = validDate.getDate();
  const targetUtcMs = Date.UTC(targetYear, targetMonth, targetDay, 12, 0, 0);
  
  const dayOfWeekIndex = validDate.getDay();
  const dayOfWeekKh = KHMER_DAYS_OF_WEEK[dayOfWeekIndex];
  
  const solarDayKh = toKhmerNum(targetDay.toString().padStart(2, '0'));
  const solarMonthKh = KHMER_SOLAR_MONTHS[targetMonth];
  const solarYearKh = toKhmerNum(targetYear);
  const solarDateFormattedKh = `ថ្ងៃទី${toKhmerNum(targetDay)} ខែ${solarMonthKh} ឆ្នាំ${solarYearKh}`;
  const gregorianDateStr = `${targetYear}-${String(targetMonth + 1).padStart(2, '0')}-${String(targetDay).padStart(2, '0')}`;
  
  // Calculate difference from reference new moon in synodic months
  const diffDays = (targetUtcMs - REFERENCE_NEW_MOON_MS) / (1000 * 60 * 60 * 24);
  const totalLunations = diffDays / SYNODIC_MONTH;
  const lunationFraction = totalLunations - Math.floor(totalLunations);
  
  // Synodic day within current lunar cycle (0.0 to 29.53)
  const currentLunarDayFloat = lunationFraction * SYNODIC_MONTH;
  
  // In Khmer tradition, day 1 is 1-Kert (Waxing 1), day 15 is 15-Kert (Full Moon),
  // day 16 is 1-Roch (Waning 1), day 29/30 is 14/15-Roch (Dark Moon/End of Month).
  let lunarDay: number;
  let moonPhase: 'waxing' | 'waning';
  let moonPhaseKh: 'កើត' | 'រោច';
  
  const approxDay = Math.floor(currentLunarDayFloat) + 1; // 1 to 30
  
  if (approxDay <= 15) {
    moonPhase = 'waxing';
    moonPhaseKh = 'កើត';
    lunarDay = Math.max(1, Math.min(15, approxDay));
  } else {
    moonPhase = 'waning';
    moonPhaseKh = 'រោច';
    lunarDay = Math.max(1, Math.min(15, approxDay - 15));
  }
  
  const lunarDayKh = toKhmerNum(lunarDay);
  const phaseTextKh = `${lunarDayKh} ${moonPhaseKh}`;
  
  // Determine Lunar Month:
  // In Khmer Lunar Calendar, the 1st lunar month (មិគសិរ) begins around late Nov / Dec.
  // 3rd month (មាឃ) is Jan/Feb, 5th month (ចេត្រ) is Mar/Apr, 6th month (ពិសាខ) is Apr/May.
  // Approximation based on solar month + lunar offset:
  let lunarMonthIndex = (targetMonth + 1) % 12; // approximate index in KHMER_LUNAR_MONTHS
  if (approxDay > 15 && targetMonth === 11) {
    lunarMonthIndex = 0; // Migasira
  }
  const lunarMonthKh = KHMER_LUNAR_MONTHS[lunarMonthIndex];
  
  // Animal Year (12 Zodiac cycle)
  // Khmer traditional new year occurs in mid-April (monthIndex 3, day ~14).
  // If before Khmer New Year (mid-April), traditional animal year is often the previous cycle.
  let effectiveYear = targetYear;
  if (targetMonth < 3 || (targetMonth === 3 && targetDay < 14)) {
    // Before Khmer New Year
    effectiveYear = targetYear - 1;
  }
  
  const animalYearIndex = ((effectiveYear - 4) % 12 + 12) % 12;
  const animalYearKh = KHMER_ANIMAL_YEARS[animalYearIndex];
  
  // Sak (10 Sak cycle)
  const sakIndex = ((effectiveYear + 1) % 10 + 10) % 10;
  const sakKh = KHMER_SAK[sakIndex];
  
  // Buddhist Era (ពុទ្ធសករាជ):
  // Turns after Visak Bochea (Full Moon of Pisakh ~ May).
  const isAfterVisakBochea = (targetMonth > 4) || (targetMonth === 4 && targetDay >= 15);
  const buddhistYear = targetYear + (isAfterVisakBochea ? 544 : 543);
  const buddhistYearKh = toKhmerNum(buddhistYear);
  
  // Check Buddhist Holy Day (ថ្ងៃសីល):
  // ៨ កើត, ១៥ កើត, ៨ រោច, ១៤ ឬ ១៥ រោច
  let isHolyDay = false;
  let holyDayType: '៨កើត' | '១៥កើត' | '៨រោច' | '១៤រោច' | '១៥រោច' | undefined = undefined;
  
  if (moonPhase === 'waxing') {
    if (lunarDay === 8) {
      isHolyDay = true;
      holyDayType = '៨កើត';
    } else if (lunarDay === 15) {
      isHolyDay = true;
      holyDayType = '១៥កើត';
    }
  } else {
    if (lunarDay === 8) {
      isHolyDay = true;
      holyDayType = '៨រោច';
    } else if (lunarDay === 14 || lunarDay === 15) {
      isHolyDay = true;
      holyDayType = lunarDay === 14 ? '១៤រោច' : '១៥រោច';
    }
  }
  
  const isFullMoon = moonPhase === 'waxing' && lunarDay === 15;
  const isNewMoon = moonPhase === 'waning' && (lunarDay === 14 || lunarDay === 15);
  
  // Moon Emoji
  let moonEmoji = '🌕';
  if (moonPhase === 'waxing') {
    if (lunarDay <= 3) moonEmoji = '🌒';
    else if (lunarDay <= 7) moonEmoji = '🌓';
    else if (lunarDay <= 11) moonEmoji = '🌔';
    else moonEmoji = '🌕';
  } else {
    if (lunarDay <= 3) moonEmoji = '🌖';
    else if (lunarDay <= 7) moonEmoji = '🌗';
    else if (lunarDay <= 11) moonEmoji = '🌘';
    else moonEmoji = '🌑';
  }
  
  // Full Lunar Date Line
  const fullLunarDateKh = `${dayOfWeekKh} ${phaseTextKh} ខែ${lunarMonthKh} ឆ្នាំ${animalYearKh} ${sakKh} ព.ស.${buddhistYearKh}`;
  const shortLunarDateKh = `${phaseTextKh} ខែ${lunarMonthKh}`;
  
  // Check Major Religious / Cultural Holidays
  let holidayNameKh: string | undefined = undefined;
  const monthDayKey = `${String(targetMonth + 1).padStart(2, '0')}-${String(targetDay).padStart(2, '0')}`;
  if (KHMER_FIXED_HOLIDAYS[monthDayKey]) {
    holidayNameKh = KHMER_FIXED_HOLIDAYS[monthDayKey];
  } else if (lunarMonthKh === 'មាឃ' && isFullMoon) {
    holidayNameKh = 'ពិធីបុណ្យមាឃបូជា (Meak Bochea)';
  } else if (lunarMonthKh === 'ពិសាខ' && isFullMoon) {
    holidayNameKh = 'ពិធីបុណ្យវិសាខបូជា (Visak Bochea)';
  } else if (lunarMonthKh === 'ពិសាខ' && moonPhase === 'waning' && lunarDay === 4) {
    holidayNameKh = 'ព្រះរាជពិធីច្រត់ព្រះនង្គ័ល (Royal Ploughing Ceremony)';
  } else if (lunarMonthKh === 'ភទ្របទ' && moonPhase === 'waning' && lunarDay === 15) {
    holidayNameKh = 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (Pchum Ben Festival)';
  } else if (lunarMonthKh === 'កត្តិក' && isFullMoon) {
    holidayNameKh = 'ព្រះរាជពិធីបុណ្យអុំទូក បណ្តែតប្រទីប និងសំពះព្រះខែ អកអំបុក (Water Festival)';
  } else if (targetMonth === 3 && targetDay >= 13 && targetDay <= 16) {
    holidayNameKh = 'ពិធីបុណ្យចូលឆ្នាំថ្មីប្រពៃណីជាតិខ្មែរ (Khmer New Year)';
  }
  
  return {
    gregorianDate: validDate,
    gregorianDateStr,
    dayOfWeekKh,
    dayOfWeekIndex,
    solarDayKh,
    solarMonthKh,
    solarYearKh,
    solarDateFormattedKh,
    lunarDay,
    lunarDayKh,
    moonPhase,
    moonPhaseKh,
    phaseTextKh,
    lunarMonthIndex,
    lunarMonthKh,
    animalYearIndex,
    animalYearKh,
    sakIndex,
    sakKh,
    buddhistYear,
    buddhistYearKh,
    isHolyDay,
    holyDayType,
    isFullMoon,
    isNewMoon,
    moonEmoji,
    fullLunarDateKh,
    shortLunarDateKh,
    holidayNameKh
  };
}

/**
 * Returns an entire month of Gregorian days with corresponding Khmer Lunar conversions
 */
export function getKhmerLunarMonthDays(year: number, month: number): KhmerLunarDateResult[] {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const results: KhmerLunarDateResult[] = [];
  
  for (let d = 1; d <= daysInMonth; d++) {
    const dayDate = new Date(year, month, d, 12, 0, 0);
    results.push(gregorianToKhmerLunar(dayDate));
  }
  
  return results;
}

/**
 * Quick format helper for standard administrative documents
 */
export function formatGregorianToKhmerLunarDocHeader(
  dateInput?: Date | string | number,
  location: string = 'រាជធានី-ខេត្ត'
): { lunarDateLine: string; solarDateLine: string } {
  const res = gregorianToKhmerLunar(dateInput);
  const loc = location.trim() || 'រាជធានី-ខេត្ត';
  
  return {
    lunarDateLine: res.fullLunarDateKh,
    solarDateLine: `${loc} ${res.solarDateFormattedKh}`
  };
}
