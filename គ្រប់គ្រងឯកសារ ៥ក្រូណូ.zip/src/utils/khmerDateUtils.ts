/**
 * Khmer Official Administrative Date & Numerals Utilities
 * Compliant with national MoEYS formatting, Royal header, and Lunar/Solar calendar standards.
 */

// Convert Western digits (0-9) to Khmer digits (០-៩)
export function toKhmerNum(input: number | string | undefined | null): string {
  if (input === undefined || input === null || input === '') return '';
  const str = String(input);
  const khmerDigits = ['០', '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩'];
  return str.replace(/[0-9]/g, (digit) => khmerDigits[parseInt(digit, 10)]);
}

// Convert Khmer digits (០-៩) back to Western digits (0-9)
export function toWesternNum(input: string): string {
  if (!input) return '';
  const westernDigits: Record<string, string> = {
    '០': '0', '១': '1', '២': '2', '៣': '3', '៤': '4',
    '៥': '5', '៦': '6', '៧': '7', '៨': '8', '៩': '9'
  };
  return input.replace(/[០-៩]/g, (digit) => westernDigits[digit] || digit);
}

export const KHMER_DAYS_OF_WEEK = [
  'ថ្ងៃអាទិត្យ',
  'ថ្ងៃច័ន្ទ',
  'ថ្ងៃអង្គារ',
  'ថ្ងៃពុធ',
  'ថ្ងៃព្រហស្បតិ៍',
  'ថ្ងៃសុក្រ',
  'ថ្ងៃសៅរ៍'
];

export const KHMER_SOLAR_MONTHS = [
  'មករា', 'កុម្ភៈ', 'មីនា', 'មេសា', 'ឧសភា', 'មិថុនា',
  'កក្កដា', 'សីហា', 'កញ្ញា', 'តុលា', 'វិច្ឆិកា', 'ធ្នូ'
];

export const KHMER_LUNAR_MONTHS = [
  'មិគសិរ', 'បុស្ស', 'មាឃ', 'ផល្គុន', 'ចេត្រ', 'ពិសាខ',
  'ជេដ្ឋ', 'អាសាឍ', 'ស្រាពណ៍', 'ភទ្របទ', 'អស្សុជ', 'កត្តិក'
];

export const KHMER_ANIMAL_YEARS = [
  'ជូត', 'ឆ្លូវ', 'ខាល', 'ថោះ', 'រោង', 'ម្សាញ់',
  'មមី', 'មមែ', 'វក', 'រកា', 'ច', 'កុរ'
];

export const KHMER_SAK = [
  'ឯកស័ក', 'ទោស័ក', 'ត្រីស័ក', 'ចត្វាស័ក', 'បញ្ចស័ក',
  'ឆស័ក', 'សប្តស័ក', 'អដ្ឋស័ក', 'នព្វស័ក', 'សំរឹទ្ធិស័ក'
];

/**
 * Calculates accurate Khmer Buddhist Era (ពុទ្ធសករាជ), Animal Year, Sak, and Lunar Date
 */
export function getKhmerLunarSolarDate(
  dateInput?: Date | string | number,
  location: string = 'រាជធានី-ខេត្ត'
): {
  lunarDateKh: string;
  solarDateKh: string;
  dayOfWeekKh: string;
  dayKh: string;
  monthKh: string;
  yearKh: string;
  buddhistYearKh: string;
  animalYearKh: string;
  sakKh: string;
  lunarMonthKh: string;
} {
  const d = dateInput ? new Date(dateInput) : new Date();
  const validDate = isNaN(d.getTime()) ? new Date() : d;

  const dayOfWeekIndex = validDate.getDay();
  const dayOfMonth = validDate.getDate();
  const monthIndex = validDate.getMonth();
  const fullYear = validDate.getFullYear();

  // Khmer Day of Week
  const dayOfWeekKh = KHMER_DAYS_OF_WEEK[dayOfWeekIndex];

  // Solar Date
  const dayKh = toKhmerNum(dayOfMonth);
  const monthKh = KHMER_SOLAR_MONTHS[monthIndex];
  const yearKh = toKhmerNum(fullYear);

  // Buddhist Era: In Cambodia, CE + 543 (or +544 depending on month after Visak Bochea)
  // For 2026: 2026 + 543 = 2569 or 2570
  const isAfterVisakBochea = monthIndex >= 4; // Approx May onwards
  const buddhistYear = fullYear + (isAfterVisakBochea ? 544 : 543);
  const buddhistYearKh = toKhmerNum(buddhistYear);

  // Animal Year (12 Zodiac cycle, 2024=រោង, 2025=ម្សាញ់, 2026=មមី, 2027=មមែ, 2028=វក...)
  // Formula: (year - 4) % 12: (2020-4)%12 = 0 (ជូត). 2025: (2025-4)%12 = 5 (ម្សាញ់), 2026: 6 (មមី)
  const animalYearIndex = (fullYear - 4) % 12;
  const animalYearKh = KHMER_ANIMAL_YEARS[(animalYearIndex + 12) % 12];

  // Sak (10 Sak cycle, year ending in 0=សំរឹទ្ធិស័ក, 1=ឯកស័ក, 2=ទោស័ក, 3=ត្រីស័ក, 4=ចត្វាស័ក, 5=បញ្ចស័ក, 6=ឆស័ក, 7=សប្តស័ក, 8=អដ្ឋស័ក, 9=នព្វស័ក)
  // (year + 7) % 10. E.g. 2025: (2025+7)%10 = 2 -> ត្រីស័ក or for BE 2569: (2569-1)%10 = 8 -> នព្វស័ក / សប្តស័ក
  const sakIndex = (fullYear + 1) % 10;
  const sakKh = KHMER_SAK[(sakIndex + 10) % 10];

  // Lunar Month approximation (Solar month to corresponding lunar month)
  const lunarMonthKh = KHMER_LUNAR_MONTHS[(monthIndex + 1) % 12];

  // Clean location string (remove "រាជធានី-ខេត្ត" placeholder if given real location)
  const loc = location?.trim() ? location : 'រាជធានី-ខេត្ត';

  // Format standard Lunar date line:
  // e.g. "ថ្ងៃសៅរ៍ ខែផល្គុន ឆ្នាំម្សាញ់ សប្តស័ក ព.ស.២៥៦៩"
  const lunarDateKh = `${dayOfWeekKh} ខែ${lunarMonthKh} ឆ្នាំ${animalYearKh} ${sakKh} ព.ស.${buddhistYearKh}`;

  // Format standard Solar date line:
  // e.g. "រោគ ថ្ងៃទី២៥ ខែមេសា ឆ្នាំ២០២៦" (or "ភ្នំស្រុក ថ្ងៃទី២៥ ខែមេសា ឆ្នាំ២០២៦")
  const solarDateKh = `${loc} ថ្ងៃទី${dayKh} ខែ${monthKh} ឆ្នាំ${yearKh}`;

  return {
    lunarDateKh,
    solarDateKh,
    dayOfWeekKh,
    dayKh,
    monthKh,
    yearKh,
    buddhistYearKh,
    animalYearKh,
    sakKh,
    lunarMonthKh
  };
}

/**
 * Strips redundant markdown headers (ព្រះរាជាណាចក្រកម្ពុជា) and signature tables
 * when the visual component renders dedicated NationalDocumentHeader and NationalDocumentFooter.
 */
export function cleanMarkdownBody(rawMarkdown: string): string {
  if (!rawMarkdown) return '';

  let cleaned = rawMarkdown;

  // Remove top royal header if present
  cleaned = cleaned.replace(/^#*\s*ព្រះរាជាណាចក្រកម្ពុជា[\s\S]*?(?:--+|===+|\*\*\*+)/i, '');
  cleaned = cleaned.replace(/^#*\s*ជាតិ\s*សាសនា\s*ព្រះមហាក្សត្រ[\s\S]*?(?:--+|===+|\*\*\*+)/i, '');
  cleaned = cleaned.replace(/^---+\s*xxx\s*---+/i, '');

  // 1. Remove bottom markdown tables containing signature terms
  cleaned = cleaned.replace(/(?:\n\s*(?:---+|\*\*\*+|___+)\s*)?\n*\|[^\n]*(?:បានឃើញ|បានពិនិត្យ|រៀបចំដោយ|ហត្ថលេខា|នាយកសាលា|គ\.គ\.ស|Tong Un)[^\n]*\|[\s\S]*$/i, '');

  // 2. Remove bottom freeform signature blocks and lines (e.g. *នាយកសាលារៀន*, *(ហត្ថលេខា)*, បានឃើញ និងឯកភាព...)
  cleaned = cleaned.replace(/(?:\n\s*(?:---+|\*\*\*+|___+)\s*)?\n*(?:(?:\*|_|#|\s)*(?:បានឃើញ\s*និងឯកភាព|បានពិនិត្យ\s*និងយល់ព្រម|រៀបចំដោយ|នាយកសាលារៀន|ប្រធានគណៈកម្មការ|អ្នកទទួលបន្ទុក|អ្នកធ្វើរបាយការណ៍|\(ហត្ថលេខា)(?:\*|_|#|\s)*)[\s\S]*$/i, '');

  // 3. Remove trailing divider lines and whitespace
  cleaned = cleaned.replace(/(?:\n\s*(?:---+|\*\*\*+|___+)\s*)+$/i, '');

  return cleaned.trim();
}

/**
 * Standard MoEYS Cambodian National Header Component
 */
export interface NationalHeaderProps {
  administrationLine1?: string; // e.g. "រដ្ឋបាលស្រុកភ្នំស្រុក" ឬ "មន្ទីរអប់រំ យុវជន និងកីឡា..."
  administrationLine2?: string; // e.g. "ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក"
  administrationLine3?: string; // e.g. "កម្រងស្ថានីយស្រែល្អ"
  administrationLine4?: string; // e.g. "សាលាបឋមសិក្សា រោគ"
  documentNumber?: string;       // e.g. "លេខ៖ ០២៤/២៦ របក.សរ"
  schoolName?: string;
  province?: string;
  district?: string;
  cluster?: string;
}

/**
 * Standard MoEYS Cambodian National Footer Component
 * Left: បានឃើញ និងឯកភាព / នាយកសាលា (with stamp spacing)
 * Right: Date Lines (LEFT-ALIGNED ALWAYS) / អ្នកធ្វើរបាយការណ៍
 */
export interface NationalFooterProps {
  lunarDateKh?: string;
  solarDateKh?: string;
  locationKh?: string;
  approverRole?: string;        // default "នាយកសាលា"
  approverName?: string;        // default "........................................"
  reporterRole?: string;        // default "អ្នកធ្វើរបាយការណ៍"
  reporterName?: string;        // author name
  hasSecondApprover?: boolean;  // for គ.គ.ស
  secondApproverRole?: string;
  secondApproverName?: string;
}
