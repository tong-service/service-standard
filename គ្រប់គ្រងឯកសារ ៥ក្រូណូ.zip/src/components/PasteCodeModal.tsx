import React, { useState } from 'react';
import { 
  X, 
  Clipboard, 
  Sparkles, 
  CheckCircle2, 
  Layers, 
  RefreshCw,
  Code,
  FileText
} from 'lucide-react';
import { ChronoDocumentType } from '../types/chrono';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';
import { useChrono } from '../context/ChronoContext';
import { useEvaluation } from '../context/EvaluationContext';

interface PasteCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultStandard?: number | null;
  defaultIndicatorId?: string | null;
}

export const PasteCodeModal: React.FC<PasteCodeModalProps> = ({
  isOpen,
  onClose,
  defaultStandard = 1,
  defaultIndicatorId
}) => {
  const { createFromPastedTextOrCode } = useChrono();
  const { lang } = useEvaluation();

  const [standardNumber, setStandardNumber] = useState<number>(defaultStandard || 1);
  const [indicatorId, setIndicatorId] = useState<string>(defaultIndicatorId || 'std1_1_1');
  const [titleKh, setTitleKh] = useState<string>('');
  const [rawContent, setRawContent] = useState<string>('');
  const [documentType, setDocumentType] = useState<ChronoDocumentType>('activity_report');
  const [formatWithAi, setFormatWithAi] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);

  const standardIndicators = ALL_INDICATORS.filter(ind => ind.standardNumber === standardNumber);

  if (!isOpen) return null;

  const handleStandardChange = (num: number) => {
    setStandardNumber(num);
    const firstInd = ALL_INDICATORS.find(ind => ind.standardNumber === num);
    if (firstInd) {
      setIndicatorId(firstInd.id);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rawContent || rawContent.trim() === '') return;

    setIsProcessing(true);
    try {
      await createFromPastedTextOrCode({
        titleKh: titleKh || 'ឯកសារបិទភ្ជាប់ (Pasted Content)',
        rawContent,
        standardNumber,
        indicatorId,
        documentType,
        formatWithAi
      });

      setSuccess(true);
      setTimeout(() => {
        setIsProcessing(false);
        onClose();
      }, 700);
    } catch (err) {
      console.error('Error creating pasted doc:', err);
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-400/30">
              <Clipboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                {lang === 'km' ? 'បិទភ្ជាប់អត្ថបទ / ទិន្នន័យ / Code (Paste Content)' : 'Paste Text / Code / Data to Chrono'}
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'km' ? 'បិទភ្ជាប់អត្ថបទព្រាង កំណត់ហេតុ ឬទិន្នន័យតារាង និងបំប្លែងដោយ AI' : 'Paste raw notes, minutes or code with optional AI formatting'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          
          {success && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'km' ? 'បានរក្សាទុកឯកសារក្នុងក្រូណូដោយជោគជ័យ!' : 'Document created successfully!'}</span>
            </div>
          )}

          {/* Chrono Classification */}
          <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                <span>{lang === 'km' ? 'ក្រូណូស្តង់ដា' : 'Standard Binder'}</span>
              </label>
              <select
                value={standardNumber}
                onChange={(e) => handleStandardChange(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 bg-white"
              >
                {STANDARDS_METADATA.map(s => (
                  <option key={s.number} value={s.number}>
                    ក្រូណូទី {s.number} ({s.shortKh})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {lang === 'km' ? 'សូចនាករ' : 'Indicator'}
              </label>
              <select
                value={indicatorId}
                onChange={(e) => setIndicatorId(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 bg-white"
              >
                {standardIndicators.map(ind => (
                  <option key={ind.id} value={ind.id}>
                    {ind.code} - {ind.expectedResultKh.substring(0, 30)}...
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Title & Document Type */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-800 mb-1">
                {lang === 'km' ? 'ចំណងជើងឯកសារ (ទុកទំនេរឱ្យ AI ដាក់ឱ្យ)' : 'Document Title'}
              </label>
              <input
                type="text"
                value={titleKh}
                onChange={(e) => setTitleKh(e.target.value)}
                placeholder="ចំណងជើងឯកសារភស្តុតាង..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                {lang === 'km' ? 'ប្រភេទឯកសារ' : 'Document Type'}
              </label>
              <select
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value as ChronoDocumentType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-semibold"
              >
                <option value="activity_report">របាយការណ៍សកម្មភាព</option>
                <option value="verification_report">របាយការណ៍ផ្ទៀងផ្ទាត់</option>
                <option value="meeting_minutes">កំណត់ហេតុប្រជុំ</option>
                <option value="moeys_decision">សេចក្តីសម្រេច/លិខិត</option>
                <option value="student_list">បញ្ជីទិន្នន័យសិស្ស</option>
                <option value="other">ផ្សេងៗ</option>
              </select>
            </div>
          </div>

          {/* Raw Text / Code Area */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Code className="w-4 h-4 text-purple-600" />
                <span>{lang === 'km' ? 'បិទភ្ជាប់អត្ថបទ ឬទិន្នន័យ (Paste Text / Raw Notes / Code Here)' : 'Paste Raw Content'} *</span>
              </label>
              <button
                type="button"
                onClick={async () => {
                  try {
                    const text = await navigator.clipboard.readText();
                    if (text) setRawContent(text);
                  } catch (e) {
                    console.warn('Clipboard read failed:', e);
                  }
                }}
                className="text-[11px] text-indigo-600 hover:text-indigo-800 font-bold"
              >
                {lang === 'km' ? '📋 ចុចដើម្បីបិទភ្ជាប់ (Paste)' : 'Paste from Clipboard'}
              </button>
            </div>
            <textarea
              required
              rows={9}
              value={rawContent}
              onChange={(e) => setRawContent(e.target.value)}
              placeholder="បិទភ្ជាប់អត្ថបទព្រាងពី Word, Excel, Telegram ឬសេចក្តីប្រកាសនៅទីនេះ..."
              className="w-full p-3.5 text-xs font-mono border border-slate-300 rounded-xl focus:ring-2 focus:ring-purple-500 leading-relaxed bg-slate-50/50"
            />
          </div>

          {/* AI Toggle Option */}
          <div className="p-3.5 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-purple-600 text-white rounded-lg">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-purple-950">
                  {lang === 'km' ? 'ប្រើ AI រៀបចំទម្រង់រដ្ឋបាលអប់រំស្វ័យប្រវត្ត' : 'Auto-format with AI Assistant'}
                </p>
                <p className="text-[11px] text-purple-700">
                  {lang === 'km' ? 'AI នឹងកែសម្រួលវេយ្យាករណ៍ បន្ថែមក្បាលលិខិតជាតិ និងរៀបចំកន្លែងចុះហត្ថលេខា' : 'Refines grammar, adds national headers & signature blocks'}
                </p>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={formatWithAi} 
                onChange={(e) => setFormatWithAi(e.target.checked)} 
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              {lang === 'km' ? 'បោះបង់' : 'Cancel'}
            </button>

            <button
              type="submit"
              disabled={!rawContent || isProcessing}
              className="px-5 py-2 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-md shadow-purple-600/20 disabled:opacity-50 flex items-center gap-1.5"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{lang === 'km' ? 'កំពុងដំណើរការ AI...' : 'Processing...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{lang === 'km' ? 'បង្កើតឯកសារក្នុងក្រូណូ' : 'Create in Chrono'}</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
