import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Star, 
  Edit3, 
  Search, 
  Filter, 
  FileText, 
  ExternalLink, 
  ChevronRight, 
  ChevronDown, 
  Layers, 
  Sparkles,
  LayoutGrid,
  Table as TableIcon,
  CheckSquare,
  Square,
  AlertCircle
} from 'lucide-react';
import { useEvaluation } from '../context/EvaluationContext';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';
import { IndicatorDefinition, IndicatorScore, ScoreStatus } from '../types';

interface StandardsTableProps {
  onSelectIndicator: (indicator: IndicatorDefinition) => void;
  lang: 'km' | 'en';
}

export const StandardsTable: React.FC<StandardsTableProps> = ({ onSelectIndicator, lang }) => {
  const { 
    evaluationRecord, 
    saveScore, 
    toggleActivityCheck, 
    autoSaveStatus,
    syncStatus,
    selectedStandard, 
    searchQuery, 
    setSearchQuery,
    statusFilter,
    setStatusFilter
  } = useEvaluation();

  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});

  const toggleRowExpanded = (id: string) => {
    setExpandedRows(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Filter indicators
  const filteredIndicators = useMemo(() => {
    return ALL_INDICATORS.filter((ind) => {
      // Standard filter
      if (selectedStandard !== null && ind.standardNumber !== selectedStandard) {
        return false;
      }

      // Status filter
      const score = evaluationRecord?.scores[ind.id];
      const status = score?.status || 'not_started';
      if (statusFilter !== 'all') {
        if (statusFilter === 'achieved' && status !== 'achieved' && status !== 'exceeded') return false;
        if (statusFilter === 'in_progress' && status !== 'in_progress') return false;
        if (statusFilter === 'not_started' && status !== 'not_started') return false;
      }

      // Search Query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesCode = ind.code.toLowerCase().includes(query);
        const matchesExpected = ind.expectedResultKh.toLowerCase().includes(query) || (ind.expectedResultEn?.toLowerCase() || '').includes(query);
        const matchesSection = ind.sectionTitleKh.toLowerCase().includes(query);
        const matchesActivities = ind.activitiesKh.some(a => a.toLowerCase().includes(query));
        if (!matchesCode && !matchesExpected && !matchesSection && !matchesActivities) {
          return false;
        }
      }

      return true;
    });
  }, [selectedStandard, statusFilter, searchQuery, evaluationRecord?.scores]);

  // Group by standard & section for organized tabular structure
  const groupedData = useMemo(() => {
    const groups: {
      standardMeta: typeof STANDARDS_METADATA[0];
      sections: {
        sectionTitleKh: string;
        sectionTitleEn: string;
        indicators: IndicatorDefinition[];
      }[];
    }[] = [];

    STANDARDS_METADATA.forEach((meta) => {
      if (selectedStandard !== null && meta.number !== selectedStandard) return;

      const indForStd = filteredIndicators.filter(i => i.standardNumber === meta.number);
      if (indForStd.length === 0) return;

      const sectionMap = new Map<string, IndicatorDefinition[]>();
      indForStd.forEach((ind) => {
        const key = ind.sectionTitleKh;
        if (!sectionMap.has(key)) sectionMap.set(key, []);
        sectionMap.get(key)!.push(ind);
      });

      const sections = Array.from(sectionMap.entries()).map(([secKh, inds]) => ({
        sectionTitleKh: secKh,
        sectionTitleEn: inds[0]?.sectionTitleEn || '',
        indicators: inds
      }));

      groups.push({
        standardMeta: meta,
        sections
      });
    });

    return groups;
  }, [filteredIndicators, selectedStandard]);

  const handleQuickScore = async (e: React.MouseEvent, indicatorId: string, starValue: number) => {
    e.stopPropagation();
    await saveScore(indicatorId, {
      score: starValue,
      percentage: starValue * 20
    });
  };

  const getStatusBadge = (status?: ScoreStatus) => {
    switch (status) {
      case 'exceeded':
      case 'achieved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>{lang === 'km' ? 'សម្រេចបាន' : 'Achieved'}</span>
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
            <span>{lang === 'km' ? 'កំពុងអនុវត្ត' : 'In Progress'}</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
            <Circle className="w-3 h-3 text-slate-400" />
            <span>{lang === 'km' ? 'មិនទាន់អនុវត្ត' : 'Not Started'}</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      
      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={lang === 'km' ? 'ស្វែងរកសូចនាករ ឬ ៧១ សកម្មភាព...' : 'Search indicators, results or activities...'}
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-slate-50/50 hover:bg-white transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-xs text-slate-400 hover:text-slate-600"
            >
              ✕
            </button>
          )}
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
          <span className="px-2 text-slate-500 font-medium hidden sm:inline">
            <Filter className="w-3 h-3 inline mr-1" />
            {lang === 'km' ? 'ស្ថានភាព' : 'Status'}:
          </span>
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
              statusFilter === 'all' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? 'ទាំងអស់' : 'All'}
          </button>
          <button
            onClick={() => setStatusFilter('achieved')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
              statusFilter === 'achieved' ? 'bg-emerald-600 text-white shadow-2xs font-semibold' : 'text-emerald-700 hover:bg-emerald-50'
            }`}
          >
            {lang === 'km' ? 'សម្រេចបាន' : 'Achieved'}
          </button>
          <button
            onClick={() => setStatusFilter('in_progress')}
            className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
              statusFilter === 'in_progress' ? 'bg-amber-600 text-white shadow-2xs font-semibold' : 'text-amber-700 hover:bg-amber-50'
            }`}
          >
            {lang === 'km' ? 'កំពុងអនុវត្ត' : 'In Progress'}
          </button>
        </div>

        {/* View Toggle (Table / Grid) & Auto-Save Pill */}
        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-[11px] font-medium text-slate-600">
            {autoSaveStatus === 'saving' || syncStatus === 'saving' ? (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                <span className="text-amber-700">{lang === 'km' ? 'កំពុងរក្សាទុកស្វ័យប្រវត្ត...' : 'Auto-saving...'}</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-800">{lang === 'km' ? 'រក្សាទុកស្វ័យប្រវត្តសកម្ម' : 'Auto-save on'}</span>
              </>
            )}
          </div>

          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'table' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="ទម្រង់តារាង (Table View)"
            >
              <TableIcon className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'cards' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="ទម្រង់កាត (Card View)"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Empty State */}
      {filteredIndicators.length === 0 && (
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center shadow-xs">
          <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h4 className="text-sm font-bold text-slate-800">
            {lang === 'km' ? 'រកមិនឃើញសូចនាករដែលត្រូវគ្នាទេ' : 'No matching indicators found'}
          </h4>
          <p className="text-xs text-slate-500 mt-1">
            {lang === 'km' ? 'សូមសាកល្បងផ្លាស់ប្តូរពាក្យស្វែងរក ឬជម្រើសចម្រាញ់របស់អ្នក' : 'Try adjusting your search query or filters'}
          </p>
          <button
            onClick={() => { setSearchQuery(''); setStatusFilter('all'); }}
            className="mt-4 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors"
          >
            {lang === 'km' ? 'សម្អាតការស្វែងរក' : 'Reset Search'}
          </button>
        </div>
      )}

      {/* Main Content: Grouped Standards and Sections */}
      {groupedData.map(({ standardMeta, sections }) => (
        <div key={standardMeta.number} className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          
          {/* Standard Header Banner */}
          <div className="px-5 py-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm ${
                standardMeta.number === 1 ? 'bg-emerald-500 text-white' :
                standardMeta.number === 2 ? 'bg-blue-500 text-white' :
                standardMeta.number === 3 ? 'bg-amber-500 text-white' :
                standardMeta.number === 4 ? 'bg-purple-500 text-white' :
                'bg-rose-500 text-white'
              }`}>
                {standardMeta.number}
              </span>
              <div>
                <h3 className="text-sm sm:text-base font-bold">
                  {lang === 'km' ? standardMeta.titleKh : standardMeta.titleEn}
                </h3>
                <p className="text-xs text-slate-300">
                  {standardMeta.descriptionKh}
                </p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-semibold text-slate-300">
                {sections.reduce((acc, s) => acc + s.indicators.length, 0)} {lang === 'km' ? 'សូចនាករ' : 'Indicators'}
              </span>
            </div>
          </div>

          {/* Sections list */}
          <div className="divide-y divide-slate-100">
            {sections.map((sec, secIdx) => (
              <div key={secIdx} className="p-4 sm:p-5">
                
                {/* Section Title */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-indigo-600"></div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-800 tracking-tight">
                    {lang === 'km' ? sec.sectionTitleKh : sec.sectionTitleEn}
                  </h4>
                </div>

                {/* Table View */}
                {viewMode === 'table' ? (
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold">
                          <th className="py-2.5 px-3 w-14 text-center">{lang === 'km' ? 'ល.រ' : 'Code'}</th>
                          <th className="py-2.5 px-4 min-w-[240px]">{lang === 'km' ? 'លទ្ធផលរំពឹងទុក (សូចនាករ)' : 'Expected Result'}</th>
                          <th className="py-2.5 px-4 min-w-[320px]">{lang === 'km' ? 'សកម្មភាពអនុវត្ត (៧១ សកម្មភាព)' : 'Action Activities'}</th>
                          <th className="py-2.5 px-3 w-40 text-center">{lang === 'km' ? 'ពិន្ទុ (១-៥)' : 'Score (1-5)'}</th>
                          <th className="py-2.5 px-3 w-28 text-center">{lang === 'km' ? 'ស្ថានភាព' : 'Status'}</th>
                          <th className="py-2.5 px-3 w-16 text-center">{lang === 'km' ? 'កែប្រែ' : 'Action'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 bg-white">
                        {sec.indicators.map((ind) => {
                          const scoreObj = evaluationRecord?.scores[ind.id];
                          const scoreValue = scoreObj?.score || 1;
                          const completedActs = scoreObj?.completedActivities || [];
                          const isExpanded = expandedRows[ind.id] !== false; // default expanded for ease

                          return (
                            <tr 
                              key={ind.id} 
                              className="hover:bg-slate-50/70 transition-colors group"
                            >
                              
                              {/* Code Column */}
                              <td className="py-3 px-3 text-center align-top font-bold text-slate-800 bg-slate-50/40">
                                <span className="inline-block px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
                                  {ind.code}
                                </span>
                              </td>

                              {/* Expected Result (Indicator) */}
                              <td className="py-3 px-4 align-top">
                                <p className="font-semibold text-slate-900 leading-relaxed text-xs">
                                  {lang === 'km' ? ind.expectedResultKh : ind.expectedResultEn}
                                </p>
                                {scoreObj?.notes && (
                                  <div className="mt-2 p-2 rounded-lg bg-amber-50/80 border border-amber-200/60 text-[11px] text-amber-900">
                                    <span className="font-semibold">កំណត់ចំណាំ៖ </span>{scoreObj.notes}
                                  </div>
                                )}
                              </td>

                              {/* Action Activities checklist */}
                              <td className="py-3 px-4 align-top">
                                <div className="space-y-1.5">
                                  {ind.activitiesKh.map((act, actIdx) => {
                                    const isDone = completedActs.includes(actIdx);
                                    return (
                                      <div 
                                        key={actIdx}
                                        onClick={() => toggleActivityCheck(ind.id, actIdx)}
                                        className={`flex items-start gap-2 p-1.5 rounded-lg cursor-pointer transition-all ${
                                          isDone 
                                            ? 'bg-emerald-50/80 text-emerald-900 font-medium' 
                                            : 'hover:bg-slate-100 text-slate-700'
                                        }`}
                                      >
                                        <button 
                                          type="button" 
                                          className="mt-0.5 text-slate-400 hover:text-indigo-600 shrink-0"
                                        >
                                          {isDone ? (
                                            <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                                          ) : (
                                            <Square className="w-4 h-4 text-slate-300" />
                                          )}
                                        </button>
                                        <span className={`text-xs leading-snug ${isDone ? 'line-through opacity-85 text-emerald-800' : ''}`}>
                                          • {act}
                                        </span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </td>

                              {/* Interactive Score Selector */}
                              <td className="py-3 px-3 align-top text-center">
                                <div className="flex items-center justify-center gap-1">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <button
                                      key={star}
                                      onClick={(e) => handleQuickScore(e, ind.id, star)}
                                      className={`p-1 rounded transition-transform hover:scale-125 focus:outline-none ${
                                        star <= scoreValue 
                                          ? 'text-amber-400 hover:text-amber-500' 
                                          : 'text-slate-200 hover:text-slate-400'
                                      }`}
                                      title={`ពិន្ទុ ${star}/5 (${star * 20}%)`}
                                    >
                                      <Star 
                                        className={`w-4 h-4 ${star <= scoreValue ? 'fill-amber-400' : ''}`} 
                                      />
                                    </button>
                                  ))}
                                </div>
                                <span className="text-[11px] font-bold text-slate-600 mt-1 block">
                                  {scoreValue} / 5 ({scoreValue * 20}%)
                                </span>
                              </td>

                              {/* Status Badge */}
                              <td className="py-3 px-3 align-top text-center">
                                {getStatusBadge(scoreObj?.status)}
                              </td>

                              {/* Edit Modal Action */}
                              <td className="py-3 px-3 align-top text-center">
                                <button
                                  onClick={() => onSelectIndicator(ind)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                                  title="កែប្រែលម្អិត / បន្ថែមភស្តុតាង & កំណត់ចំណាំ"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                              </td>

                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  /* Cards View */
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {sec.indicators.map((ind) => {
                      const scoreObj = evaluationRecord?.scores[ind.id];
                      const scoreValue = scoreObj?.score || 1;
                      const completedActs = scoreObj?.completedActivities || [];

                      return (
                        <div 
                          key={ind.id}
                          className="p-4 rounded-xl border border-slate-200 bg-white hover:shadow-md transition-shadow flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold text-xs border border-indigo-100">
                                {ind.code}
                              </span>
                              {getStatusBadge(scoreObj?.status)}
                            </div>

                            <h5 className="font-bold text-slate-900 text-xs sm:text-sm mb-3">
                              {lang === 'km' ? ind.expectedResultKh : ind.expectedResultEn}
                            </h5>

                            {/* Sub-activities */}
                            <div className="space-y-1.5 mb-4">
                              <span className="text-[11px] font-semibold text-slate-500 block">
                                {lang === 'km' ? 'សកម្មភាពត្រូវអនុវត្ត៖' : 'Action items:'}
                              </span>
                              {ind.activitiesKh.map((act, actIdx) => {
                                const isDone = completedActs.includes(actIdx);
                                return (
                                  <div
                                    key={actIdx}
                                    onClick={() => toggleActivityCheck(ind.id, actIdx)}
                                    className={`flex items-start gap-2 p-1.5 rounded-lg cursor-pointer text-xs ${
                                      isDone ? 'bg-emerald-50 text-emerald-900 line-through' : 'hover:bg-slate-50 text-slate-700'
                                    }`}
                                  >
                                    <button type="button" className="mt-0.5 shrink-0">
                                      {isDone ? (
                                        <CheckSquare className="w-3.5 h-3.5 text-emerald-600" />
                                      ) : (
                                        <Square className="w-3.5 h-3.5 text-slate-300" />
                                      )}
                                    </button>
                                    <span>{act}</span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                            <div className="flex items-center gap-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  key={star}
                                  onClick={(e) => handleQuickScore(e, ind.id, star)}
                                  className={`p-0.5 hover:scale-110 transition-transform ${
                                    star <= scoreValue ? 'text-amber-400' : 'text-slate-200'
                                  }`}
                                >
                                  <Star className={`w-3.5 h-3.5 ${star <= scoreValue ? 'fill-amber-400' : ''}`} />
                                </button>
                              ))}
                              <span className="text-[11px] font-bold text-slate-600 ml-1">
                                {scoreValue}/5
                              </span>
                            </div>

                            <button
                              onClick={() => onSelectIndicator(ind)}
                              className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 hover:bg-indigo-100 flex items-center gap-1"
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>{lang === 'km' ? 'លម្អិត' : 'Details'}</span>
                            </button>
                          </div>

                        </div>
                      );
                    })}
                  </div>
                )}

              </div>
            ))}
          </div>

        </div>
      ))}

    </div>
  );
};
