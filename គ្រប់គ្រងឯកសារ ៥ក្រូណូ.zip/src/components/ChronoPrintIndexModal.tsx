import React from 'react';
import { 
  X, 
  Printer, 
  Download, 
  FolderCheck, 
  CheckCircle2, 
  Clock, 
  ShieldCheck,
  Building
} from 'lucide-react';
import { useChrono } from '../context/ChronoContext';
import { useAuth } from '../context/AuthContext';
import { useEvaluation } from '../context/EvaluationContext';
import { STANDARDS_METADATA } from '../data/standardsData';
import { NationalDocumentHeader } from './NationalDocumentHeader';
import { NationalDocumentFooter } from './NationalDocumentFooter';
import { toKhmerNum, getKhmerLunarSolarDate } from '../utils/khmerDateUtils';

interface ChronoPrintIndexModalProps {
  isOpen: boolean;
  onClose: () => void;
  standardNumber: number;
}

export const ChronoPrintIndexModal: React.FC<ChronoPrintIndexModalProps> = ({
  isOpen,
  onClose,
  standardNumber
}) => {
  const { getDocumentsForStandard } = useChrono();
  const { userProfile } = useAuth();
  const { academicYear, lang } = useEvaluation();

  if (!isOpen) return null;

  const standardMeta = STANDARDS_METADATA.find(s => s.number === standardNumber);
  const standardDocs = getDocumentsForStandard(standardNumber);

  const dates = getKhmerLunarSolarDate(new Date(), userProfile?.district || userProfile?.province || 'រោគ');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
              <FolderCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                {lang === 'km' ? `ក្របមុខ និងតារាងមាតិកាក្រូណូទី ${toKhmerNum(standardNumber)}` : `Chrono ${standardNumber} Cover & Index`}
              </h3>
              <p className="text-xs text-slate-400">
                {standardMeta?.titleKh}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'បោះពុម្ពសម្រាប់ដាក់ក្នុងក្រូណូ' : 'Print Cover & Index'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-100">
          
          {/* Printable Sheet 1: Cover Page */}
          <div className="bg-white border-2 border-slate-300 rounded-2xl p-10 sm:p-14 shadow-sm max-w-3xl mx-auto space-y-6 text-center print:border-none print:shadow-none print:p-0 mb-8">
            {/* Official National Header */}
            <NationalDocumentHeader
              administrationLine1={userProfile?.province ? `រដ្ឋបាលខេត្ត ${userProfile.province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា'}
              administrationLine2={userProfile?.district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${userProfile.district}` : 'មន្ទីរអប់រំ យុវជន និងកីឡា'}
              administrationLine3="កម្រងស្ថានីយសាលារៀនគំរូ"
              administrationLine4={userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ'}
              standardNumber={standardNumber}
            />

            {/* Big Chrono Box */}
            <div className="my-6 py-8 px-6 border-4 border-double border-indigo-950 rounded-2xl bg-indigo-50/40 space-y-3">
              <span className="text-xs uppercase tracking-widest font-bold text-indigo-800 bg-indigo-100 px-4 py-1 rounded-full border border-indigo-300">
                ឯកសារភស្តុតាងសាលារៀនគំរូ
              </span>
              <h1 className="font-moul text-xl sm:text-2xl text-indigo-950 leading-relaxed">
                ក្រូណូទី {toKhmerNum(standardNumber)}
              </h1>
              <h2 className="text-sm sm:text-base font-bold text-slate-800 font-sans">
                {standardMeta?.titleKh}
              </h2>
              <p className="text-xs text-slate-600 max-w-lg mx-auto italic">
                {standardMeta?.descriptionKh}
              </p>
            </div>

            {/* School & Academic Year Info */}
            <div className="grid grid-cols-2 gap-4 text-xs font-sans border-t border-b border-slate-200 py-4 max-w-lg mx-auto text-left">
              <div>
                <span className="text-slate-500">ឆ្នាំសិក្សា៖ </span>
                <span className="font-bold text-slate-900">{toKhmerNum(academicYear || '២០២៥-២០២៦')}</span>
              </div>
              <div>
                <span className="text-slate-500">ចំនួនឯកសារក្នុងក្រូណូ៖ </span>
                <span className="font-bold text-slate-900">{toKhmerNum(standardDocs.length)} ឯកសារ</span>
              </div>
              <div>
                <span className="text-slate-500">នាយកសាលា៖ </span>
                <span className="font-bold text-slate-900">{userProfile?.displayName || 'នាយកសាលារៀន'}</span>
              </div>
              <div>
                <span className="text-slate-500">ទីតាំងតម្កល់៖ </span>
                <span className="font-bold text-slate-900">{userProfile?.schoolName || 'សាលារៀន'}</span>
              </div>
            </div>

            {/* Official National Footer on Cover */}
            <NationalDocumentFooter
              lunarDateKh={dates.lunarDateKh}
              solarDateKh={dates.solarDateKh}
              locationKh={userProfile?.district || userProfile?.province || 'រោគ'}
              secondApproverRole="ប្រធានគណៈកម្មការ គ.គ.ស"
              secondApproverName=""
              approverRole="នាយកសាលារៀន"
              approverName={userProfile?.displayName || ''}
              reporterRole="អ្នកទទួលបន្ទុកក្រូណូ"
              reporterName="Tong Un"
            />
          </div>

          {/* Printable Sheet 2: Table of Contents / Index */}
          <div className="bg-white border-2 border-slate-300 rounded-2xl p-8 sm:p-12 shadow-sm max-w-3xl mx-auto space-y-6 text-slate-900 print:border-none print:shadow-none print:p-0">
            {/* Header for Index */}
            <NationalDocumentHeader
              administrationLine1={userProfile?.province ? `រដ្ឋបាលខេត្ត ${userProfile.province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា'}
              administrationLine2={userProfile?.district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${userProfile.district}` : 'មន្ទីរអប់រំ យុវជន និងកីឡា'}
              administrationLine3="កម្រងស្ថានីយសាលារៀនគំរូ"
              administrationLine4={userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ'}
              documentTitle={`តារាងមាតិកាឯកសារភស្តុតាង (ក្រូណូទី ${toKhmerNum(standardNumber)})`}
              subTitle={`ស្តង់ដា៖ ${standardMeta?.titleKh} | ឆ្នាំសិក្សា៖ ${toKhmerNum(academicYear || '២០២៥-២០២៦')}`}
              standardNumber={standardNumber}
            />

            {/* Table with Khmer Numerals */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse font-sans">
                <thead>
                  <tr className="bg-slate-100 border border-slate-300 text-slate-900 font-bold">
                    <th className="p-2.5 text-center w-12 border border-slate-300">ល.រ</th>
                    <th className="p-2.5 border border-slate-300">លេខឯកសារ</th>
                    <th className="p-2.5 border border-slate-300">ឈ្មោះឯកសារ / ភស្តុតាង</th>
                    <th className="p-2.5 text-center border border-slate-300">សូចនាករ</th>
                    <th className="p-2.5 text-center border border-slate-300">កាលបរិច្ឆេទ</th>
                    <th className="p-2.5 text-center border border-slate-300">ស្ថានភាព</th>
                  </tr>
                </thead>
                <tbody>
                  {standardDocs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400 italic border border-slate-300">
                        មិនទាន់មានឯកសារក្នុងក្រូណូនេះនៅឡើយទេ
                      </td>
                    </tr>
                  ) : (
                    standardDocs.map((doc, idx) => (
                      <tr key={doc.id} className="hover:bg-slate-50 border border-slate-300">
                        <td className="p-2.5 text-center font-bold border border-slate-300">{toKhmerNum(idx + 1)}</td>
                        <td className="p-2.5 font-sans text-xs border border-slate-300">{toKhmerNum(doc.documentNumber || '-')}</td>
                        <td className="p-2.5 font-semibold text-slate-900 border border-slate-300">
                          {doc.titleKh}
                        </td>
                        <td className="p-2.5 text-center font-bold text-indigo-700 border border-slate-300">
                          {toKhmerNum(doc.indicatorCode)}
                        </td>
                        <td className="p-2.5 text-center text-slate-700 border border-slate-300">
                          {doc.solarDateKh || doc.dateKh || new Date(doc.createdAt).toLocaleDateString('km-KH')}
                        </td>
                        <td className="p-2.5 text-center border border-slate-300">
                          {doc.status === 'signed_and_filed' ? (
                            <span className="text-emerald-700 font-bold">ចុះហត្ថលេខារួច</span>
                          ) : doc.status === 'verified' ? (
                            <span className="text-blue-700 font-bold">ផ្ទៀងផ្ទាត់រួច</span>
                          ) : (
                            <span className="text-amber-700 font-medium">រង់ចាំចុះហត្ថលេខា</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Note */}
            <p className="text-[11px] text-slate-600 italic pt-2">
              * រាល់ឯកសារដែលមានក្នុងតារាងមាតិកានេះ ត្រូវបានរៀបចំតាមលំដាប់លំដោយ និងតម្កល់ក្នុងក្រូណូផ្លូវការរបស់សាលារៀន សម្រាប់ទទួលការវាយតម្លៃពីគណៈកម្មការ និងអធិការកិច្ច។
            </p>

            {/* Signatures for Index Sheet */}
            <NationalDocumentFooter
              lunarDateKh={dates.lunarDateKh}
              solarDateKh={dates.solarDateKh}
              locationKh={userProfile?.district || userProfile?.province || 'រោគ'}
              secondApproverRole="ប្រធានគណៈកម្មការ គ.គ.ស"
              secondApproverName=""
              approverRole="នាយកសាលារៀន"
              approverName={userProfile?.displayName || ''}
              reporterRole="អ្នករៀបចំតារាងមាតិកា"
              reporterName="Tong Un"
            />
          </div>

        </div>

      </div>
    </div>
  );
};
