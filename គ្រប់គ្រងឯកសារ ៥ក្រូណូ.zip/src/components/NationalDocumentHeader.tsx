import React from 'react';
import { toKhmerNum } from '../utils/khmerDateUtils';

export interface NationalDocumentHeaderProps {
  administrationLine1?: string; // e.g. "រដ្ឋបាលស្រុកភ្នំស្រុក" ឬ "មន្ទីរអប់រំ យុវជន និងកីឡា..."
  administrationLine2?: string; // e.g. "ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក"
  administrationLine3?: string; // e.g. "កម្រងស្ថានីយស្រែល្អ"
  administrationLine4?: string; // e.g. "សាលាបឋមសិក្សា រោគ"
  documentNumber?: string;       // e.g. "លេខ៖ ០២៤/២៦ របក.សរ"
  schoolName?: string;
  province?: string;
  district?: string;
  documentTitle?: string;
  subTitle?: string;
  standardNumber?: number;
  indicatorCode?: string;
}

export const NationalDocumentHeader: React.FC<NationalDocumentHeaderProps> = ({
  administrationLine1,
  administrationLine2,
  administrationLine3,
  administrationLine4,
  documentNumber,
  schoolName,
  province,
  district,
  documentTitle,
  subTitle,
  standardNumber,
  indicatorCode
}) => {
  // Construct default administration hierarchy if not custom provided
  const line1 = administrationLine1 || (province ? `រដ្ឋបាលខេត្ត ${province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា');
  const line2 = administrationLine2 || (district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${district}` : 'មន្ទីរអប់រំ យុវជន និងកីឡា');
  const line3 = administrationLine3 || 'កម្រងស្ថានីយសាលារៀនគំរូ';
  const line4 = administrationLine4 || schoolName || 'សាលាបឋមសិក្សាគំរូ';

  return (
    <div className="w-full space-y-4 text-slate-900 select-text print:text-black">
      {/* Top Banner: Left Admin Hierarchy & Right Kingdom Motto */}
      <div className="flex justify-between items-start pt-2 pb-2 gap-4">
        {/* Administration Hierarchy: Left Top */}
        <div className="space-y-0.5 text-left text-xs sm:text-sm text-slate-800 leading-snug">
          <p className="font-semibold text-slate-900">{line1}</p>
          <p className="font-semibold text-slate-800">{line2}</p>
          {line3 && <p className="text-slate-700">{line3}</p>}
          <p className="font-moul text-xs sm:text-sm text-slate-900 pt-0.5">{line4}</p>
          {documentNumber && (
            <p className="text-slate-600 text-xs pt-1 font-sans">
              {documentNumber.startsWith('លេខ') ? documentNumber : `លេខ៖ ${toKhmerNum(documentNumber)}`}
            </p>
          )}
        </div>

        {/* National Motto: Right Top */}
        <div className="text-center font-moul space-y-1 shrink-0">
          <h2 className="text-xs sm:text-sm md:text-base font-normal tracking-wide text-slate-900">
            ព្រះរាជាណាចក្រកម្ពុជា
          </h2>
          <h3 className="text-[11px] sm:text-xs md:text-sm font-normal tracking-wide text-slate-900">
            ជាតិ សាសនា ព្រះមហាក្សត្រ
          </h3>
          <div className="text-[10px] sm:text-xs tracking-widest text-slate-700 font-sans select-none pt-0.5">
            ---***---
          </div>
          {(standardNumber || indicatorCode) && (
            <div className="text-right text-[11px] text-slate-600 pt-1 font-sans space-y-0.5">
              {standardNumber && (
                <p className="font-semibold text-indigo-900">
                  ក្រូណូទី {toKhmerNum(standardNumber)}
                </p>
              )}
              {indicatorCode && (
                <p className="text-slate-500">
                  សូចនាករ {toKhmerNum(indicatorCode)}
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Document Title: Center */}
      {documentTitle && (
        <div className="text-center pt-2 pb-3 border-b border-slate-200 space-y-1">
          <h1 className="font-moul text-base sm:text-lg text-slate-900 leading-relaxed max-w-3xl mx-auto">
            {documentTitle}
          </h1>
          {subTitle && (
            <p className="text-xs sm:text-sm font-semibold text-slate-700 font-sans">
              {subTitle}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
