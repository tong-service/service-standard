import React from 'react';
import { getKhmerLunarSolarDate, toKhmerNum } from '../utils/khmerDateUtils';

export interface NationalDocumentFooterProps {
  lunarDateKh?: string;
  solarDateKh?: string;
  locationKh?: string;
  dateRaw?: Date | string;
  approverRole?: string;        // Center: "នាយកសាលារៀន"
  approverName?: string;        // Center: Principal name
  secondApproverRole?: string;  // Left: "ប្រធានគណៈកម្មការ គ.គ.ស"
  secondApproverName?: string;  // Left: Committee Chair name
  reporterRole?: string;        // Right: "អ្នកទទួលបន្ទុកស្តង់ដា" ឬ "អ្នកធ្វើរបាយការណ៍"
  reporterName?: string;        // Right: Reporter name (e.g. "Tong Un")
  showThreeColumns?: boolean;   // default: true (3-column MoEYS standard)
}

export const NationalDocumentFooter: React.FC<NationalDocumentFooterProps> = ({
  lunarDateKh,
  solarDateKh,
  locationKh,
  dateRaw,
  approverRole = 'នាយកសាលារៀន',
  approverName,
  secondApproverRole = 'ប្រធានគណៈកម្មការ គ.គ.ស',
  secondApproverName,
  reporterRole = 'អ្នកទទួលបន្ទុកស្តង់ដា',
  reporterName = 'Tong Un',
  showThreeColumns = true
}) => {
  // Generate accurate lunar & solar dates if not pre-provided
  const defaultDates = getKhmerLunarSolarDate(dateRaw, locationKh || 'រោគ');
  const finalLunarDate = lunarDateKh || defaultDates.lunarDateKh;
  const finalSolarDate = solarDateKh || defaultDates.solarDateKh;

  const hasThreeColumns = showThreeColumns && Boolean(secondApproverRole);

  const displayReporterRole = reporterRole?.startsWith('រៀបចំ') 
    ? reporterRole.replace(/^រៀបចំដោយ\s*/, '') 
    : reporterRole;

  return (
    <div className="w-full pt-6 mt-6 border-t border-slate-200 text-slate-900 select-text print:text-black">
      {/* 
        Official MoEYS Date Section:
        Always placed at the top-right, with text strictly left-aligned.
        Placing this at the top ensures the Preparer (អ្នករៀបចំ) section sits above
        or level with the approvals, never below them.
      */}
      <div className="flex justify-end mb-4 sm:mb-6">
        <div className="text-left font-sans text-xs sm:text-[13px] text-slate-800 leading-normal space-y-0.5 min-w-[210px] max-w-[340px]">
          <p className="whitespace-normal sm:whitespace-nowrap font-medium text-slate-900">
            {finalLunarDate}
          </p>
          <p className="whitespace-normal sm:whitespace-nowrap font-medium text-slate-900">
            {finalSolarDate}
          </p>
        </div>
      </div>

      {hasThreeColumns ? (
        /*
          Official 3-Column Footer as mandated by MoEYS & User Request:
          - ឆ្វេង (Left): គ.គ.ស. (បានពិនិត្យ និងយល់ព្រម)
          - កណ្ដាល (Center): នាយកសាលា (បានឃើញ និងឯកភាព)
          - ស្ដាំ (Right): អ្នករៀបចំ (រៀបចំដោយ)
          
          Maintained in a fixed 3-column grid (grid-cols-3) so that on all screen sizes,
          the columns remain side-by-side on the same horizontal plane and the right column
          never drops below the others.
        */
        <div className="grid grid-cols-3 gap-2 sm:gap-4 md:gap-6 text-xs sm:text-sm font-sans items-start">
          {/* 1. Left Column: គណៈកម្មការទ្រទ្រង់សាលារៀន (គ.គ.ស) */}
          <div className="text-center space-y-1">
            <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-900 leading-snug">
              បានពិនិត្យ និងយល់ព្រម
            </p>
            <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-800 leading-snug">
              {secondApproverRole}
            </p>
            
            {/* Signature Area */}
            <div className="h-20 sm:h-24 md:h-28 flex items-center justify-center">
              <span className="text-[10px] sm:text-xs text-slate-400 italic">
                (ហត្ថលេខា)
              </span>
            </div>
            
            {/* Dotted Line & Name */}
            <div className="pt-1 sm:pt-2">
              <p className="text-slate-400 tracking-tighter sm:tracking-wider overflow-hidden select-none">
                ..................................................
              </p>
              <p className="font-semibold text-slate-900 text-[11px] sm:text-xs md:text-sm mt-1">
                {secondApproverName || ''}
              </p>
            </div>
          </div>

          {/* 2. Center Column: នាយកសាលារៀន */}
          <div className="text-center space-y-1">
            <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-900 leading-snug">
              បានឃើញ និងឯកភាព
            </p>
            <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-800 leading-snug">
              {approverRole}
            </p>
            
            {/* Physical Stamp & Signature Space */}
            <div className="h-20 sm:h-24 md:h-28 flex items-center justify-center">
              <span className="text-[10px] sm:text-xs text-slate-400 italic">
                (ហត្ថលេខា និងត្រា)
              </span>
            </div>
            
            {/* Dotted Line & Name */}
            <div className="pt-1 sm:pt-2">
              <p className="text-slate-400 tracking-tighter sm:tracking-wider overflow-hidden select-none">
                ..................................................
              </p>
              <p className="font-semibold text-slate-900 text-[11px] sm:text-xs md:text-sm mt-1">
                {approverName || ''}
              </p>
            </div>
          </div>

          {/* 3. Right Column: អ្នករៀបចំ (Preparer / Reporter) */}
          <div className="text-center space-y-1">
            <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-900 leading-snug">
              រៀបចំដោយ
            </p>
            {displayReporterRole ? (
              <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-800 leading-snug">
                {displayReporterRole}
              </p>
            ) : (
              <p className="font-moul text-[11px] sm:text-xs md:text-sm text-slate-800 leading-snug invisible">
                -
              </p>
            )}
            
            {/* Signature Area */}
            <div className="h-20 sm:h-24 md:h-28 flex items-center justify-center">
              <span className="text-[10px] sm:text-xs text-slate-400 italic">
                (ហត្ថលេខា)
              </span>
            </div>
            
            {/* Dotted Line & Name */}
            <div className="pt-1 sm:pt-2">
              <p className="text-slate-400 tracking-tighter sm:tracking-wider overflow-hidden select-none">
                ..................................................
              </p>
              <p className="font-semibold text-slate-900 text-[11px] sm:text-xs md:text-sm mt-1">
                {reporterName || 'Tong Un'}
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* Standard 2-Column Footer Fallback */
        <div className="grid grid-cols-2 gap-4 sm:gap-8 text-xs sm:text-sm font-sans items-start">
          {/* Left Column: បានឃើញ និងឯកភាព / នាយកសាលា */}
          <div className="text-center space-y-1">
            <p className="font-moul text-xs sm:text-sm text-slate-900">បានឃើញ និងឯកភាព</p>
            <p className="font-moul text-xs sm:text-sm text-slate-900">{approverRole}</p>
            
            <div className="h-20 sm:h-24 flex items-center justify-center">
              <span className="text-[11px] text-slate-400 italic">(ហត្ថលេខា និងត្រា)</span>
            </div>

            <div className="pt-2">
              <p className="text-slate-400 tracking-wider select-none">
                ..................................................
              </p>
              <p className="font-semibold text-slate-900 text-xs sm:text-sm mt-1">
                {approverName || ''}
              </p>
            </div>
          </div>

          {/* Right Column: អ្នកធ្វើរបាយការណ៍ / រៀបចំដោយ */}
          <div className="text-center space-y-1">
            <p className="font-moul text-xs sm:text-sm text-slate-900">រៀបចំដោយ</p>
            {displayReporterRole ? (
              <p className="font-moul text-xs sm:text-sm text-slate-800">{displayReporterRole}</p>
            ) : null}
            
            <div className="h-20 sm:h-24 flex items-center justify-center">
              <span className="text-[11px] text-slate-400 italic">(ហត្ថលេខា)</span>
            </div>

            <div className="pt-2">
              <p className="text-slate-400 tracking-wider select-none">
                ..................................................
              </p>
              <p className="font-semibold text-slate-900 text-xs sm:text-sm mt-1">
                {reporterName || 'Tong Un'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
