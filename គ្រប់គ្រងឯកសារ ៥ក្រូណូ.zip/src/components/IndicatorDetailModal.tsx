import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Star, 
  CheckSquare, 
  Square, 
  Link, 
  FileText, 
  Plus, 
  Trash2, 
  ExternalLink, 
  ShieldCheck, 
  Clock,
  User,
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw,
  FolderOpen,
  Eye,
  Upload,
  Download
} from 'lucide-react';
import { useEvaluation } from '../context/EvaluationContext';
import { useChrono } from '../context/ChronoContext';
import { IndicatorDefinition, IndicatorScore, ScoreStatus } from '../types';
import { ChronoDocument } from '../types/chrono';
import { DocumentViewerModal } from './DocumentViewerModal';
import { DocumentEditorModal } from './DocumentEditorModal';
import { ImportFileModal } from './ImportFileModal';

interface IndicatorDetailModalProps {
  indicator: IndicatorDefinition | null;
  isOpen: boolean;
  onClose: () => void;
  lang: 'km' | 'en';
}

export const IndicatorDetailModal: React.FC<IndicatorDetailModalProps> = ({
  indicator,
  isOpen,
  onClose,
  lang
}) => {
  const { evaluationRecord, saveScore, autoSaveStatus } = useEvaluation();
  const { getDocumentsForIndicator } = useChrono();

  const [score, setScore] = useState<number>(1);
  const [status, setStatus] = useState<ScoreStatus>('not_started');
  const [notes, setNotes] = useState<string>('');
  const [evidenceLinks, setEvidenceLinks] = useState<string[]>([]);
  const [newLinkInput, setNewLinkInput] = useState<string>('');
  const [completedActivities, setCompletedActivities] = useState<number[]>([]);
  const [localAutoSaveStatus, setLocalAutoSaveStatus] = useState<'saved' | 'saving'>('saved');

  // Modal states for indicator-specific chrono actions
  const [viewingChronoDoc, setViewingChronoDoc] = useState<ChronoDocument | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);

  // Track if current state is initialized from indicator to prevent unwanted save on mount
  const isInitializedRef = useRef<boolean>(false);
  const notesDebounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const indicatorChronoDocs = indicator ? getDocumentsForIndicator(indicator.id) : [];

  // Sync state with current indicator score
  useEffect(() => {
    if (indicator && evaluationRecord?.scores[indicator.id]) {
      const existing = evaluationRecord.scores[indicator.id];
      setScore(existing.score || 1);
      setStatus(existing.status || 'not_started');
      setNotes(existing.notes || '');
      setEvidenceLinks(existing.evidenceLinks || []);
      setCompletedActivities(existing.completedActivities || []);
    } else {
      setScore(1);
      setStatus('not_started');
      setNotes('');
      setEvidenceLinks([]);
      setCompletedActivities([]);
    }
    isInitializedRef.current = true;
  }, [indicator?.id, isOpen]);

  if (!isOpen || !indicator) return null;

  const currentScoreRecord = evaluationRecord?.scores[indicator.id];

  // Helper to trigger immediate or debounced auto-save
  const triggerAutoSave = (updated: {
    score?: number;
    status?: ScoreStatus;
    notes?: string;
    evidenceLinks?: string[];
    completedActivities?: number[];
  }, immediate = false) => {
    setLocalAutoSaveStatus('saving');
    const newScore = updated.score !== undefined ? updated.score : score;
    const newStatus = updated.status !== undefined ? updated.status : status;
    const newNotes = updated.notes !== undefined ? updated.notes : notes;
    const newLinks = updated.evidenceLinks !== undefined ? updated.evidenceLinks : evidenceLinks;
    const newActs = updated.completedActivities !== undefined ? updated.completedActivities : completedActivities;

    saveScore(indicator.id, {
      score: newScore,
      percentage: newScore * 20,
      status: newStatus,
      notes: newNotes,
      evidenceLinks: newLinks,
      completedActivities: newActs
    }, { immediate });

    setTimeout(() => {
      setLocalAutoSaveStatus('saved');
    }, 500);
  };

  const handleToggleActivity = (index: number) => {
    let nextCompleted: number[];
    if (completedActivities.includes(index)) {
      nextCompleted = completedActivities.filter(i => i !== index);
    } else {
      nextCompleted = [...completedActivities, index];
    }
    setCompletedActivities(nextCompleted);

    // Auto update suggested score if user hasn't overridden
    const ratio = indicator.activitiesKh.length > 0 ? nextCompleted.length / indicator.activitiesKh.length : 0;
    let nextScore = score;
    let nextStatus = status;

    if (ratio >= 1) {
      nextScore = 5;
      nextStatus = 'achieved';
    } else if (ratio >= 0.7) {
      nextScore = 4;
      nextStatus = 'achieved';
    } else if (ratio >= 0.4) {
      nextScore = 3;
      nextStatus = 'in_progress';
    } else if (ratio > 0) {
      nextScore = 2;
      nextStatus = 'in_progress';
    }

    setScore(nextScore);
    setStatus(nextStatus);

    // Trigger auto-save immediately
    triggerAutoSave({
      completedActivities: nextCompleted,
      score: nextScore,
      status: nextStatus
    }, false);
  };

  const handleScoreChange = (newVal: number) => {
    setScore(newVal);
    let nextStatus: ScoreStatus = 'in_progress';
    if (newVal >= 5) nextStatus = 'exceeded';
    else if (newVal >= 4) nextStatus = 'achieved';
    else if (newVal >= 2) nextStatus = 'in_progress';
    else nextStatus = 'not_started';

    setStatus(nextStatus);
    triggerAutoSave({ score: newVal, status: nextStatus }, false);
  };

  const handleStatusChange = (newStatus: ScoreStatus) => {
    setStatus(newStatus);
    triggerAutoSave({ status: newStatus }, false);
  };

  const handleNotesChange = (val: string) => {
    setNotes(val);
    setLocalAutoSaveStatus('saving');

    if (notesDebounceTimerRef.current) {
      clearTimeout(notesDebounceTimerRef.current);
    }

    notesDebounceTimerRef.current = setTimeout(() => {
      triggerAutoSave({ notes: val }, false);
    }, 400);
  };

  const handleAddLink = () => {
    if (!newLinkInput.trim()) return;
    const updated = [...evidenceLinks, newLinkInput.trim()];
    setEvidenceLinks(updated);
    setNewLinkInput('');
    triggerAutoSave({ evidenceLinks: updated }, true);
  };

  const handleRemoveLink = (idx: number) => {
    const updated = evidenceLinks.filter((_, i) => i !== idx);
    setEvidenceLinks(updated);
    triggerAutoSave({ evidenceLinks: updated }, true);
  };

  const handleClose = () => {
    // Flush any pending note auto-save immediately
    if (notesDebounceTimerRef.current) {
      clearTimeout(notesDebounceTimerRef.current);
    }
    triggerAutoSave({
      score,
      status,
      notes,
      evidenceLinks,
      completedActivities
    }, true);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-start justify-between gap-4 shrink-0">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-md bg-indigo-500 text-white font-bold text-xs">
                {indicator.code}
              </span>
              <span className="text-xs text-slate-300 font-medium">
                {lang === 'km' ? indicator.standardTitleKh : indicator.standardTitleEn}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold leading-snug">
              {lang === 'km' ? indicator.expectedResultKh : indicator.expectedResultEn}
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Auto-Save Status Banner */}
        <div className="px-6 py-2 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            {localAutoSaveStatus === 'saving' || autoSaveStatus === 'saving' ? (
              <span className="inline-flex items-center gap-1.5 text-amber-700 font-medium">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-600" />
                <span>{lang === 'km' ? 'កំពុងរក្សាទុកស្វ័យប្រវត្តទៅ Cloud...' : 'Auto-saving to Firestore...'}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{lang === 'km' ? 'បានរក្សាទុកស្វ័យប្រវត្ត (Auto-saved)' : 'All changes auto-saved'}</span>
              </span>
            )}
          </div>

          <span className="text-[11px] text-slate-500">
            {lang === 'km' ? 'រាល់ការកែប្រែត្រូវបានរក្សាទុកភ្លាមៗ' : 'Continuous real-time sync'}
          </span>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* 1. Activities Checklist */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <CheckSquare className="w-4 h-4 text-indigo-600" />
                <span>{lang === 'km' ? 'សកម្មភាពអនុវត្តទាំង ៧១ (ចុចធីកដើម្បីរក្សាទុកស្វ័យប្រវត្ត)' : 'Activities Checklist (Auto-saves on check)'}</span>
              </h4>
              <span className="text-xs font-bold text-indigo-600">
                {completedActivities.length} / {indicator.activitiesKh.length}
              </span>
            </div>
            <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
              {indicator.activitiesKh.map((act, idx) => {
                const isChecked = completedActivities.includes(idx);
                return (
                  <div
                    key={idx}
                    onClick={() => handleToggleActivity(idx)}
                    className={`flex items-start gap-3 p-2.5 rounded-lg cursor-pointer transition-all ${
                      isChecked
                        ? 'bg-emerald-50 text-emerald-900 border border-emerald-200 font-medium shadow-2xs'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                    }`}
                  >
                    <button type="button" className="mt-0.5 shrink-0">
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300" />
                      )}
                    </button>
                    <span className={`text-xs ${isChecked ? 'line-through text-emerald-800 font-medium' : ''}`}>
                      {act}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 2. Score & Status Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Score Selector */}
            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              <label className="block text-xs font-bold text-slate-800 mb-2">
                {lang === 'km' ? 'ពិន្ទុវាយតម្លៃ (១ ដល់ ៥)' : 'Evaluation Score (1 to 5)'}
              </label>
              <div className="flex items-center gap-2 mb-2">
                {[1, 2, 3, 4, 5].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => handleScoreChange(val)}
                    className={`flex-1 py-2 rounded-lg font-bold text-xs flex flex-col items-center gap-1 transition-all ${
                      score === val
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${score >= val ? 'text-amber-300 fill-amber-300' : 'text-slate-300'}`} />
                    <span>{val}</span>
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-slate-500 text-center font-medium">
                {score === 1 && (lang === 'km' ? 'កម្រិត ១ (០-២៥%) មិនទាន់អនុវត្ត' : 'Level 1 (0-25%) Not Started')}
                {score === 2 && (lang === 'km' ? 'កម្រិត ២ (២៦-៥០%) កំពុងអភិវឌ្ឍ' : 'Level 2 (26-50%) Developing')}
                {score === 3 && (lang === 'km' ? 'កម្រិត ៣ (៥១-៧៥%) មធ្យម' : 'Level 3 (51-75%) Proficient')}
                {score === 4 && (lang === 'km' ? 'កម្រិត ៤ (៧៦-៩០%) ល្អប្រសើរ' : 'Level 4 (76-90%) Advanced')}
                {score === 5 && (lang === 'km' ? 'កម្រិត ៥ (៩១-១០០%) ឆ្នើម' : 'Level 5 (91-100%) Exemplary')}
              </p>
            </div>

            {/* Status Selector */}
            <div className="p-4 rounded-xl border border-slate-200 bg-white">
              <label className="block text-xs font-bold text-slate-800 mb-2">
                {lang === 'km' ? 'ស្ថានភាពអនុវត្ត' : 'Implementation Status'}
              </label>
              <select
                value={status}
                onChange={(e) => handleStatusChange(e.target.value as ScoreStatus)}
                className="w-full px-3 py-2.5 text-xs font-semibold rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white mb-2"
              >
                <option value="not_started">មិនទាន់អនុវត្ត (Not Started)</option>
                <option value="in_progress">កំពុងអនុវត្ត (In Progress)</option>
                <option value="achieved">សម្រេចបានល្អ (Achieved)</option>
                <option value="exceeded">សម្រេចបានឆ្នើម (Exceeded)</option>
              </select>
              <div className="p-2.5 rounded-lg bg-indigo-50/70 border border-indigo-100 text-[11px] text-indigo-900 flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-indigo-600" />
                <span>{lang === 'km' ? 'ទិន្នន័យត្រូវបានរក្សាទុកស្វ័យប្រវត្តក្នុង Firestore ភ្លាមៗ។' : 'Automatically saved in Firestore Database.'}</span>
              </div>
            </div>

          </div>

          {/* 3. Evaluation Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-slate-600" />
              <span>{lang === 'km' ? 'កំណត់ចំណាំ និងលទ្ធផលសង្កេតជាក់ស្តែង (រក្សាទុកស្វ័យប្រវត្ត)' : 'Evaluation Notes & Observations (Auto-saved)'}</span>
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder={lang === 'km' ? 'កត់ត្រាវឌ្ឍនភាព បញ្ហាប្រឈម ឬសកម្មភាពដែលបានអនុវត្តជាក់ស្តែង...' : 'Add notes, challenges or remarks...'}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* 4. Evidence Attachments & Links */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <Link className="w-4 h-4 text-slate-600" />
              <span>{lang === 'km' ? 'តំណភ្ជាប់ឯកសារភស្តុតាង (Google Drive, រូបភាព, របាយការណ៍)' : 'Evidence Links / URLs'}</span>
            </label>
            
            <div className="flex gap-2 mb-2">
              <input
                type="url"
                value={newLinkInput}
                onChange={(e) => setNewLinkInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddLink();
                  }
                }}
                placeholder="https://drive.google.com/... ឬតំណភ្ជាប់ឯកសារ (Enter ដើម្បីបញ្ចូល)"
                className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddLink}
                className="px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-semibold text-xs flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'បន្ថែម' : 'Add'}</span>
              </button>
            </div>

            {evidenceLinks.length > 0 && (
              <div className="space-y-1.5">
                {evidenceLinks.map((linkUrl, idx) => (
                  <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                    <a
                      href={linkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:underline truncate max-w-[80%] flex items-center gap-1.5 font-medium"
                    >
                      <ExternalLink className="w-3 h-3 shrink-0" />
                      <span className="truncate">{linkUrl}</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => handleRemoveLink(idx)}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="លុបតំណភ្ជាប់"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 5. Chrono Binder Documents (ក្រូណូភស្តុតាងផ្លូវការ) */}
          <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-indigo-600" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">
                    {lang === 'km' ? `ឯកសារក្នុងក្រូណូទី ${indicator.standardNumber} សម្រាប់សូចនាករនេះ (${indicatorChronoDocs.length})` : `Chrono Documents (${indicatorChronoDocs.length})`}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'km' ? 'ឯកសារភស្តុតាងផ្លូវការដែលបានតម្កល់ក្នុងក្រូណូ និងត្រៀមចុះហត្ថលេខា' : 'Official documents filed in Chrono binder'}
                  </p>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(true)}
                  className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{lang === 'km' ? 'AI បង្កើតគំរូ' : 'AI Template'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsImportOpen(true)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-bold flex items-center gap-1"
                >
                  <Upload className="w-3 h-3 text-emerald-600" />
                  <span>Import</span>
                </button>
              </div>
            </div>

            {/* List of chrono documents for this indicator */}
            {indicatorChronoDocs.length === 0 ? (
              <div className="p-3 bg-white rounded-xl border border-indigo-100 text-center text-xs text-slate-500 italic">
                {lang === 'km' ? 'មិនទាន់មានឯកសារក្នុងក្រូណូសម្រាប់សូចនាករនេះទេ។ ចុច "AI បង្កើតគំរូ" ឬ "Import" ដើម្បីបន្ថែម។' : 'No documents filed for this indicator yet.'}
              </div>
            ) : (
              <div className="space-y-1.5">
                {indicatorChronoDocs.map((doc) => (
                  <div 
                    key={doc.id}
                    className="p-2.5 bg-white rounded-xl border border-indigo-100 flex items-center justify-between gap-3 text-xs hover:border-indigo-300 transition-colors"
                  >
                    <div className="min-w-0 flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0 font-bold text-[11px]">
                        {doc.documentNumber ? doc.documentNumber.slice(-3) : 'DOC'}
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 truncate">{doc.titleKh}</p>
                        <p className="text-[10px] text-slate-500">
                          {doc.status === 'signed_and_filed' ? '✅ ចុះហត្ថលេខារួច' : '⏳ រង់ចាំចុះហត្ថលេខា'} • {doc.dateKh || 'ថ្មីៗ'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setViewingChronoDoc(doc)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center gap-1 shrink-0"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{lang === 'km' ? 'មើល / បោះពុម្ព' : 'View'}</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Timestamp metadata */}
          {currentScoreRecord?.updatedAt && (
            <div className="text-[11px] text-slate-400 flex items-center gap-3 pt-2 border-t border-slate-100">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {new Date(currentScoreRecord.updatedAt).toLocaleString('km-KH')}
              </span>
              {currentScoreRecord.updatedByName && (
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {currentScoreRecord.updatedByName}
                </span>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2.5 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>{lang === 'km' ? 'មុខងាររក្សាទុកស្វ័យប្រវត្តកំពុងដំណើរការ' : 'Automatic save active'}</span>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-600/20 transition-colors flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{lang === 'km' ? 'រួចរាល់ (Done)' : 'Done'}</span>
          </button>
        </div>

      </div>

      {/* Embedded Chrono Modals */}
      <DocumentViewerModal
        isOpen={viewingChronoDoc !== null}
        onClose={() => setViewingChronoDoc(null)}
        document={viewingChronoDoc}
      />

      <DocumentEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        defaultStandard={indicator.standardNumber}
        defaultIndicatorId={indicator.id}
      />

      <ImportFileModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        defaultStandard={indicator.standardNumber}
        defaultIndicatorId={indicator.id}
      />

    </div>
  );
};
