import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Clock, 
  MapPin, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Filter, 
  Printer, 
  Sparkles, 
  Copy, 
  Check, 
  X, 
  BookOpen, 
  Users, 
  GraduationCap, 
  ShieldCheck, 
  FileText, 
  Layers, 
  CalendarDays,
  Sun,
  Moon,
  Info,
  Edit2,
  Trash2
} from 'lucide-react';
import { SchoolEvent, SchoolEventCategory, SchoolEventStatus } from '../types/eventPlanner';
import { INITIAL_SCHOOL_EVENTS } from '../data/schoolEventsData';
import { 
  gregorianToKhmerLunar, 
  getKhmerLunarMonthDays, 
  KhmerLunarDateResult 
} from '../utils/khmerLunarCalendar';
import { toKhmerNum, toWesternNum, KHMER_SOLAR_MONTHS, KHMER_DAYS_OF_WEEK } from '../utils/khmerDateUtils';
import { useAuth } from '../context/AuthContext';

interface SchoolEventPlannerViewProps {
  lang?: 'km' | 'en';
}

const STORAGE_KEY = 'moeys_school_planner_events_v1';

export const SchoolEventPlannerView: React.FC<SchoolEventPlannerViewProps> = ({ lang = 'km' }) => {
  const { userProfile } = useAuth();

  // Current view date state (year and month index 0-11)
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(8); // September = 8 (0-indexed)
  const [selectedDateStr, setSelectedDateStr] = useState<string>('2026-09-01');
  
  // Events state with LocalStorage persistence
  const [events, setEvents] = useState<SchoolEvent[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load events from storage', e);
    }
    return INITIAL_SCHOOL_EVENTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
    } catch (e) {
      console.error('Failed to save events to storage', e);
    }
  }, [events]);

  // Filters & Search
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'calendar' | 'list' | 'converter'>('calendar');

  // Modal State for Add/Edit Event
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<SchoolEvent | null>(null);

  // Form State for Event Modal
  const [formTitleKh, setFormTitleKh] = useState('');
  const [formDate, setFormDate] = useState('2026-09-01');
  const [formCategory, setFormCategory] = useState<SchoolEventCategory>('standard_1');
  const [formStandardNum, setFormStandardNum] = useState<number | undefined>(1);
  const [formIndicatorCode, setFormIndicatorCode] = useState('១.១');
  const [formTime, setFormTime] = useState('08:00 - 11:00');
  const [formLocation, setFormLocation] = useState(userProfile?.schoolName || 'សាលាបឋមសិក្សា រោគ');
  const [formResponsible, setFormResponsible] = useState(userProfile?.displayName || 'Tong Un');
  const [formStatus, setFormStatus] = useState<SchoolEventStatus>('planned');
  const [formDescription, setFormDescription] = useState('');

  // Converter Tool State
  const [converterInputDate, setConverterInputDate] = useState('2026-09-01');
  const [copiedLunarText, setCopiedLunarText] = useState(false);

  // Calculated lunar conversion for converter tool
  const convertedLunar = useMemo(() => {
    return gregorianToKhmerLunar(converterInputDate);
  }, [converterInputDate]);

  // Calculated month days for current calendar view
  const monthDays = useMemo(() => {
    return getKhmerLunarMonthDays(currentYear, currentMonth);
  }, [currentYear, currentMonth]);

  // Information about current month
  const monthHeaderInfo = useMemo(() => {
    const midMonthDate = new Date(currentYear, currentMonth, 15);
    const lunar = gregorianToKhmerLunar(midMonthDate);
    return {
      solarMonthKh: KHMER_SOLAR_MONTHS[currentMonth],
      solarYearKh: toKhmerNum(currentYear),
      animalYearKh: lunar.animalYearKh,
      sakKh: lunar.sakKh,
      buddhistYearKh: lunar.buddhistYearKh,
      lunarMonthKh: lunar.lunarMonthKh
    };
  }, [currentYear, currentMonth]);

  // Month Navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(prev => prev - 1);
    } else {
      setCurrentMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(prev => prev + 1);
    } else {
      setCurrentMonth(prev => prev + 1);
    }
  };

  const handleGoToToday = () => {
    const today = new Date();
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    setSelectedDateStr(dateStr);
    setConverterInputDate(dateStr);
  };

  // Open modal for creating new event
  const openNewEventModal = (initialDate?: string) => {
    const targetDate = initialDate || selectedDateStr || '2026-09-01';
    setEditingEvent(null);
    setFormTitleKh('');
    setFormDate(targetDate);
    setFormCategory('standard_1');
    setFormStandardNum(1);
    setFormIndicatorCode('១.១');
    setFormTime('08:00 - 11:00');
    setFormLocation(userProfile?.schoolName || 'សាលាបឋមសិក្សា រោគ');
    setFormResponsible(userProfile?.displayName || 'Tong Un');
    setFormStatus('planned');
    setFormDescription('');
    setIsEventModalOpen(true);
  };

  // Open modal for editing existing event
  const openEditEventModal = (event: SchoolEvent) => {
    setEditingEvent(event);
    setFormTitleKh(event.titleKh);
    setFormDate(event.gregorianDate);
    setFormCategory(event.category);
    setFormStandardNum(event.standardNumber);
    setFormIndicatorCode(event.indicatorCode || '');
    setFormTime(event.time || '');
    setFormLocation(event.location || '');
    setFormResponsible(event.responsiblePerson || '');
    setFormStatus(event.status);
    setFormDescription(event.descriptionKh || '');
    setIsEventModalOpen(true);
  };

  // Save Event
  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitleKh.trim()) return;

    const lunarInfo = gregorianToKhmerLunar(formDate);

    if (editingEvent) {
      // Update existing
      setEvents(prev => prev.map(item => {
        if (item.id === editingEvent.id) {
          return {
            ...item,
            titleKh: formTitleKh,
            gregorianDate: formDate,
            lunarDateKh: lunarInfo.fullLunarDateKh,
            shortLunarKh: lunarInfo.shortLunarDateKh,
            isHolyDay: lunarInfo.isHolyDay,
            category: formCategory,
            standardNumber: formStandardNum,
            indicatorCode: formIndicatorCode,
            time: formTime,
            location: formLocation,
            responsiblePerson: formResponsible,
            status: formStatus,
            descriptionKh: formDescription,
            updatedAt: new Date().toISOString()
          };
        }
        return item;
      }));
    } else {
      // Create new
      const newEvt: SchoolEvent = {
        id: `evt-${Date.now()}`,
        titleKh: formTitleKh,
        gregorianDate: formDate,
        lunarDateKh: lunarInfo.fullLunarDateKh,
        shortLunarKh: lunarInfo.shortLunarDateKh,
        isHolyDay: lunarInfo.isHolyDay,
        category: formCategory,
        standardNumber: formStandardNum,
        indicatorCode: formIndicatorCode,
        time: formTime,
        location: formLocation,
        responsiblePerson: formResponsible,
        status: formStatus,
        descriptionKh: formDescription,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setEvents(prev => [...prev, newEvt]);
    }

    setIsEventModalOpen(false);
  };

  // Delete Event
  const handleDeleteEvent = (id: string) => {
    if (window.confirm('តើអ្នកពិតជាចង់លុបព្រឹត្តិការណ៍នេះចេញពីប្រតិទិនផែនការដែរឬទេ?')) {
      setEvents(prev => prev.filter(e => e.id !== id));
    }
  };

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return events.filter(evt => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = evt.titleKh.toLowerCase().includes(q);
        const matchResp = evt.responsiblePerson?.toLowerCase().includes(q);
        const matchLoc = evt.location?.toLowerCase().includes(q);
        const matchInd = evt.indicatorCode?.toLowerCase().includes(q);
        if (!matchTitle && !matchResp && !matchLoc && !matchInd) return false;
      }

      // Category
      if (categoryFilter === 'all') return true;
      if (categoryFilter === 'standards') {
        return evt.category.startsWith('standard_');
      }
      if (categoryFilter === 'meeting') return evt.category === 'meeting';
      if (categoryFilter === 'exam') return evt.category === 'exam';
      if (categoryFilter === 'holiday') return evt.category === 'national_holiday' || evt.isNationalHoliday;
      if (categoryFilter === 'holy_day') return evt.isHolyDay;
      return evt.category === categoryFilter;
    });
  }, [events, searchQuery, categoryFilter]);

  // Events map by date string (YYYY-MM-DD)
  const eventsByDate = useMemo(() => {
    const map: Record<string, SchoolEvent[]> = {};
    filteredEvents.forEach(evt => {
      if (!map[evt.gregorianDate]) {
        map[evt.gregorianDate] = [];
      }
      map[evt.gregorianDate].push(evt);
    });
    return map;
  }, [filteredEvents]);

  // Selected date events
  const selectedDateEvents = useMemo(() => {
    return events.filter(e => e.gregorianDate === selectedDateStr);
  }, [events, selectedDateStr]);

  const selectedDateLunar = useMemo(() => {
    return gregorianToKhmerLunar(selectedDateStr);
  }, [selectedDateStr]);

  // Copy Lunar String helper
  const handleCopyLunar = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLunarText(true);
    setTimeout(() => setCopiedLunarText(false), 2000);
  };

  // Helper for category badge styles
  const getCategoryBadge = (category: SchoolEventCategory, stdNum?: number) => {
    switch (category) {
      case 'standard_1':
        return { label: 'ស្តង់ដាទី១៖ លទ្ធផលសិស្ស', bg: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
      case 'standard_2':
        return { label: 'ស្តង់ដាទី២៖ ការបង្រៀន/រៀន', bg: 'bg-blue-100 text-blue-800 border-blue-300' };
      case 'standard_3':
        return { label: 'ស្តង់ដាទី៣៖ គ.គ.ស/សហគមន៍', bg: 'bg-purple-100 text-purple-800 border-purple-300' };
      case 'standard_4':
        return { label: 'ស្តង់ដាទី៤៖ ប្រតិបត្តិការសាលា', bg: 'bg-amber-100 text-amber-800 border-amber-300' };
      case 'standard_5':
        return { label: 'ស្តង់ដាទី៥៖ គណនេយ្យភាព', bg: 'bg-indigo-100 text-indigo-800 border-indigo-300' };
      case 'exam':
        return { label: 'ការប្រឡង/តេស្ត', bg: 'bg-rose-100 text-rose-800 border-rose-300' };
      case 'meeting':
        return { label: 'កិច្ចប្រជុំបច្ចេកទេស', bg: 'bg-cyan-100 text-cyan-800 border-cyan-300' };
      case 'national_holiday':
        return { label: 'ពិធីបុណ្យជាតិ', bg: 'bg-orange-100 text-orange-800 border-orange-300' };
      case 'holy_day':
        return { label: 'ថ្ងៃសីល', bg: 'bg-yellow-100 text-yellow-800 border-yellow-300' };
      default:
        return { label: 'ផែនការសាលា', bg: 'bg-slate-100 text-slate-800 border-slate-300' };
    }
  };

  const getStatusBadge = (status: SchoolEventStatus) => {
    switch (status) {
      case 'completed':
        return { label: 'សម្រេចបាន', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'in_progress':
        return { label: 'កំពុងអនុវត្ត', bg: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'postponed':
        return { label: 'ពន្យារពេល', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      default:
        return { label: 'បានគ្រោងទុក', bg: 'bg-slate-100 text-slate-700 border-slate-200' };
    }
  };

  // Print Calendar
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-moul">
                ប្រតិទិនផែនការ និងព្រឹត្តិការណ៍សាលារៀន (ចន្ទគតិ-សុរិយគតិ)
              </h2>
              <p className="text-xs text-slate-500 font-sans flex items-center gap-1.5">
                <span>ប្រព័ន្ធគណនា និងបម្លែងកាលបរិច្ឆេទចន្ទគតិខ្មែរ ថ្ងៃសីល និងសកម្មភាព ៥ ស្តង់ដា</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span className="font-semibold text-amber-700">ឆ្នាំ{monthHeaderInfo.animalYearKh} {monthHeaderInfo.sakKh} ព.ស.{monthHeaderInfo.buddhistYearKh}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 no-print">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'calendar'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <CalendarDays className="w-3.5 h-3.5" />
            <span>ប្រតិទិនប្រចាំខែ</span>
          </button>

          <button
            onClick={() => setActiveTab('list')}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'list'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>បញ្ជីព្រឹត្តិការណ៍ ({filteredEvents.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('converter')}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'converter'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Moon className="w-3.5 h-3.5" />
            <span>ឧបករណ៍បម្លែងចន្ទគតិ</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-200"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>បោះពុម្ព</span>
          </button>

          <button
            onClick={() => openNewEventModal()}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-emerald-600/20 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>បន្ថែមព្រឹត្តិការណ៍</span>
          </button>
        </div>
      </div>

      {/* Converter Quick Widget (Always visible or in dedicated tab) */}
      {activeTab === 'converter' && (
        <div className="bg-gradient-to-br from-amber-50 via-white to-indigo-50/40 rounded-2xl p-5 sm:p-6 border border-amber-200/80 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-200/60 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold">
                🪷
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-amber-950 font-moul">
                  ឧបករណ៍បម្លែងកាលបរិច្ឆេទសកល (Gregorian) ទៅជា ចន្ទគតិខ្មែរផ្លូវការ
                </h3>
                <p className="text-xs text-amber-800/80">
                  ជ្រើសរើសថ្ងៃខែឆ្នាំសកល ដើម្បីទាញយកទម្រង់កាលបរិច្ឆេទចន្ទគតិ ពុទ្ធសករាជ ឆ្នាំសត្វ ស័ក និងថ្ងៃសីល
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="date"
                value={converterInputDate}
                onChange={(e) => setConverterInputDate(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold border border-amber-300 rounded-xl bg-white focus:ring-2 focus:ring-amber-500 shadow-inner"
              />
              <button
                onClick={handleGoToToday}
                className="px-2.5 py-1.5 text-xs font-bold rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300"
              >
                ថ្ងៃនេះ
              </button>
            </div>
          </div>

          {/* Conversion Details Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
            {/* Card 1: Official Full Line */}
            <div className="md:col-span-2 bg-white rounded-xl p-4 border border-amber-200 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider">
                  ទម្រង់រដ្ឋបាលផ្លូវការ (ចន្ទគតិ)
                </span>
                <button
                  onClick={() => handleCopyLunar(convertedLunar.fullLunarDateKh)}
                  className="px-2 py-1 text-[11px] font-bold rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1 transition-colors"
                >
                  {copiedLunarText ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-amber-700" />}
                  <span>{copiedLunarText ? 'បានចម្លង!' : 'ចម្លងអត្ថបទ'}</span>
                </button>
              </div>
              <p className="text-base sm:text-lg font-bold text-slate-900 font-sans select-all leading-relaxed">
                {convertedLunar.fullLunarDateKh}
              </p>
              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-3 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">សុរិយគតិ៖</span>
                <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700 font-sans">
                  {convertedLunar.solarDateFormattedKh}
                </span>
                {convertedLunar.holidayNameKh && (
                  <span className="bg-rose-50 text-rose-700 border border-rose-200 px-2 py-0.5 rounded font-bold">
                    🎉 {convertedLunar.holidayNameKh}
                  </span>
                )}
              </div>
            </div>

            {/* Card 2: Lunar Phase & Holy Day Status */}
            <div className="bg-white rounded-xl p-4 border border-amber-200 shadow-xs space-y-2">
              <span className="text-[11px] font-bold text-amber-800 uppercase tracking-wider">
                ដំណាក់កាលព្រះចន្ទ & ថ្ងៃសីល
              </span>
              <div className="flex items-center gap-3 pt-1">
                <span className="text-3xl select-none">{convertedLunar.moonEmoji}</span>
                <div>
                  <h4 className="text-base font-bold text-slate-900">
                    {convertedLunar.phaseTextKh} (ខែ{convertedLunar.lunarMonthKh})
                  </h4>
                  <p className="text-xs text-slate-500">
                    {convertedLunar.isFullMoon ? '🌕 ថ្ងៃពេញបូណ៌មី' : convertedLunar.isNewMoon ? '🌑 ថ្ងៃដាច់ខែ' : convertedLunar.moonPhase === 'waxing' ? '🌙 ខ្នើត (ព្រះចន្ទកាន់តែធំ)' : '🌘 រនោច (ព្រះចន្ទកាន់តែតូច)'}
                  </p>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-100">
                {convertedLunar.isHolyDay ? (
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                    <span>🪷</span>
                    <span>ជាថ្ងៃសីល ({convertedLunar.holyDayType})</span>
                  </div>
                ) : (
                  <div className="text-xs text-slate-500 italic">
                    មិនមែនជាថ្ងៃសីល
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Action to create event from converter */}
          <div className="flex justify-end pt-2">
            <button
              onClick={() => openNewEventModal(converterInputDate)}
              className="px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>បង្កើតព្រឹត្តិការណ៍សាលារៀនលើកាលបរិច្ឆេទនេះ</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Month Calendar & Sidebar Workspace */}
      {activeTab === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left / Center 8 cols: Big Month Calendar Grid */}
          <div className="lg:col-span-8 bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-4">
            
            {/* Calendar Controls & Month Title */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevMonth}
                  className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  title="ខែមុន"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="text-center sm:text-left">
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 font-moul">
                    ខែ{monthHeaderInfo.solarMonthKh} ឆ្នាំ{monthHeaderInfo.solarYearKh}
                  </h3>
                  <p className="text-xs text-amber-800 font-sans font-semibold">
                    ខែ{monthHeaderInfo.lunarMonthKh} ឆ្នាំ{monthHeaderInfo.animalYearKh} {monthHeaderInfo.sakKh} ព.ស.{monthHeaderInfo.buddhistYearKh}
                  </p>
                </div>
                <button
                  onClick={handleNextMonth}
                  className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  title="ខែបន្ទាប់"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Filter and Today button */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleGoToToday}
                  className="px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 transition-colors"
                >
                  ថ្ងៃនេះ
                </button>

                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="px-2.5 py-1.5 text-xs font-semibold border border-slate-300 rounded-xl bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">គ្រប់ប្រភេទទាំងអស់</option>
                  <option value="standards">ស្តង់ដាទាំង ៥</option>
                  <option value="standard_1">ស្តង់ដាទី ១ (លទ្ធផលសិស្ស)</option>
                  <option value="standard_2">ស្តង់ដាទី ២ (ការបង្រៀន)</option>
                  <option value="standard_3">ស្តង់ដាទី ៣ (គ.គ.ស)</option>
                  <option value="standard_4">ស្តង់ដាទី ៤ (ប្រតិបត្តិការ)</option>
                  <option value="standard_5">ស្តង់ដាទី ៥ (គណនេយ្យភាព)</option>
                  <option value="exam">ការប្រឡង</option>
                  <option value="meeting">កិច្ចប្រជុំ</option>
                  <option value="holiday">បុណ្យជាតិ</option>
                  <option value="holy_day">ថ្ងៃសីល</option>
                </select>
              </div>
            </div>

            {/* 7-Days Header (Sun to Sat) */}
            <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs py-2 bg-slate-50/80 rounded-xl border border-slate-200/60">
              <span className="text-rose-600">អាទិត្យ</span>
              <span className="text-slate-700">ច័ន្ទ</span>
              <span className="text-slate-700">អង្គារ</span>
              <span className="text-slate-700">ពុធ</span>
              <span className="text-slate-700">ព្រហស្បតិ៍</span>
              <span className="text-slate-700">សុក្រ</span>
              <span className="text-blue-600">សៅរ៍</span>
            </div>

            {/* Calendar Grid Days */}
            <div className="grid grid-cols-7 gap-1.5">
              {/* Leading Empty Cells for proper weekday offset */}
              {Array.from({ length: monthDays[0]?.dayOfWeekIndex || 0 }).map((_, idx) => (
                <div key={`empty-${idx}`} className="min-h-[85px] bg-slate-50/40 rounded-xl border border-dashed border-slate-200/40 opacity-40" />
              ))}

              {/* Real Days */}
              {monthDays.map((dayItem) => {
                const dayEvents = eventsByDate[dayItem.gregorianDateStr] || [];
                const isSelected = selectedDateStr === dayItem.gregorianDateStr;
                const isSunday = dayItem.dayOfWeekIndex === 0;
                const isSaturday = dayItem.dayOfWeekIndex === 6;
                const todayStr = new Date().toISOString().split('T')[0];
                const isToday = dayItem.gregorianDateStr === todayStr;

                return (
                  <div
                    key={dayItem.gregorianDateStr}
                    onClick={() => setSelectedDateStr(dayItem.gregorianDateStr)}
                    className={`min-h-[92px] p-1.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between group relative ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/40 shadow-sm ring-2 ring-indigo-500/20'
                        : isToday
                        ? 'border-indigo-400 bg-indigo-50/20'
                        : dayItem.isHolyDay
                        ? 'border-amber-300 bg-amber-50/30 hover:border-amber-400'
                        : 'border-slate-200/80 bg-white hover:border-indigo-300 hover:shadow-xs'
                    }`}
                  >
                    {/* Day Top: Solar day number & Lunar text */}
                    <div>
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-xs font-bold leading-none ${
                            isToday
                              ? 'w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center'
                              : isSunday
                              ? 'text-rose-600'
                              : isSaturday
                              ? 'text-blue-600'
                              : 'text-slate-800'
                          }`}
                        >
                          {dayItem.gregorianDate.getDate()}
                        </span>

                        {/* Lunar Moon & Phase Badge */}
                        <div className="flex items-center gap-0.5">
                          {dayItem.isHolyDay && (
                            <span className="text-[10px]" title={`ថ្ងៃសីល (${dayItem.holyDayType})`}>
                              🪷
                            </span>
                          )}
                          <span className="text-[11px] select-none">
                            {dayItem.moonEmoji}
                          </span>
                        </div>
                      </div>

                      {/* Khmer Lunar Date Subtitle */}
                      <p
                        className={`text-[10px] leading-tight pt-0.5 font-sans font-medium truncate ${
                          dayItem.isHolyDay
                            ? 'text-amber-800 font-bold'
                            : 'text-slate-500'
                        }`}
                      >
                        {dayItem.phaseTextKh}
                      </p>
                    </div>

                    {/* Events Mini Badges */}
                    <div className="space-y-1 mt-1">
                      {dayEvents.slice(0, 2).map((evt) => {
                        const style = getCategoryBadge(evt.category);
                        return (
                          <div
                            key={evt.id}
                            className={`text-[9px] px-1 py-0.5 rounded font-medium truncate border leading-none ${style.bg}`}
                            title={`${evt.titleKh} (${evt.time || ''})`}
                          >
                            {evt.indicatorCode ? `[${evt.indicatorCode}] ` : ''}
                            {evt.titleKh}
                          </div>
                        );
                      })}
                      {dayEvents.length > 2 && (
                        <span className="text-[9px] font-bold text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded block text-center">
                          +{dayEvents.length - 2} ទៀត
                        </span>
                      )}

                      {/* Holiday Badge if any */}
                      {dayItem.holidayNameKh && (
                        <div className="text-[9px] px-1 py-0.5 rounded font-bold truncate bg-rose-50 text-rose-700 border border-rose-200">
                          🎉 {dayItem.holidayNameKh}
                        </div>
                      )}
                    </div>

                    {/* Quick Add Hover Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openNewEventModal(dayItem.gregorianDateStr);
                      }}
                      className="absolute bottom-1 right-1 p-0.5 rounded bg-indigo-600 text-white opacity-0 group-hover:opacity-100 transition-opacity shadow-xs"
                      title="បន្ថែមព្រឹត្តិការណ៍លើថ្ងៃនេះ"
                    >
                      <Plus className="w-2.5 h-2.5" />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-amber-100 border border-amber-300 inline-block" />
                <span>🪷 ថ្ងៃសីល (៨កើត, ១៥កើត, ៨រោច, ១៤/១៥រោច)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-emerald-100 border border-emerald-300 inline-block" />
                <span>ស្តង់ដាទី១</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-blue-100 border border-blue-300 inline-block" />
                <span>ស្តង់ដាទី២</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-purple-100 border border-purple-300 inline-block" />
                <span>ស្តង់ដាទី៣</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-amber-100 border border-amber-300 inline-block" />
                <span>ស្តង់ដាទី៤</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-indigo-100 border border-indigo-300 inline-block" />
                <span>ស្តង់ដាទី៥</span>
              </div>
            </div>
          </div>

          {/* Right 4 cols: Selected Day Details & Event Agenda */}
          <div className="lg:col-span-4 space-y-4">
            
            {/* Selected Date Card */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold text-indigo-900 flex items-center gap-1">
                  <CalendarIcon className="w-3.5 h-3.5 text-indigo-600" />
                  <span>ព័ត៌មានលម្អិតថ្ងៃដែលបានជ្រើស</span>
                </span>
                <button
                  onClick={() => openNewEventModal(selectedDateStr)}
                  className="px-2 py-1 text-[11px] font-bold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3 h-3" />
                  <span>បន្ថែម</span>
                </button>
              </div>

              {/* Full Lunar & Solar Text for Selected Date */}
              <div className="bg-amber-50/60 rounded-xl p-3.5 border border-amber-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">
                    កាលបរិច្ឆេទចន្ទគតិ
                  </span>
                  <button
                    onClick={() => handleCopyLunar(selectedDateLunar.fullLunarDateKh)}
                    className="text-[10px] font-bold text-amber-800 hover:text-amber-950 flex items-center gap-0.5"
                    title="ចម្លងអត្ថបទចន្ទគតិ"
                  >
                    <Copy className="w-2.5 h-2.5" />
                    <span>ចម្លង</span>
                  </button>
                </div>
                <p className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                  {selectedDateLunar.fullLunarDateKh}
                </p>
                <p className="text-xs text-slate-600 pt-1 border-t border-amber-200/50">
                  <span className="font-semibold">សុរិយគតិ៖ </span>
                  {selectedDateLunar.solarDateFormattedKh}
                </p>
                {selectedDateLunar.isHolyDay && (
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-200/80 text-amber-900 text-[11px] font-bold">
                    <span>🪷</span>
                    <span>ថ្ងៃសីល ({selectedDateLunar.holyDayType})</span>
                  </div>
                )}
                {selectedDateLunar.holidayNameKh && (
                  <div className="block mt-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    🎉 {selectedDateLunar.holidayNameKh}
                  </div>
                )}
              </div>

              {/* Events Scheduled on Selected Date */}
              <div className="space-y-2 pt-1">
                <h4 className="text-xs font-bold text-slate-800 flex items-center justify-between">
                  <span>ផែនការសកម្មភាព ({selectedDateEvents.length})</span>
                  {selectedDateEvents.length === 0 && (
                    <span className="text-[11px] font-normal text-slate-400">គ្មានសកម្មភាព</span>
                  )}
                </h4>

                {selectedDateEvents.length > 0 ? (
                  <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                    {selectedDateEvents.map((evt) => {
                      const catBadge = getCategoryBadge(evt.category);
                      const statusBadge = getStatusBadge(evt.status);
                      return (
                        <div
                          key={evt.id}
                          className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-indigo-300 transition-all space-y-2 group shadow-2xs"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <h5 className="text-xs font-bold text-slate-900 leading-snug">
                              {evt.titleKh}
                            </h5>
                            <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 shrink-0">
                              <button
                                onClick={() => openEditEventModal(evt)}
                                className="p-1 rounded hover:bg-slate-200 text-slate-600 hover:text-indigo-600"
                                title="កែសម្រួល"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => handleDeleteEvent(evt.id)}
                                className="p-1 rounded hover:bg-rose-100 text-slate-400 hover:text-rose-600"
                                title="លុប"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>

                          {/* Tags */}
                          <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                            <span className={`px-1.5 py-0.5 rounded border font-semibold ${catBadge.bg}`}>
                              {catBadge.label}
                            </span>
                            {evt.indicatorCode && (
                              <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 font-bold border border-indigo-200">
                                សូចនាករ {evt.indicatorCode}
                              </span>
                            )}
                            <span className={`px-1.5 py-0.5 rounded border ${statusBadge.bg}`}>
                              {statusBadge.label}
                            </span>
                          </div>

                          {/* Metadata */}
                          <div className="grid grid-cols-1 gap-1 text-[11px] text-slate-600 pt-1 border-t border-slate-200/60">
                            {evt.time && (
                              <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span>{evt.time}</span>
                              </div>
                            )}
                            {evt.location && (
                              <div className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{evt.location}</span>
                              </div>
                            )}
                            {evt.responsiblePerson && (
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{evt.responsiblePerson}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl space-y-2">
                    <p className="text-xs text-slate-500">ពុំទាន់មានសកម្មភាពសម្រាប់ថ្ងៃនេះទេ</p>
                    <button
                      onClick={() => openNewEventModal(selectedDateStr)}
                      className="px-3 py-1 text-xs font-bold rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200"
                    >
                      + បន្ថែមសកម្មភាពថ្មី
                    </button>
                  </div>
                )}
              </div>

            </div>

            {/* Quick MoEYS Standard Alignment Box */}
            <div className="bg-indigo-900 text-white rounded-2xl p-4 space-y-2 shadow-sm">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-300" />
                <h4 className="text-xs font-bold">អនុលោមតាមស្តង់ដាសាលារៀនគំរូ</h4>
              </div>
              <p className="text-[11px] text-indigo-200 leading-relaxed">
                រាល់សកម្មភាពដែលបានគ្រោងទុកក្នុងប្រតិទិន អាចភ្ជាប់ជាភស្តុតាង និងបញ្ចូលក្នុងក្រូណូឯកសារទាំង ៥ បានយ៉ាងងាយស្រួល។
              </p>
            </div>

          </div>

        </div>
      )}

      {/* List View Tab */}
      {activeTab === 'list' && (
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 font-moul">
                តារាងផែនការ និងព្រឹត្តិការណ៍សាលារៀនសរុប ({filteredEvents.length})
              </h3>
            </div>

            {/* Search Input */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="ស្វែងរកតាមចំណងជើង អ្នកទទួលខុសត្រូវ..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-xl bg-white w-56 sm:w-64 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-2.5 py-1.5 text-xs font-semibold border border-slate-300 rounded-xl bg-white text-slate-700"
              >
                <option value="all">គ្រប់ប្រភេទ</option>
                <option value="standards">ស្តង់ដាទាំង ៥</option>
                <option value="exam">ការប្រឡង</option>
                <option value="meeting">កិច្ចប្រជុំ</option>
                <option value="holiday">បុណ្យជាតិ</option>
              </select>
            </div>
          </div>

          {/* Events Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-y border-slate-200 text-slate-700 font-bold">
                  <th className="py-2.5 px-3">ល.រ</th>
                  <th className="py-2.5 px-3">កាលបរិច្ឆេទសកល & ចន្ទគតិ</th>
                  <th className="py-2.5 px-3">សកម្មភាព / ព្រឹត្តិការណ៍</th>
                  <th className="py-2.5 px-3">ប្រភេទ / ស្តង់ដា</th>
                  <th className="py-2.5 px-3">ទីកន្លែង & ម៉ោង</th>
                  <th className="py-2.5 px-3">អ្នកទទួលខុសត្រូវ</th>
                  <th className="py-2.5 px-3">ស្ថានភាព</th>
                  <th className="py-2.5 px-3 text-right">សកម្មភាព</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredEvents.map((evt, idx) => {
                  const lunarInfo = gregorianToKhmerLunar(evt.gregorianDate);
                  const catBadge = getCategoryBadge(evt.category);
                  const statusBadge = getStatusBadge(evt.status);

                  return (
                    <tr key={evt.id} className="hover:bg-indigo-50/30 transition-colors">
                      <td className="py-3 px-3 font-semibold text-slate-500">
                        {toKhmerNum(idx + 1)}
                      </td>
                      <td className="py-3 px-3 space-y-0.5">
                        <span className="font-bold text-slate-900 block font-sans">
                          {evt.gregorianDate}
                        </span>
                        <span className="text-[11px] text-amber-800 font-semibold block font-sans">
                          {lunarInfo.shortLunarDateKh} {lunarInfo.moonEmoji}
                        </span>
                        {lunarInfo.isHolyDay && (
                          <span className="text-[10px] bg-amber-100 text-amber-900 px-1 rounded font-bold">
                            🪷 ថ្ងៃសីល
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-slate-900 block text-xs">
                          {evt.titleKh}
                        </span>
                        {evt.descriptionKh && (
                          <p className="text-[11px] text-slate-500 line-clamp-1 max-w-xs">
                            {evt.descriptionKh}
                          </p>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${catBadge.bg}`}>
                          {catBadge.label}
                        </span>
                        {evt.indicatorCode && (
                          <span className="ml-1 text-[10px] font-bold text-indigo-700">
                            (សូចនាករ {evt.indicatorCode})
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-slate-600 text-[11px]">
                        <div>{evt.location || 'សាលារៀន'}</div>
                        <div className="text-slate-400">{evt.time || 'ពេលព្រឹក'}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-700 font-medium">
                        {evt.responsiblePerson || 'នាយកសាលា'}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${statusBadge.bg}`}>
                          {statusBadge.label}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openEditEventModal(evt)}
                            className="p-1 rounded hover:bg-slate-200 text-slate-600 hover:text-indigo-600"
                            title="កែសម្រួល"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteEvent(evt.id)}
                            className="p-1 rounded hover:bg-rose-100 text-slate-400 hover:text-rose-600"
                            title="លុប"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Event Modal */}
      {isEventModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold">
                  <CalendarIcon className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-slate-900 font-moul">
                  {editingEvent ? 'កែសម្រួលព្រឹត្តិការណ៍សាលារៀន' : 'បន្ថែមព្រឹត្តិការណ៍សាលារៀនថ្មី'}
                </h3>
              </div>
              <button
                onClick={() => setIsEventModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveEvent} className="space-y-4 text-xs">
              
              {/* Event Title */}
              <div className="space-y-1">
                <label className="font-bold text-slate-800">
                  ឈ្មោះកម្មវិធី / ព្រឹត្តិការណ៍ <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="ឧទាហរណ៍៖ យុទ្ធនាការចុះឈ្មោះកុមារអាយុ ៦ឆ្នាំ"
                  value={formTitleKh}
                  onChange={(e) => setFormTitleKh(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-medium focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Date with Dynamic Lunar Preview */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 flex items-center justify-between">
                  <span>កាលបរិច្ឆេទសកល (Gregorian Date) <span className="text-rose-600">*</span></span>
                </label>
                <input
                  type="date"
                  required
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-semibold focus:ring-2 focus:ring-indigo-500 shadow-inner"
                />
                
                {/* Live Synchronized Lunar Calculation */}
                {formDate && (
                  <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-slate-800 space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-800">
                      <span>កាលបរិច្ឆេទចន្ទគតិខ្មែរ (ស្វ័យប្រវត្តិ)៖</span>
                      <span>{gregorianToKhmerLunar(formDate).moonEmoji}</span>
                    </div>
                    <p className="text-xs font-bold text-amber-950 font-sans">
                      {gregorianToKhmerLunar(formDate).fullLunarDateKh}
                    </p>
                    {gregorianToKhmerLunar(formDate).isHolyDay && (
                      <span className="inline-block text-[10px] font-bold text-amber-900 bg-amber-200/70 px-1.5 py-0.5 rounded">
                        🪷 ថ្ងៃសីល ({gregorianToKhmerLunar(formDate).holyDayType})
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Category & Standard */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">ប្រភេទកម្មវិធី</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as SchoolEventCategory)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
                  >
                    <option value="standard_1">ស្តង់ដាទី ១ (លទ្ធផលសិស្ស)</option>
                    <option value="standard_2">ស្តង់ដាទី ២ (ការបង្រៀន/រៀន)</option>
                    <option value="standard_3">ស្តង់ដាទី ៣ (គ.គ.ស/សហគមន៍)</option>
                    <option value="standard_4">ស្តង់ដាទី ៤ (ប្រតិបត្តិការសាលា)</option>
                    <option value="standard_5">ស្តង់ដាទី ៥ (គណនេយ្យភាព)</option>
                    <option value="exam">ការប្រឡង និងតេស្ត</option>
                    <option value="meeting">កិច្ចប្រជុំបច្ចេកទេស/រដ្ឋបាល</option>
                    <option value="national_holiday">ពិធីបុណ្យជាតិ</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-800">សូចនាករពាក់ព័ន្ធ</label>
                  <input
                    type="text"
                    placeholder="ឧ. ១.១, ២.៣"
                    value={formIndicatorCode}
                    onChange={(e) => setFormIndicatorCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
                  />
                </div>
              </div>

              {/* Time & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">ពេលវេលា / ម៉ោង</label>
                  <input
                    type="text"
                    placeholder="08:00 - 11:00"
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-800">ទីកន្លែង</label>
                  <input
                    type="text"
                    placeholder="សាលារៀន"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
                  />
                </div>
              </div>

              {/* Responsible Person & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-800">អ្នកទទួលខុសត្រូវ</label>
                  <input
                    type="text"
                    placeholder="Tong Un / នាយកសាលា"
                    value={formResponsible}
                    onChange={(e) => setFormResponsible(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-medium"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-800">ស្ថានភាព</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as SchoolEventStatus)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-medium"
                  >
                    <option value="planned">បានគ្រោងទុក (Planned)</option>
                    <option value="in_progress">កំពុងអនុវត្ត (In Progress)</option>
                    <option value="completed">សម្រេចបាន (Completed)</option>
                    <option value="postponed">ពន្យារពេល (Postponed)</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <label className="font-bold text-slate-800">ការពិពណ៌នាសង្ខេប</label>
                <textarea
                  rows={2}
                  placeholder="ព័ត៌មានបន្ថែម ឬកំណត់សម្គាល់អំពីសកម្មភាព..."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
                />
              </div>

              {/* Modal Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEventModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors"
                >
                  បោះបង់
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-colors shadow-sm shadow-indigo-600/20"
                >
                  {editingEvent ? 'រក្សាទុកការកែប្រែ' : 'បន្ថែមព្រឹត្តិការណ៍'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
