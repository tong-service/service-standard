import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  FileUp, 
  FileText, 
  Image as ImageIcon, 
  FileSpreadsheet, 
  CheckCircle2, 
  Layers,
  AlertCircle
} from 'lucide-react';
import { ChronoDocumentType } from '../types/chrono';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';
import { useChrono } from '../context/ChronoContext';
import { useEvaluation } from '../context/EvaluationContext';

interface ImportFileModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultStandard?: number | null;
  defaultIndicatorId?: string | null;
}

export const ImportFileModal: React.FC<ImportFileModalProps> = ({
  isOpen,
  onClose,
  defaultStandard = 1,
  defaultIndicatorId
}) => {
  const { importFileAsDocument } = useChrono();
  const { lang } = useEvaluation();

  const [standardNumber, setStandardNumber] = useState<number>(defaultStandard || 1);
  const [indicatorId, setIndicatorId] = useState<string>(defaultIndicatorId || 'std1_1_1');
  const [customTitle, setCustomTitle] = useState<string>('');
  const [documentType, setDocumentType] = useState<ChronoDocumentType>('activity_report');
  
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreviewUrl, setFilePreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const standardIndicators = ALL_INDICATORS.filter(ind => ind.standardNumber === standardNumber);

  if (!isOpen) return null;

  const handleStandardChange = (num: number) => {
    setStandardNumber(num);
    const firstInd = ALL_INDICATORS.find(ind => ind.standardNumber === num);
    if (firstInd) {
      setIndicatorId(firstInd.id);
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    if (!customTitle || customTitle.trim() === '') {
      setCustomTitle(file.name.replace(/\.[^/.]+$/, ""));
    }

    if (file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setFilePreviewUrl(url);
      setDocumentType('evidence_photo');
    } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls') || file.name.endsWith('.csv')) {
      setDocumentType('student_list');
      setFilePreviewUrl(null);
    } else {
      setFilePreviewUrl(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setIsUploading(true);
    try {
      await importFileAsDocument(selectedFile, {
        standardNumber,
        indicatorId,
        titleKh: customTitle || selectedFile.name,
        documentType
      });

      setUploadSuccess(true);
      setTimeout(() => {
        setIsUploading(false);
        onClose();
      }, 700);
    } catch (err) {
      console.error('File import error:', err);
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
              <FileUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                {lang === 'km' ? 'Import ឯកសារភស្តុតាងចូលក្រូណូ' : 'Import Evidence File to Chrono'}
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'km' ? 'គាំទ្រគ្រប់ប្រភេទឯកសារ៖ PDF, Photos/Images, Word .docx, Excel .xlsx, CSV, TXT' : 'Supports PDF, Images, Word, Excel, CSV, TXT'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {uploadSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'km' ? 'បានបញ្ចូលឯកសារចូលក្នុងក្រូណូដោយជោគជ័យ!' : 'File imported successfully!'}</span>
            </div>
          )}

          {/* Target Chrono Standard & Indicator */}
          <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                <span>{lang === 'km' ? 'ក្រូណូស្តង់ដាគោលដៅ' : 'Target Chrono'}</span>
              </label>
              <select
                value={standardNumber}
                onChange={(e) => handleStandardChange(Number(e.target.value))}
                className="w-full px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 bg-white"
              >
                {STANDARDS_METADATA.map(s => (
                  <option key={s.number} value={s.number}>
                    ក្រូណូទី {s.number} ({s.shortKh})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {lang === 'km' ? 'សូចនាករ' : 'Indicator'}
              </label>
              <select
                value={indicatorId}
                onChange={(e) => setIndicatorId(e.target.value)}
                className="w-full px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 bg-white"
              >
                {standardIndicators.map(ind => (
                  <option key={ind.id} value={ind.id}>
                    {ind.code} - {ind.expectedResultKh.substring(0, 30)}...
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Drag & Drop File Zone */}
          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFileSelect(file);
              }}
              className="hidden"
            />

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-6 border-2 border-dashed rounded-2xl text-center cursor-pointer transition-all ${
                isDragOver 
                  ? 'border-indigo-500 bg-indigo-50/50' 
                  : selectedFile 
                    ? 'border-emerald-300 bg-emerald-50/40' 
                    : 'border-slate-300 bg-slate-50 hover:bg-slate-100/70'
              }`}
            >
              {selectedFile ? (
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-xl flex items-center justify-center mx-auto">
                    {selectedFile.type.startsWith('image/') ? (
                      <ImageIcon className="w-6 h-6" />
                    ) : selectedFile.name.endsWith('.xlsx') || selectedFile.name.endsWith('.csv') ? (
                      <FileSpreadsheet className="w-6 h-6" />
                    ) : (
                      <FileText className="w-6 h-6" />
                    )}
                  </div>
                  <div>
                    <p className="font-bold text-xs text-slate-800">{selectedFile.name}</p>
                    <p className="text-[11px] text-slate-500">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-bold"
                  >
                    {lang === 'km' ? 'ប្តូរ File ផ្សេង' : 'Change file'}
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-xs text-slate-800">
                      {lang === 'km' ? 'ចុចទីនេះ ឬអូសទម្លាក់ File ចូល (Drag & Drop)' : 'Click to browse or drag file here'}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      PDF, JPG, PNG, DOCX, XLSX, CSV, TXT (រហូតដល់ 50MB)
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Custom Title & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-800 mb-1">
                {lang === 'km' ? 'ចំណងជើងឯកសារក្នុងក្រូណូ' : 'Document Title'}
              </label>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="ឈ្មោះឯកសារភស្តុតាង..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                {lang === 'km' ? 'ប្រភេទឯកសារ' : 'Category'}
              </label>
              <select
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value as ChronoDocumentType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
              >
                <option value="activity_report">របាយការណ៍សកម្មភាព</option>
                <option value="evidence_photo">រូបភាពភស្តុតាង</option>
                <option value="verification_report">របាយការណ៍ផ្ទៀងផ្ទាត់</option>
                <option value="meeting_minutes">កំណត់ហេតុ</option>
                <option value="student_list">បញ្ជីសិស្ស / ពិន្ទុ</option>
                <option value="observation_sheet">កិច្ចតែងការ / សង្កេត</option>
                <option value="other">ឯកសារផ្សេងៗ</option>
              </select>
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              {lang === 'km' ? 'បោះបង់' : 'Cancel'}
            </button>

            <button
              type="submit"
              disabled={!selectedFile || isUploading}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-600/20 disabled:opacity-50 flex items-center gap-1.5"
            >
              <Upload className="w-4 h-4" />
              <span>{isUploading ? (lang === 'km' ? 'កំពុង Import...' : 'Importing...') : (lang === 'km' ? 'Import ចូលក្រូណូ' : 'Import to Chrono')}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
