import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  Send, 
  Layers, 
  Calendar,
  Building,
  RefreshCw,
  Eye,
  Edit3,
  MapPin,
  UserCheck
} from 'lucide-react';
import { ChronoDocument, ChronoDocumentType } from '../types/chrono';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';
import { useChrono } from '../context/ChronoContext';
import { useAuth } from '../context/AuthContext';
import { useEvaluation } from '../context/EvaluationContext';
import { NationalDocumentHeader } from './NationalDocumentHeader';
import { NationalDocumentFooter } from './NationalDocumentFooter';
import { toKhmerNum, getKhmerLunarSolarDate, cleanMarkdownBody } from '../utils/khmerDateUtils';

interface DocumentEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDocument?: ChronoDocument | null;
  defaultStandard?: number | null;
  defaultIndicatorId?: string | null;
}

export const DocumentEditorModal: React.FC<DocumentEditorModalProps> = ({
  isOpen,
  onClose,
  initialDocument,
  defaultStandard = 1,
  defaultIndicatorId
}) => {
  const { addDocument, updateDocument, generateAiDocument, enhanceTextWithAi } = useChrono();
  const { userProfile } = useAuth();
  const { academicYear, lang } = useEvaluation();

  const defaultDates = getKhmerLunarSolarDate(new Date(), userProfile?.district || userProfile?.province || 'រោគ');

  const [standardNumber, setStandardNumber] = useState<number>(
    initialDocument?.standardNumber || defaultStandard || 1
  );
  const [indicatorId, setIndicatorId] = useState<string>(
    initialDocument?.indicatorId || defaultIndicatorId || 'std1_1_1'
  );
  const [documentType, setDocumentType] = useState<ChronoDocumentType>(
    initialDocument?.documentType || 'activity_report'
  );
  const [titleKh, setTitleKh] = useState<string>(
    initialDocument?.titleKh || ''
  );
  const [documentNumber, setDocumentNumber] = useState<string>(
    initialDocument?.documentNumber || `លេខ.../${toKhmerNum(academicYear || '២៥-២៦')} របក.សរ`
  );
  const [dateKh, setDateKh] = useState<string>(
    initialDocument?.dateKh || defaultDates.solarDateKh
  );
  const [summaryKh, setSummaryKh] = useState<string>(
    initialDocument?.summaryKh || ''
  );
  const [contentMarkdown, setContentMarkdown] = useState<string>(
    initialDocument?.contentMarkdown || ''
  );
  const [status, setStatus] = useState(
    initialDocument?.status || 'ready_for_signature'
  );

  // Administrative hierarchy fields
  const [administrationLine1, setAdministrationLine1] = useState<string>(
    initialDocument?.administrationLine1 || (userProfile?.province ? `រដ្ឋបាលខេត្ត${userProfile.province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា')
  );
  const [administrationLine2, setAdministrationLine2] = useState<string>(
    initialDocument?.administrationLine2 || (userProfile?.district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${userProfile.district}` : 'ការិយាល័យអប់រំ យុវជន និងកីឡា')
  );
  const [administrationLine3, setAdministrationLine3] = useState<string>(
    initialDocument?.administrationLine3 || 'កម្រងស្ថានីយសាលារៀនគំរូ'
  );
  const [administrationLine4, setAdministrationLine4] = useState<string>(
    initialDocument?.administrationLine4 || userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ'
  );

  // Lunar / Solar Date & Signatures
  const [locationKh, setLocationKh] = useState<string>(
    initialDocument?.locationKh || userProfile?.district || 'រោគ'
  );
  const [lunarDateKh, setLunarDateKh] = useState<string>(
    initialDocument?.lunarDateKh || defaultDates.lunarDateKh
  );
  const [solarDateKh, setSolarDateKh] = useState<string>(
    initialDocument?.solarDateKh || defaultDates.solarDateKh
  );
  const [secondApproverRole, setSecondApproverRole] = useState<string>(
    initialDocument?.secondApproverRole || 'ប្រធានគណៈកម្មការ គ.គ.ស'
  );
  const [secondApproverName, setSecondApproverName] = useState<string>(
    initialDocument?.secondApproverName || ''
  );
  const [approverRole, setApproverRole] = useState<string>(
    initialDocument?.approverRole || 'នាយកសាលារៀន'
  );
  const [approverName, setApproverName] = useState<string>(
    initialDocument?.approverName || userProfile?.displayName || ''
  );
  const [reporterRole, setReporterRole] = useState<string>(
    initialDocument?.reporterRole || 'អ្នកទទួលបន្ទុកស្តង់ដា'
  );
  const [reporterName, setReporterName] = useState<string>(
    initialDocument?.reporterName || userProfile?.displayName || 'Tong Un'
  );

  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [isAiEnhancing, setIsAiEnhancing] = useState(false);
  const [aiCustomPrompt, setAiCustomPrompt] = useState('');
  const [showAiPromptBox, setShowAiPromptBox] = useState(false);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Filter indicators by selected standard
  const standardIndicators = ALL_INDICATORS.filter(ind => ind.standardNumber === standardNumber);
  const selectedIndicator = ALL_INDICATORS.find(ind => ind.id === indicatorId);

  // Auto-refresh Khmer Dates based on current date & location
  const handleRecalculateDate = () => {
    const calc = getKhmerLunarSolarDate(new Date(), locationKh || 'រោគ');
    setLunarDateKh(calc.lunarDateKh);
    setSolarDateKh(calc.solarDateKh);
    setDateKh(calc.solarDateKh);
  };

  // Convert all numbers in the form to Khmer numerals
  const handleConvertNumbersToKhmer = () => {
    setTitleKh(prev => toKhmerNum(prev));
    setDocumentNumber(prev => toKhmerNum(prev));
    setSummaryKh(prev => toKhmerNum(prev));
    setContentMarkdown(prev => toKhmerNum(prev));
    setLunarDateKh(prev => toKhmerNum(prev));
    setSolarDateKh(prev => toKhmerNum(prev));
  };

  // Handle Standard Change
  const handleStandardChange = (num: number) => {
    setStandardNumber(num);
    const firstInd = ALL_INDICATORS.find(ind => ind.standardNumber === num);
    if (firstInd) {
      setIndicatorId(firstInd.id);
    }
  };

  // Generate Sample MoEYS Template with AI
  const handleAiGenerate = async () => {
    setIsAiGenerating(true);
    try {
      const generated = await generateAiDocument({
        standardNumber,
        indicatorId,
        indicatorCode: selectedIndicator?.code || '១.១',
        indicatorTitleKh: selectedIndicator?.expectedResultKh,
        activitiesKh: selectedIndicator?.activitiesKh,
        documentType,
        customInstructions: aiCustomPrompt
      });

      // Update fields
      setTitleKh(generated.titleKh);
      setDocumentNumber(generated.documentNumber ? toKhmerNum(generated.documentNumber) : `លេខ.../${toKhmerNum(academicYear || '២៥-២៦')} របក.សរ`);
      if (generated.lunarDateKh) setLunarDateKh(generated.lunarDateKh);
      if (generated.solarDateKh) setSolarDateKh(generated.solarDateKh);
      setDateKh(generated.solarDateKh || generated.dateKh || solarDateKh);
      setSummaryKh(generated.summaryKh);
      setContentMarkdown(cleanMarkdownBody(generated.contentMarkdown));
      setShowAiPromptBox(false);
      setAiCustomPrompt('');
    } catch (e) {
      console.error('AI generation error:', e);
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Enhance Current Text with AI
  const handleAiEnhance = async () => {
    if (!contentMarkdown || contentMarkdown.trim() === '') return;
    setIsAiEnhancing(true);
    try {
      const enhanced = await enhanceTextWithAi({
        rawText: contentMarkdown,
        standardNumber,
        indicatorCode: selectedIndicator?.code,
        documentType
      });

      setContentMarkdown(cleanMarkdownBody(enhanced.enhancedMarkdown));
      if (enhanced.titleKh && (!titleKh || titleKh === '')) {
        setTitleKh(enhanced.titleKh);
      }
    } catch (e) {
      console.error('AI enhance error:', e);
    } finally {
      setIsAiEnhancing(false);
    }
  };

  // Save Document
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleKh || titleKh.trim() === '') return;

    const ind = ALL_INDICATORS.find(i => i.id === indicatorId);

    const docPayload = {
      standardNumber,
      indicatorId,
      indicatorCode: ind?.code || '១.១',
      sectionNumber: ind?.sectionNumber || 1,
      sectionTitleKh: ind?.sectionTitleKh || `ស្តង់ដាទី${standardNumber}`,
      titleKh,
      documentNumber,
      dateKh: solarDateKh || dateKh,
      documentType,
      status,
      summaryKh,
      contentMarkdown,
      administrationLine1,
      administrationLine2,
      administrationLine3,
      administrationLine4,
      locationKh,
      lunarDateKh,
      solarDateKh,
      secondApproverRole,
      secondApproverName,
      approverRole,
      approverName,
      reporterRole,
      reporterName
    };

    if (initialDocument) {
      await updateDocument(initialDocument.id, docPayload);
    } else {
      await addDocument({
        ...docPayload,
        schoolId: userProfile?.schoolName || 'សាលារៀនគំរូ',
        userId: userProfile?.uid || 'guest',
        fileType: 'text',
        authorName: reporterName || userProfile?.displayName || 'នាយកសាលា',
        academicYear: academicYear || '2025-2026'
      });
    }

    setSaveSuccess(true);
    setTimeout(() => {
      onClose();
    }, 600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight text-white flex items-center gap-2">
                <span>{initialDocument ? (lang === 'km' ? 'កែសម្រួលឯកសារក្នុងក្រូណូ' : 'Edit Chrono Document') : (lang === 'km' ? 'បង្កើតឯកសារភស្តុតាងថ្មី' : 'Create Chrono Document')}</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 font-medium">
                  ក្រូណូទី {toKhmerNum(standardNumber)}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'km' ? 'តាក់តែងឯកសាររដ្ឋបាលអប់រំ និងភស្តុតាងតាមក្បួនខ្នាតក្រសួង' : 'Standard-compliant educational document & evidence'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab switch for Editor vs Preview */}
            <div className="bg-white/10 p-1 rounded-xl flex items-center text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className={`px-3 py-1 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'editor' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'ទម្រង់កែសម្រួល' : 'Editor'}</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'preview' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'ទម្រង់លិខិតផ្លូវការ' : 'Official Preview'}</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* AI Quick Bar */}
        <div className="px-6 py-2.5 bg-indigo-50 border-b border-indigo-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-indigo-900 font-semibold">
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
            <span>{lang === 'km' ? 'ជំនួយការ AI សាលារៀនគំរូ៖' : 'AI Education Assistant:'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleConvertNumbersToKhmer}
              className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer transition-all"
              title="ប្តូរលេខទាំងអស់ជាលេខខ្មែរ (០-៩)"
            >
              <span>០-៩ លេខខ្មែរ</span>
            </button>

            <button
              type="button"
              disabled={isAiGenerating || isAiEnhancing}
              onClick={() => setShowAiPromptBox(!showAiPromptBox)}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-xs transition-all disabled:opacity-50 cursor-pointer"
            >
              {isAiGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{lang === 'km' ? 'កំពុងបង្កើតឯកសារគំរូ...' : 'Generating...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lang === 'km' ? '✨ បង្កើតឯកសារគំរូពេញលេញដោយ AI' : 'Generate Full Template'}</span>
                </>
              )}
            </button>

            <button
              type="button"
              disabled={isAiEnhancing || !contentMarkdown}
              onClick={handleAiEnhance}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-indigo-700 border border-indigo-200 rounded-lg font-bold flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer"
            >
              {isAiEnhancing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{lang === 'km' ? 'កំពុងកែលម្អ...' : 'Polishing...'}</span>
                </>
              ) : (
                <>
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{lang === 'km' ? '✨ កែលម្អភាសារដ្ឋបាល' : 'Polish with AI'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Custom AI Prompt expandable box */}
        {showAiPromptBox && (
          <div className="px-6 py-3 bg-indigo-900/5 border-b border-indigo-100 animate-in slide-in-from-top-2 duration-150">
            <label className="block text-xs font-bold text-indigo-950 mb-1.5">
              {lang === 'km' ? 'បញ្ចូលសេចក្តីណែនាំបន្ថែមសម្រាប់ AI (ឧទាហរណ៍៖ បញ្ជាក់ទិន្នន័យជាក់ស្តែង ឬសកម្មភាពពិសេស)' : 'Custom AI Instructions'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={aiCustomPrompt}
                onChange={(e) => setAiCustomPrompt(e.target.value)}
                placeholder="ឧ. សាលាបានចុះស្រង់ស្ថិតិបានសិស្ស ៤៨ នាក់, មានកិច្ចប្រជុំជាមួយមាតាបិតា ៣ លើក..."
                className="flex-1 px-3 py-2 text-xs border border-indigo-200 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAiGenerate();
                  }
                }}
              />
              <button
                type="button"
                disabled={isAiGenerating}
                onClick={handleAiGenerate}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'បង្កើតឥឡូវនេះ' : 'Generate Now'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-5">
          
          {saveSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'km' ? 'ឯកសារត្រូវបានរក្សាទុកក្នុងក្រូណូ និង Firestore ដោយជោគជ័យ!' : 'Document saved successfully!'}</span>
            </div>
          )}

          {activeTab === 'editor' ? (
            <div className="space-y-4">
              
              {/* Classification Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                {/* Standard Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-indigo-600" />
                    <span>{lang === 'km' ? 'ជ្រើសរើសក្រូណូស្តង់ដា' : 'Target Standard'}</span>
                  </label>
                  <select
                    value={standardNumber}
                    onChange={(e) => handleStandardChange(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white cursor-pointer"
                  >
                    {STANDARDS_METADATA.map(s => (
                      <option key={s.number} value={s.number}>
                        ក្រូណូទី {toKhmerNum(s.number)} ({s.shortKh})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Indicator Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'km' ? 'សូចនាករដែលពាក់ព័ន្ធ' : 'Related Indicator'}
                  </label>
                  <select
                    value={indicatorId}
                    onChange={(e) => setIndicatorId(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white cursor-pointer"
                  >
                    {standardIndicators.map(ind => (
                      <option key={ind.id} value={ind.id}>
                        {toKhmerNum(ind.code)} - {ind.expectedResultKh.substring(0, 38)}...
                      </option>
                    ))}
                  </select>
                </div>

                {/* Document Type Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'km' ? 'ប្រភេទឯកសាររដ្ឋបាល' : 'Document Type'}
                  </label>
                  <select
                    value={documentType}
                    onChange={(e) => setDocumentType(e.target.value as ChronoDocumentType)}
                    className="w-full px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white cursor-pointer"
                  >
                    <option value="activity_report">របាយការណ៍សកម្មភាពអនុវត្ត</option>
                    <option value="verification_report">របាយការណ៍ផ្ទៀងផ្ទាត់ និងវាយតម្លៃ</option>
                    <option value="action_plan">ផែនការសកម្មភាព / ផែនការកែលម្អ</option>
                    <option value="meeting_minutes">កំណត់ហេតុប្រជុំ គ.គ.ស</option>
                    <option value="moeys_decision">សេចក្តីសម្រេច / លិខិតបទដ្ឋាន</option>
                    <option value="student_list">បញ្ជីស្ថិតិ / លទ្ធផលសិក្សាសិស្ស</option>
                    <option value="observation_sheet">តារាងសង្កេតការបង្រៀន / កិច្ចតែងការ</option>
                    <option value="evidence_photo">កម្រងរូបភាពភស្តុតាង</option>
                    <option value="financial_receipt">របាយការណ៍ហិរញ្ញវត្ថុ / វិក្កយបត្រ</option>
                    <option value="other">ឯកសារផ្សេងៗ</option>
                  </select>
                </div>
              </div>

              {/* Administrative Hierarchy Setup (National Standard Header) */}
              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span className="flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-indigo-600" />
                    <span>រចនាសម្ព័ន្ធរដ្ឋបាលថ្នាក់ជាតិ (Header Hierarchy)</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">តម្រឹមឆ្វេងតាមស្តង់ដារដ្ឋបាល</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                  <div>
                    <label className="text-[11px] text-slate-600">ថ្នាក់ទី១ (ខេត្ត/ក្រសួង)</label>
                    <input
                      type="text"
                      value={administrationLine1}
                      onChange={(e) => setAdministrationLine1(e.target.value)}
                      placeholder="រដ្ឋបាលខេត្តបន្ទាយមានជ័យ"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600">ថ្នាក់ទី២ (ការិយាល័យអប់រំ)</label>
                    <input
                      type="text"
                      value={administrationLine2}
                      onChange={(e) => setAdministrationLine2(e.target.value)}
                      placeholder="ការិយាល័យអប់រំ យុវជន និងកីឡា ស្រុកភ្នំស្រុក"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600">ថ្នាក់ទី៣ (កម្រង/ផ្នែក)</label>
                    <input
                      type="text"
                      value={administrationLine3}
                      onChange={(e) => setAdministrationLine3(e.target.value)}
                      placeholder="កម្រងស្ថានីយសាលារៀនគំរូ"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600">ថ្នាក់ទី៤ (អង្គភាពសាលា)</label>
                    <input
                      type="text"
                      value={administrationLine4}
                      onChange={(e) => setAdministrationLine4(e.target.value)}
                      placeholder="សាលាបឋមសិក្សា រោគ"
                      className="w-full px-2.5 py-1.5 text-xs font-semibold text-indigo-900 border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Title & Document Number */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    {lang === 'km' ? 'ចំណងជើងឯកសារពេញលេញ' : 'Document Title'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={titleKh}
                    onChange={(e) => setTitleKh(e.target.value)}
                    placeholder="ឧ. របាយការណ៍លទ្ធផលនៃការចុះស្រង់ស្ថិតិកុមារចូលរៀនថ្នាក់ទី១..."
                    className="w-full px-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    {lang === 'km' ? 'លេខលិខិតផ្លូវការ' : 'Doc No'}
                  </label>
                  <input
                    type="text"
                    value={documentNumber}
                    onChange={(e) => setDocumentNumber(e.target.value)}
                    placeholder="លេខ ០១/២៦ របក.សរ"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Summary */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  {lang === 'km' ? 'សេចក្តីសង្ខេបខ្លឹមសារខ្លី (សម្រាប់តារាងមាតិកាក្រូណូ)' : 'Summary'}
                </label>
                <input
                  type="text"
                  value={summaryKh}
                  onChange={(e) => setSummaryKh(e.target.value)}
                  placeholder="សង្ខេបខ្លឹមសារសំខាន់ៗនៃឯកសារភស្តុតាង..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Lunar and Solar Dates (National Standard Footer format) */}
              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                    <span>កាលបរិច្ឆេទចន្ទគតិ និងសុរិយគតិ (Footer Matrix)</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleRecalculateDate}
                    className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>គណនាកាលបរិច្ឆេទឡើងវិញ</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-[11px] text-slate-600 flex items-center gap-1 mb-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span>ទីតាំង (ឧ. រោគ, ភ្នំស្រុក)</span>
                    </label>
                    <input
                      type="text"
                      value={locationKh}
                      onChange={(e) => setLocationKh(e.target.value)}
                      placeholder="រោគ"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 mb-0.5 block">កាលបរិច្ឆេទចន្ទគតិ</label>
                    <input
                      type="text"
                      value={lunarDateKh}
                      onChange={(e) => setLunarDateKh(e.target.value)}
                      placeholder="ថ្ងៃ...កើត ខែ... ឆ្នាំ..."
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 mb-0.5 block">កាលបរិច្ឆេទសុរិយគតិ (តម្រឹមឆ្វេង)</label>
                    <input
                      type="text"
                      value={solarDateKh}
                      onChange={(e) => setSolarDateKh(e.target.value)}
                      placeholder="រោគ ថ្ងៃទី២៥ ខែមេសា ឆ្នាំ២០២៦"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white font-semibold text-slate-800"
                    />
                  </div>
                </div>

                {/* Signers: 3 Columns (Left: គ.គ.ស., Center: នាយកសាលា, Right: អ្នករៀបចំ) */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200/80 text-xs">
                  {/* Left: គ.គ.ស. */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                      <UserCheck className="w-3 h-3 text-indigo-600" />
                      <span>ផ្នែកឆ្វេង៖ គ.គ.ស (បានពិនិត្យ និងយល់ព្រម)</span>
                    </label>
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={secondApproverRole}
                        onChange={(e) => setSecondApproverRole(e.target.value)}
                        placeholder="ប្រធានគណៈកម្មការ គ.គ.ស"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                      <input
                        type="text"
                        value={secondApproverName}
                        onChange={(e) => setSecondApproverName(e.target.value)}
                        placeholder="ឈ្មោះប្រធាន គ.គ.ស (បើមាន)"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>

                  {/* Center: នាយកសាលា */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                      <UserCheck className="w-3 h-3 text-indigo-600" />
                      <span>ផ្នែកកណ្ដាល៖ នាយកសាលា (បានឃើញ និងឯកភាព)</span>
                    </label>
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={approverRole}
                        onChange={(e) => setApproverRole(e.target.value)}
                        placeholder="នាយកសាលារៀន"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                      <input
                        type="text"
                        value={approverName}
                        onChange={(e) => setApproverName(e.target.value)}
                        placeholder="ឈ្មោះនាយកសាលា (បើមាន)"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                    </div>
                  </div>

                  {/* Right: អ្នករៀបចំ */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                      <UserCheck className="w-3 h-3 text-indigo-600" />
                      <span>ផ្នែកស្ដាំ៖ អ្នករៀបចំ (រៀបចំដោយ)</span>
                    </label>
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={reporterRole}
                        onChange={(e) => setReporterRole(e.target.value)}
                        placeholder="អ្នកទទួលបន្ទុកស្តង់ដា"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      />
                      <input
                        type="text"
                        value={reporterName}
                        onChange={(e) => setReporterName(e.target.value)}
                        placeholder="ឈ្មោះអ្នករៀបចំ (ឧទាហរណ៍៖ Tong Un)"
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white font-semibold"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Markdown Content Editor */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <span>{lang === 'km' ? 'ខ្លឹមសារឯកសារពេញលេញ' : 'Full Document Content'}</span>
                  </label>
                  <span className="text-[11px] text-slate-500">
                    {lang === 'km' ? 'គាំទ្រទម្រង់តារាង ចំណុចទី១, ទី២ និងលេខខ្មែរ' : 'Supports tables and lists'}
                  </span>
                </div>
                <textarea
                  rows={12}
                  value={contentMarkdown}
                  onChange={(e) => setContentMarkdown(e.target.value)}
                  placeholder="I. សេចក្តីផ្តើម...&#10;II. គោលបំណង...&#10;III. លទ្ធផលសម្រេចបាន..."
                  className="w-full p-4 text-xs font-sans border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 leading-relaxed bg-slate-50/50"
                />
              </div>

              {/* Status and Filing metadata */}
              <div className="flex items-center justify-between p-3 bg-slate-100 rounded-xl">
                <div className="flex items-center gap-3">
                  <label className="text-xs font-bold text-slate-700">
                    {lang === 'km' ? 'ស្ថានភាពឯកសារ៖' : 'Status:'}
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 bg-white cursor-pointer"
                  >
                    <option value="draft">ឯកសារព្រាង (Draft)</option>
                    <option value="ready_for_signature">រង់ចាំចុះហត្ថលេខា (Ready for Sign)</option>
                    <option value="signed_and_filed">បានចុះហត្ថលេខា & តម្កល់ក្នុងក្រូណូ (Signed & Filed)</option>
                    <option value="verified">បានផ្ទៀងផ្ទាត់រួច (Verified)</option>
                  </select>
                </div>

                <div className="text-xs text-slate-500">
                  {lang === 'km' ? 'ឆ្នាំសិក្សា៖ ' : 'Academic Year: '}
                  <span className="font-bold text-slate-800">{toKhmerNum(academicYear || '២០២៥-២០២៦')}</span>
                </div>
              </div>

            </div>
          ) : (
            /* Printable Preview Mode using Official National Standard Components */
            <div className="p-8 sm:p-12 bg-white border border-slate-200 rounded-2xl shadow-inner max-w-3xl mx-auto space-y-6 text-slate-900">
              {/* National Standard Header */}
              <NationalDocumentHeader
                administrationLine1={administrationLine1}
                administrationLine2={administrationLine2}
                administrationLine3={administrationLine3}
                administrationLine4={administrationLine4}
                documentNumber={documentNumber}
                schoolName={userProfile?.schoolName}
                province={userProfile?.province}
                district={userProfile?.district}
                documentTitle={titleKh || 'ចំណងជើងឯកសារ'}
                subTitle={summaryKh}
                standardNumber={standardNumber}
                indicatorCode={selectedIndicator?.code}
              />

              {/* Document Body */}
              <div className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-sans text-slate-800 py-2">
                {cleanMarkdownBody(contentMarkdown) || 'មិនទាន់មានខ្លឹមសារនៅឡើយទេ។ សូមចុច "ទម្រង់កែសម្រួល" ឬ "✨ បង្កើតឯកសារគំរូពេញលេញដោយ AI"។'}
              </div>

              {/* National Standard Footer */}
              <NationalDocumentFooter
                lunarDateKh={lunarDateKh}
                solarDateKh={solarDateKh}
                locationKh={locationKh}
                secondApproverRole={secondApproverRole}
                secondApproverName={secondApproverName}
                approverRole={approverRole}
                approverName={approverName}
                reporterRole={reporterRole}
                reporterName={reporterName}
              />
            </div>
          )}

        </form>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>{lang === 'km' ? 'ឯកសារនឹងរក្សាទុកក្នុងក្រូណូ និងផ្ទៀងផ្ទាត់ជាមួយស្តង់ដា' : 'Chrono document real-time sync'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              {lang === 'km' ? 'បោះបង់' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{lang === 'km' ? 'រក្សាទុកក្នុងក្រូណូ' : 'Save to Chrono'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

