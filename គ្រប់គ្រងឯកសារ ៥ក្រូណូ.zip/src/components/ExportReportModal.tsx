import React, { useState, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Upload, 
  FileSpreadsheet, 
  FileCode, 
  CheckCircle, 
  School,
  Award,
  Calendar,
  UserCheck
} from 'lucide-react';
import { useEvaluation } from '../context/EvaluationContext';
import { useAuth } from '../context/AuthContext';
import { ALL_INDICATORS, STANDARDS_METADATA } from '../data/standardsData';
import { IndicatorScore } from '../types';
import { NationalDocumentHeader } from './NationalDocumentHeader';
import { NationalDocumentFooter } from './NationalDocumentFooter';
import { toKhmerNum, getKhmerLunarSolarDate } from '../utils/khmerDateUtils';

interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'km' | 'en';
}

export const ExportReportModal: React.FC<ExportReportModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const { 
    evaluationRecord, 
    academicYear, 
    evaluationTerm, 
    standardsSummaries, 
    overallPercentage, 
    overallAverage,
    totalCompletedActivities,
    totalActivitiesCount,
    performanceLevel,
    bulkUpdateScores
  } = useEvaluation();
  const { userProfile } = useAuth();

  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const dates = getKhmerLunarSolarDate(new Date(), userProfile?.district || userProfile?.province || 'រោគ');

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(evaluationRecord, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `School_Evaluation_${evaluationRecord?.schoolName || 'School'}_${academicYear}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleDownloadCSV = () => {
    let csv = "\uFEFF"; // UTF-8 BOM for Khmer fonts in Excel
    csv += "ល.រ,ស្តង់ដា,សូចនាករ (លទ្ធផលរំពឹងទុក),ពិន្ទុ (១-៥),ភាគរយ,ស្ថានភាព,កំណត់ចំណាំ\n";

    ALL_INDICATORS.forEach((ind) => {
      const scoreObj = evaluationRecord?.scores[ind.id];
      const scoreVal = scoreObj?.score || 0;
      const pct = scoreObj?.percentage || 0;
      const status = scoreObj?.status || 'not_started';
      const notes = (scoreObj?.notes || '').replace(/"/g, '""');

      csv += `"${toKhmerNum(ind.code)}","${ind.standardTitleKh}","${ind.expectedResultKh.replace(/"/g, '""')}",${toKhmerNum(scoreVal)},${toKhmerNum(pct)}%,"${status}","${notes}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `School_Evaluation_Scores_${academicYear}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.scores) {
          await bulkUpdateScores(json.scores);
          setImportStatus('ទិន្នន័យត្រូវបាននាំចូលដោយជោគជ័យ (Data imported successfully)');
        } else {
          setImportStatus('ឯកសារ JSON មិនត្រឹមត្រូវ (Invalid format)');
        }
      } catch (err) {
        setImportStatus('បរាជ័យក្នុងការអានឯកសារ');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div 
      onClick={onClose}
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4"
    >
      <div 
        onClick={e => e.stopPropagation()}
        className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh] animate-in fade-in zoom-in-95 duration-150"
      >
        
        {/* Modal Controls Header (Hidden in Print) */}
        <div className="no-print p-3 sm:p-4 bg-slate-900 text-white shrink-0 border-b border-slate-800">
          <div className="flex items-center justify-between gap-2 mb-2 sm:mb-0">
            <div className="flex items-center gap-2 min-w-0">
              <Printer className="w-5 h-5 text-indigo-400 shrink-0" />
              <h3 className="text-xs sm:text-sm font-bold truncate">
                {lang === 'km' ? 'របាយការណ៍វាយតម្លៃស្តង់ដាសាលារៀន' : 'Official Evaluation Report & Export'}
              </h3>
            </div>

            {/* Prominent Mobile & Desktop Close Button */}
            <button
              onClick={onClose}
              className="px-2.5 py-1.5 rounded-lg bg-rose-600/90 hover:bg-rose-600 text-white text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer shadow-xs transition-colors"
              title="បិទ (Close)"
            >
              <X className="w-4 h-4" />
              <span>{lang === 'km' ? 'បិទ' : 'Close'}</span>
            </button>
          </div>

          {/* Action Buttons Row */}
          <div className="flex flex-wrap items-center justify-end gap-2 pt-2 sm:pt-0 sm:mt-2 border-t border-slate-800 sm:border-0">
            <button
              onClick={handleDownloadCSV}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer border border-slate-700"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>CSV</span>
            </button>

            <button
              onClick={handleDownloadJSON}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer border border-slate-700"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>JSON</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'បោះពុម្ព (Print/PDF)' : 'Print Report'}</span>
            </button>
          </div>
        </div>

        {/* Printable Report Document */}
        <div className="p-6 sm:p-10 overflow-y-auto space-y-6 flex-1 bg-white text-slate-900">
          
          {/* Official National Standard Header Layout */}
          <NationalDocumentHeader
            administrationLine1={userProfile?.province ? `រដ្ឋបាលខេត្ត ${userProfile.province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា'}
            administrationLine2={userProfile?.district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${userProfile.district}` : 'មន្ទីរអប់រំ យុវជន និងកីឡា'}
            administrationLine3="កម្រងស្ថានីយសាលារៀនគំរូ"
            administrationLine4={userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ'}
            documentTitle="របាយការណ៍លទ្ធផលវាយតម្លៃស្តង់ដាសាលារៀនគំរូ"
            subTitle={`(តាមស្តង់ដាទាំង ៥ និង ៧១ សកម្មភាពគន្លឹះ ឆ្នាំសិក្សា ${toKhmerNum(academicYear || '២០២៥-២០២៦')})`}
          />

          {/* School & Evaluation Metadata */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 font-medium block">ឈ្មោះសាលារៀន៖</span>
              <span className="font-bold text-slate-900">{userProfile?.schoolName || 'សាលាបឋមសិក្សា ហ៊ុន សែន'}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">កូដសាលា / ទីតាំង៖</span>
              <span className="font-bold text-slate-900">{userProfile?.schoolCode || 'KH-120045'} ({userProfile?.province || 'ភ្នំពេញ'})</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">ឆ្នាំសិក្សា៖</span>
              <span className="font-bold text-slate-900">{toKhmerNum(academicYear)} ({evaluationTerm === 'annual' ? 'ប្រចាំឆ្នាំ' : 'ឆមាស'})</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block">កាលបរិច្ឆេទវាយតម្លៃ៖</span>
              <span className="font-bold text-slate-900">{dates.solarDateKh}</span>
            </div>
          </div>

          {/* Executive Performance Summary */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="text-xs text-indigo-300 font-semibold uppercase tracking-wider block">
                លទ្ធផលវាយតម្លៃសរុប (Overall Performance)
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-black text-white">{toKhmerNum(overallPercentage)}%</span>
                <span className="text-xs text-slate-300">({toKhmerNum(overallAverage)} / ៥.០ ពិន្ទុ)</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-300 block">កម្រិតវាយតម្លៃទទួលស្គាល់</span>
              <span className="text-lg font-bold text-amber-300">
                {performanceLevel.levelKh}
              </span>
            </div>
          </div>

          {/* Standards Summary Table */}
          <div>
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              ១. តារាងសង្ខេបពិន្ទុតាមស្តង់ដាទាំង ៥ (Summary by Standards)
            </h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 font-bold text-slate-700">
                    <th className="py-2.5 px-3 w-12 text-center">ល.រ</th>
                    <th className="py-2.5 px-4">ឈ្មោះស្តង់ដា</th>
                    <th className="py-2.5 px-3 text-center">ចំនួនសូចនាករ</th>
                    <th className="py-2.5 px-3 text-center">ចំនួនសកម្មភាព</th>
                    <th className="py-2.5 px-3 text-center">មធ្យមភាគពិន្ទុ (១-៥)</th>
                    <th className="py-2.5 px-3 text-center">ភាគរយ (%)</th>
                    <th className="py-2.5 px-3 text-center">ចំណាត់ថ្នាក់</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {standardsSummaries.map((s) => (
                    <tr key={s.standardNumber} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-center font-bold">{toKhmerNum(s.standardNumber)}</td>
                      <td className="py-2.5 px-4 font-semibold text-slate-900">{s.titleKh}</td>
                      <td className="py-2.5 px-3 text-center">{toKhmerNum(s.totalIndicators)}</td>
                      <td className="py-2.5 px-3 text-center">{toKhmerNum(s.totalActivities)}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-indigo-700">{toKhmerNum(s.averageScore)}</td>
                      <td className="py-2.5 px-3 text-center font-black">{toKhmerNum(s.percentageScore)}%</td>
                      <td className="py-2.5 px-3 text-center font-medium text-slate-700">{s.statusLabelKh}</td>
                    </tr>
                  ))}
                  <tr className="bg-slate-50 font-bold border-t-2 border-slate-300">
                    <td colSpan={2} className="py-2.5 px-4 text-slate-900">សរុបរួម (Grand Total)</td>
                    <td className="py-2.5 px-3 text-center">{toKhmerNum(ALL_INDICATORS.length)}</td>
                    <td className="py-2.5 px-3 text-center">{toKhmerNum(totalActivitiesCount)}</td>
                    <td className="py-2.5 px-3 text-center text-indigo-700">{toKhmerNum(overallAverage)}</td>
                    <td className="py-2.5 px-3 text-center text-indigo-900">{toKhmerNum(overallPercentage)}%</td>
                    <td className="py-2.5 px-3 text-center text-amber-800">{performanceLevel.levelKh}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Indicators Detailed Checklist */}
          <div>
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              ២. បញ្ជីសូចនាករ និងលទ្ធផលវាយតម្លៃលម្អិត
            </h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-left text-[11px] border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 font-bold text-slate-700">
                    <th className="py-2 px-2.5 w-12 text-center">ល.រ</th>
                    <th className="py-2 px-3">លទ្ធផលរំពឹងទុក</th>
                    <th className="py-2 px-2 w-20 text-center">ពិន្ទុ</th>
                    <th className="py-2 px-2 w-24 text-center">ស្ថានភាព</th>
                    <th className="py-2 px-3">កំណត់ចំណាំ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {ALL_INDICATORS.map((ind) => {
                    const scoreObj = evaluationRecord?.scores[ind.id];
                    const scoreVal = scoreObj?.score || 1;
                    return (
                      <tr key={ind.id} className="hover:bg-slate-50">
                        <td className="py-1.5 px-2.5 text-center font-bold text-slate-700">{toKhmerNum(ind.code)}</td>
                        <td className="py-1.5 px-3 font-medium text-slate-900">{ind.expectedResultKh}</td>
                        <td className="py-1.5 px-2 text-center font-bold text-indigo-700">{toKhmerNum(scoreVal)} / ៥</td>
                        <td className="py-1.5 px-2 text-center text-slate-600">
                          {scoreObj?.status === 'achieved' || scoreObj?.status === 'exceeded' ? 'សម្រេចបាន' :
                           scoreObj?.status === 'in_progress' ? 'កំពុងអនុវត្ត' : 'មិនទាន់អនុវត្ត'}
                        </td>
                        <td className="py-1.5 px-3 text-slate-500 italic truncate max-w-[200px]">
                          {scoreObj?.notes || '-'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Official Signatures Section using National Standard Layout */}
          <NationalDocumentFooter
            lunarDateKh={dates.lunarDateKh}
            solarDateKh={dates.solarDateKh}
            locationKh={userProfile?.district || userProfile?.province || 'រោគ'}
            approverRole="គណៈកម្មការគ្រប់គ្រងសាលា (គ.គ.ស)"
            approverName=""
            reporterRole="នាយកសាលារៀន"
            reporterName={userProfile?.displayName || 'នាយកសាលា'}
          />

          {/* Import JSON Section (Hidden in print) */}
          <div className="no-print pt-6 border-t border-slate-200">
            <div className="p-4 rounded-xl bg-slate-50 border border-dashed border-slate-300 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-indigo-600" />
                  <span>{lang === 'km' ? 'នាំចូលទិន្នន័យពីឯកសារ JSON (Import Evaluation)' : 'Import JSON Backup'}</span>
                </h5>
                <p className="text-[11px] text-slate-500">
                  {lang === 'km' ? 'ជ្រើសរើសឯកសារ JSON ដែលបានទាញយកពីមុនដើម្បីស្តារទិន្នន័យ' : 'Upload existing evaluation JSON file to restore scores.'}
                </p>
                {importStatus && (
                  <p className="text-xs font-semibold text-emerald-600 mt-1">{importStatus}</p>
                )}
              </div>

              <label className="px-4 py-2 rounded-xl bg-white border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer transition-colors shadow-2xs">
                <span>{lang === 'km' ? 'ជ្រើសរើសឯកសារ...' : 'Choose File...'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportJSON}
                  className="hidden"
                />
              </label>
            </div>
          </div>

        </div>

        {/* Modal Bottom Controls Bar (Hidden in Print) */}
        <div className="no-print p-3 sm:p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all active:scale-95 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{lang === 'km' ? 'បោះពុម្ពរបាយការណ៍ (Print / PDF)' : 'Print Report (PDF)'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer"
          >
            <X className="w-4 h-4 text-rose-400" />
            <span>{lang === 'km' ? 'បិទផ្ទាំង (Close)' : 'Close'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
