import React, { useState } from 'react';
import { 
  Shield, 
  GraduationCap, 
  RefreshCw, 
  User as UserIcon, 
  LogOut, 
  LogIn, 
  FileText, 
  Printer, 
  Sparkles, 
  Settings, 
  CheckCircle2, 
  Database,
  Search,
  School,
  ExternalLink,
  ChevronDown,
  FolderOpen,
  LayoutDashboard,
  Table,
  CalendarDays,
  ClipboardCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useEvaluation } from '../context/EvaluationContext';

export type AppViewMode = 'evaluation' | 'national_form' | 'chrono' | 'planner' | 'dashboard';

interface NavbarProps {
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenExport: () => void;
  lang: 'km' | 'en';
  setLang: (lang: 'km' | 'en') => void;
  activeView: AppViewMode;
  setActiveView: (view: AppViewMode) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAuth,
  onOpenProfile,
  onOpenExport,
  lang,
  setLang,
  activeView,
  setActiveView
}) => {
  const { currentUser, userProfile, logout } = useAuth();
  const { 
    academicYear, 
    setAcademicYear, 
    evaluationTerm, 
    setEvaluationTerm, 
    syncStatus, 
    autoSaveStatus,
    lastSavedAt,
    overallPercentage,
    performanceLevel,
    populateSampleData
  } = useEvaluation();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [isPopulating, setIsPopulating] = useState(false);

  const handlePopulate = async () => {
    if (window.confirm('តើអ្នកពិតជាចង់បញ្ចូលទិន្នន័យគំរូសាកល្បងសម្រាប់សាលារៀនគំរូដែរឬទេ? (Load realistic sample evaluation data?)')) {
      setIsPopulating(true);
      await populateSampleData();
      setIsPopulating(false);
    }
  };

  const getRoleLabelKh = (role?: string) => {
    switch(role) {
      case 'director': return 'នាយកសាលា';
      case 'deputy_director': return 'នាយករង';
      case 'evaluator': return 'អ្នកវាយតម្លៃ';
      case 'teacher': return 'គ្រូបង្រៀន';
      case 'committee': return 'គ.គ.ស';
      case 'admin': return 'អ្នកគ្រប់គ្រង';
      default: return 'មន្ត្រីអប់រំ';
    }
  };

  return (
    <header className="no-print sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & School Name */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 shrink-0">
              <School className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-base sm:text-lg tracking-tight truncate">
                  {lang === 'km' ? 'ប្រព័ន្ធគ្រប់គ្រងស្តង់ដាសាលារៀន' : 'School Standards & Score Store'}
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Firebase Cloud
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate">
                {userProfile?.schoolName || (lang === 'km' ? 'សាលាបឋមសិក្សាគំរូ' : 'Model Primary School')}
              </p>
            </div>
          </div>

          {/* Center Navigation View Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/90 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveView('evaluation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeView === 'evaluation'
                  ? 'bg-white text-indigo-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'តារាងវាយតម្លៃ ៥ ស្តង់ដា' : 'Evaluation Table'}</span>
            </button>

            <button
              onClick={() => setActiveView('national_form')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeView === 'national_form'
                  ? 'bg-indigo-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <ClipboardCheck className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? '📋 ទម្រង់ស្វ័យវាយតម្លៃថ្នាក់ជាតិ' : 'National Assessment Form'}</span>
            </button>

            <button
              onClick={() => setActiveView('chrono')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeView === 'chrono'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? '📁 ក្រូណូភស្តុតាងទាំង ៥' : '5 Chrono Binders'}</span>
            </button>

            <button
              onClick={() => setActiveView('planner')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeView === 'planner'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? '📅 ប្រតិទិន & ផែនការ' : 'Calendar & Plans'}</span>
            </button>

            <button
              onClick={() => setActiveView('dashboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeView === 'dashboard'
                  ? 'bg-white text-indigo-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'ផ្ទាំងគ្រប់គ្រង & ស្ថិតិ' : 'Dashboard'}</span>
            </button>
          </nav>

          {/* Center Academic Controls */}
          <div className="hidden xl:flex items-center gap-2 bg-slate-100/80 p-1 rounded-xl border border-slate-200">
            <div className="flex items-center px-2 text-xs font-semibold text-slate-600">
              {lang === 'km' ? 'ឆ្នាំសិក្សា' : 'Year'}:
            </div>
            <select
              value={academicYear}
              onChange={(e) => setAcademicYear(e.target.value)}
              className="bg-white text-xs font-medium text-slate-800 rounded-lg px-2.5 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            >
              <option value="2024-2025">2024-2025</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2023-2024">2023-2024</option>
            </select>

            <select
              value={evaluationTerm}
              onChange={(e) => setEvaluationTerm(e.target.value as any)}
              className="bg-white text-xs font-medium text-slate-800 rounded-lg px-2.5 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            >
              <option value="annual">{lang === 'km' ? 'ប្រចាំឆ្នាំ (Annual)' : 'Annual'}</option>
              <option value="semester_1">{lang === 'km' ? 'ឆមាសទី ១' : 'Semester 1'}</option>
              <option value="semester_2">{lang === 'km' ? 'ឆមាសទី ២' : 'Semester 2'}</option>
            </select>
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            
            {/* Auto-Save & Sync Status Badge */}
            <div 
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-100/90 border border-slate-200 text-slate-700 shadow-2xs" 
              title={lastSavedAt ? `រក្សាទុកចុងក្រោយ៖ ${new Date(lastSavedAt).toLocaleTimeString('km-KH')}` : 'Auto-save active'}
            >
              {syncStatus === 'saving' || autoSaveStatus === 'saving' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-amber-500 animate-spin" />
                  <span className="text-amber-700 font-semibold">{lang === 'km' ? 'កំពុងរក្សាទុក...' : 'Auto-saving...'}</span>
                </>
              ) : syncStatus === 'synced' ? (
                <>
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-emerald-800 font-semibold">{lang === 'km' ? 'រក្សាទុកស្វ័យប្រវត្ត' : 'Auto-saved'}</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                  <span className="text-slate-600">{lang === 'km' ? 'រក្សាទុក Local' : 'Local Auto-saved'}</span>
                </>
              )}
            </div>

            {/* Populate Sample Data Button */}
            <button
              onClick={handlePopulate}
              disabled={isPopulating}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 transition-colors shadow-2xs"
              title="បញ្ចូលទិន្នន័យគំរូ ៧១ សកម្មភាព (Load sample data)"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'km' ? 'ទិន្នន័យគំរូ' : 'Sample Data'}</span>
            </button>

            {/* Print/Export Button */}
            <button
              onClick={onOpenExport}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 text-white hover:bg-slate-800 transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'km' ? 'បោះពុម្ពរបាយការណ៍' : 'Report'}</span>
            </button>

            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === 'km' ? 'en' : 'km')}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors"
              title="ប្តូរភាសា / Switch Language"
            >
              {lang === 'km' ? 'EN' : 'ខ្មែរ'}
            </button>

            {/* User Profile / Auth Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 border border-slate-200 transition-colors text-left"
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
                    {userProfile?.displayName ? userProfile.displayName.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
                  </div>
                  <div className="hidden xl:block text-left pr-1">
                    <p className="text-xs font-semibold text-slate-800 leading-tight truncate max-w-[120px]">
                      {userProfile?.displayName || 'អ្នកប្រើប្រាស់'}
                    </p>
                    <p className="text-[10px] text-indigo-600 font-medium">
                      {getRoleLabelKh(userProfile?.role)}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 rounded-xl bg-white shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-3 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900 truncate">
                        {userProfile?.displayName || currentUser.email}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">
                        {currentUser.email || 'Guest user'}
                      </p>
                      <div className="mt-1.5 inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700">
                        {getRoleLabelKh(userProfile?.role)} • {userProfile?.schoolName || 'សាលារៀន'}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onOpenProfile();
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-slate-500" />
                      <span>{lang === 'km' ? 'ព័ត៌មានគណនី & សាលារៀន' : 'Profile & School Data'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onOpenExport();
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 transition-colors"
                    >
                      <FileText className="w-4 h-4 text-slate-500" />
                      <span>{lang === 'km' ? 'ទាញយកទិន្នន័យ (Export JSON/CSV)' : 'Export Data'}</span>
                    </button>

                    <div className="my-1 border-t border-slate-100"></div>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        logout();
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 transition-colors font-medium"
                    >
                      <LogOut className="w-4 h-4 text-rose-500" />
                      <span>{lang === 'km' ? 'ចាកចេញពីគណនី' : 'Sign Out'}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'ចូលគណនី Firebase' : 'Sign In'}</span>
              </button>
            )}

          </div>

        </div>

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden items-center justify-between overflow-x-auto py-2 border-t border-slate-100 text-xs gap-1">
          <button
            onClick={() => setActiveView('evaluation')}
            className={`px-2 py-1.5 rounded-lg font-bold flex items-center gap-1 shrink-0 ${
              activeView === 'evaluation' ? 'bg-indigo-100 text-indigo-900' : 'text-slate-600'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>តារាង ៥ស្តង់ដា</span>
          </button>

          <button
            onClick={() => setActiveView('national_form')}
            className={`px-2 py-1.5 rounded-lg font-bold flex items-center gap-1 shrink-0 ${
              activeView === 'national_form' ? 'bg-indigo-700 text-white' : 'text-slate-600'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5" />
            <span>ទម្រង់ជាតិ</span>
          </button>

          <button
            onClick={() => setActiveView('chrono')}
            className={`px-2 py-1.5 rounded-lg font-bold flex items-center gap-1 shrink-0 ${
              activeView === 'chrono' ? 'bg-indigo-600 text-white' : 'text-slate-600'
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span>ក្រូណូទាំង ៥</span>
          </button>

          <button
            onClick={() => setActiveView('planner')}
            className={`px-2 py-1.5 rounded-lg font-bold flex items-center gap-1 shrink-0 ${
              activeView === 'planner' ? 'bg-amber-600 text-white' : 'text-slate-600'
            }`}
          >
            <CalendarDays className="w-3.5 h-3.5" />
            <span>ប្រតិទិន</span>
          </button>

          <button
            onClick={() => setActiveView('dashboard')}
            className={`px-2 py-1.5 rounded-lg font-bold flex items-center gap-1 shrink-0 ${
              activeView === 'dashboard' ? 'bg-indigo-100 text-indigo-900' : 'text-slate-600'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>ផ្ទាំងគ្រប់គ្រង</span>
          </button>
        </div>

      </div>
    </header>
  );
};
