import React, { useState, useRef } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Upload, 
  CheckCircle2, 
  FileText, 
  Edit3, 
  Trash2, 
  Image as ImageIcon, 
  Building, 
  ShieldCheck, 
  Sparkles,
  ExternalLink,
  Clock,
  User,
  Paperclip
} from 'lucide-react';
import { ChronoDocument } from '../types/chrono';
import { useChrono } from '../context/ChronoContext';
import { useAuth } from '../context/AuthContext';
import { useEvaluation } from '../context/EvaluationContext';
import { STANDARDS_METADATA } from '../data/standardsData';
import { NationalDocumentHeader } from './NationalDocumentHeader';
import { NationalDocumentFooter } from './NationalDocumentFooter';
import { toKhmerNum, cleanMarkdownBody } from '../utils/khmerDateUtils';

interface DocumentViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: ChronoDocument | null;
  onEdit: (doc: ChronoDocument) => void;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({
  isOpen,
  onClose,
  document,
  onEdit
}) => {
  const { uploadSignedCopy, deleteDocument, updateDocument } = useChrono();
  const { userProfile } = useAuth();
  const { lang } = useEvaluation();

  const [activeTab, setActiveTab] = useState<'view' | 'signed_copy' | 'raw_file'>('view');
  const [isUploadingSigned, setIsUploadingSigned] = useState(false);
  const [signedName, setSignedName] = useState('');
  const [signedRole, setSignedRole] = useState('នាយកសាលា');
  const [showSignUploadBox, setShowSignUploadBox] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen || !document) return null;

  const standardMeta = STANDARDS_METADATA.find(s => s.number === document.standardNumber);

  // Print Handler
  const handlePrint = () => {
    window.print();
  };

  // Download Markdown/Text
  const handleDownloadText = () => {
    const element = document.createElement("a");
    const file = new Blob([document.contentMarkdown], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `${document.titleKh || 'chrono_document'}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Handle Upload of Signed Paper Scan / Photo
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      await uploadSignedCopy(document.id, {
        fileBase64: base64Data,
        fileName: file.name,
        signedByName: signedName || userProfile?.displayName || 'នាយកសាលា',
        signedRole
      });
      setIsUploadingSigned(false);
      setShowSignUploadBox(false);
      setActiveTab('signed_copy');
    };
    reader.readAsDataURL(file);
  };

  const handleDelete = async () => {
    if (window.confirm(lang === 'km' ? 'តើអ្នកប្រាកដជាចង់លុបឯកសារនេះចេញពីក្រូណូមែនទេ?' : 'Are you sure you want to delete this document from Chrono?')) {
      await deleteDocument(document.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/10 text-white">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs px-2 py-0.5 rounded-md bg-indigo-600 font-bold">
                  ក្រូណូទី {document.standardNumber}
                </span>
                <span className="text-xs text-slate-300 font-medium">
                  សូចនាករ {document.indicatorCode}
                </span>
                {document.aiGenerated && (
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-300 border border-purple-400/30 flex items-center gap-1 font-semibold">
                    <Sparkles className="w-3 h-3" />
                    <span>AI Template</span>
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm sm:text-base text-white mt-0.5 line-clamp-1">
                {document.titleKh}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="បោះពុម្ពឯកសារ"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'km' ? 'បោះពុម្ព' : 'Print'}</span>
            </button>

            <button
              onClick={handleDownloadText}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors"
              title="ទាញយកឯកសារ"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'km' ? 'ទាញយក' : 'Download'}</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onEdit(document);
              }}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              title="កែប្រែឯកសារ"
            >
              <Edit3 className="w-4 h-4" />
            </button>

            <button
              onClick={handleDelete}
              className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-white/10 transition-colors"
              title="លុបឯកសារ"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub-header Navigation Tabs & Status */}
        <div className="px-6 py-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveTab('view')}
              className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'view' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'ខ្លឹមសារផ្លូវការ' : 'Official Document'}</span>
            </button>

            <button
              onClick={() => setActiveTab('signed_copy')}
              className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'signed_copy' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'ឯកសារចុះហត្ថលេខារួច' : 'Signed Copy'}</span>
              {document.signedFileBase64 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              )}
            </button>

            {document.fileBase64 && (
              <button
                onClick={() => setActiveTab('raw_file')}
                className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
                  activeTab === 'raw_file' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Paperclip className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'ឯកសារភ្ជាប់ (Attachment)' : 'Attachment'}</span>
              </button>
            )}
          </div>

          {/* Status badge */}
          <div className="flex items-center gap-2">
            {document.status === 'signed_and_filed' ? (
              <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{lang === 'km' ? 'បានចុះហត្ថលេខា & ដាក់ក្នុងក្រូណូ' : 'Signed & Filed in Chrono'}</span>
              </span>
            ) : document.status === 'verified' ? (
              <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-800 border border-blue-300 font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                <span>{lang === 'km' ? 'បានផ្ទៀងផ្ទាត់ដោយអធិការ' : 'Verified by Inspector'}</span>
              </span>
            ) : (
              <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-800 border border-amber-300 font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>{lang === 'km' ? 'រង់ចាំចុះហត្ថលេខា' : 'Pending Signature'}</span>
              </span>
            )}
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          
          {activeTab === 'view' && (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 sm:p-12 shadow-sm max-w-3xl mx-auto space-y-6 text-slate-900 print:shadow-none print:border-none print:p-0">
              
              {/* Official MoEYS National Header */}
              <NationalDocumentHeader
                administrationLine1={document.administrationLine1 || (userProfile?.province ? `រដ្ឋបាលខេត្ត ${userProfile.province}` : 'ក្រសួងអប់រំ យុវជន និងកីឡា')}
                administrationLine2={document.administrationLine2 || (userProfile?.district ? `ការិយាល័យអប់រំ យុវជន និងកីឡា ${userProfile.district}` : 'ការិយាល័យអប់រំ យុវជន និងកីឡា')}
                administrationLine3={document.administrationLine3 || 'កម្រងស្ថានីយសាលារៀនគំរូ'}
                administrationLine4={document.administrationLine4 || userProfile?.schoolName || 'សាលាបឋមសិក្សាគំរូ'}
                documentNumber={document.documentNumber}
                schoolName={userProfile?.schoolName}
                province={userProfile?.province}
                district={userProfile?.district}
                documentTitle={document.titleKh}
                subTitle={document.summaryKh}
                standardNumber={document.standardNumber}
                indicatorCode={document.indicatorCode}
              />

              {/* Document Text Body */}
              <div className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap text-slate-800 font-sans py-2">
                {cleanMarkdownBody(document.contentMarkdown)}
              </div>

              {/* Official National Standard Footer (3 Columns: គ.គ.ស., នាយកសាលា, អ្នករៀបចំ) */}
              <NationalDocumentFooter
                lunarDateKh={document.lunarDateKh}
                solarDateKh={document.solarDateKh || document.dateKh}
                locationKh={document.locationKh || userProfile?.district || userProfile?.province || 'រោគ'}
                dateRaw={document.createdAt}
                secondApproverRole={document.secondApproverRole || 'ប្រធានគណៈកម្មការ គ.គ.ស'}
                secondApproverName={document.secondApproverName || ''}
                approverRole={document.approverRole || 'នាយកសាលារៀន'}
                approverName={document.approverName || userProfile?.displayName || ''}
                reporterRole={document.reporterRole || 'អ្នកទទួលបន្ទុកស្តង់ដា'}
                reporterName={document.reporterName || document.authorName || userProfile?.displayName || 'Tong Un'}
              />

            </div>
          )}

          {activeTab === 'signed_copy' && (
            <div className="max-w-2xl mx-auto space-y-4">
              {document.signedFileBase64 ? (
                <div className="bg-white p-6 rounded-2xl border border-emerald-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>{lang === 'km' ? 'ឯកសារស្កេនដែលបានចុះហត្ថលេខា និងបោះត្រារួច' : 'Physical Signed & Stamped Copy'}</span>
                    </div>
                    <span className="text-xs text-slate-500">
                      {document.signedAt ? new Date(document.signedAt).toLocaleDateString('km-KH') : ''}
                    </span>
                  </div>

                  <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center min-h-[300px]">
                    {document.signedFileBase64.startsWith('data:image/') ? (
                      <img 
                        src={document.signedFileBase64} 
                        alt="Signed document scan" 
                        className="max-h-[600px] w-auto object-contain"
                      />
                    ) : (
                      <div className="p-8 text-center space-y-3">
                        <FileText className="w-12 h-12 text-slate-400 mx-auto" />
                        <p className="text-xs font-semibold text-slate-700">{document.signedFileName || 'ឯកសារភ្ជាប់'}</p>
                        <a 
                          href={document.signedFileBase64} 
                          download={document.signedFileName || 'signed_copy.pdf'} 
                          className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold"
                        >
                          <Download className="w-4 h-4" />
                          <span>ទាញយកឯកសារស្កេន</span>
                        </a>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-600 pt-2">
                    <div>
                      {lang === 'km' ? 'ចុះហត្ថលេខាដោយ៖ ' : 'Signed by: '}
                      <span className="font-bold text-slate-900">{document.signedByName}</span> ({document.signedRole})
                    </div>
                    <button
                      onClick={() => setShowSignUploadBox(true)}
                      className="text-indigo-600 hover:text-indigo-800 font-bold"
                    >
                      {lang === 'km' ? 'ប្តូររូបភាពស្កេនថ្មី' : 'Replace Scan'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-white p-8 rounded-2xl border-2 border-dashed border-slate-300 text-center space-y-4">
                  <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">
                      {lang === 'km' ? 'មិនទាន់មានឯកសារចុះហត្ថលេខារួចភ្ជាប់មកជាមួយនៅឡើយទេ' : 'No signed copy uploaded yet'}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                      {lang === 'km' ? 'សូមបោះពុម្ពឯកសារនេះ រួចយកទៅជូននាយកសាលា និងគណៈកម្មការ គ.គ.ស ចុះហត្ថលេខានិងបោះត្រា។ បន្ទាប់មក ថតរូប ឬ Scan ជា PDF រួច Upload ចូលមកវិញ។' : 'Print this document, have it signed & stamped, then scan and re-upload here to verify.'}
                    </p>
                  </div>

                  <button
                    onClick={() => setShowSignUploadBox(true)}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-2 mx-auto transition-all"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{lang === 'km' ? 'Upload ឯកសារចុះហត្ថលេខារួច (Scan / Photo)' : 'Upload Signed Copy'}</span>
                  </button>
                </div>
              )}

              {/* Upload Signed Box Modal / Popover */}
              {showSignUploadBox && (
                <div className="p-5 bg-white border border-indigo-200 rounded-2xl shadow-lg space-y-4 animate-in fade-in">
                  <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                    <Upload className="w-4 h-4 text-indigo-600" />
                    <span>{lang === 'km' ? 'ជ្រើសរើសរូបថត ឬ File PDF ដែលបានចុះហត្ថលេខារួច' : 'Select Scanned File'}</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-700 font-bold mb-1">
                        {lang === 'km' ? 'ឈ្មោះអ្នកចុះហត្ថលេខា' : 'Signer Name'}
                      </label>
                      <input
                        type="text"
                        value={signedName}
                        onChange={(e) => setSignedName(e.target.value)}
                        placeholder={userProfile?.displayName || 'នាយកសាលា'}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 font-bold mb-1">
                        {lang === 'km' ? 'តួនាទី' : 'Signer Role'}
                      </label>
                      <select
                        value={signedRole}
                        onChange={(e) => setSignedRole(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
                      >
                        <option value="នាយកសាលា">នាយកសាលា (Principal)</option>
                        <option value="ប្រធានគណៈកម្មការ គ.គ.ស">ប្រធានគណៈកម្មការ គ.គ.ស</option>
                        <option value="នាយករង">នាយករង</option>
                        <option value="ប្រធានស្តង់ដា">ប្រធានស្តង់ដា</option>
                      </select>
                    </div>
                  </div>

                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*,application/pdf"
                    className="hidden"
                  />

                  <div className="flex gap-2 justify-end pt-2">
                    <button
                      type="button"
                      onClick={() => setShowSignUploadBox(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg"
                    >
                      {lang === 'km' ? 'បោះបង់' : 'Cancel'}
                    </button>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-4 py-1.5 bg-indigo-600 text-white font-bold text-xs rounded-lg flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{lang === 'km' ? 'ជ្រើសរើស File (JPG, PNG, PDF)' : 'Choose File'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'raw_file' && document.fileBase64 && (
            <div className="max-w-2xl mx-auto bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4 text-center">
              {document.fileBase64.startsWith('data:image/') ? (
                <img 
                  src={document.fileBase64} 
                  alt={document.titleKh} 
                  className="max-h-[550px] w-auto mx-auto object-contain rounded-lg border border-slate-200"
                />
              ) : (
                <div className="p-8 space-y-4">
                  <FileText className="w-16 h-16 text-indigo-500 mx-auto" />
                  <h4 className="font-bold text-sm text-slate-800">{document.fileName || 'ឯកសារភ្ជាប់'}</h4>
                  <a
                    href={document.fileBase64}
                    download={document.fileName || 'document_attachment'}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>ទាញយកឯកសារភ្ជាប់</span>
                  </a>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500">
            {lang === 'km' ? 'បង្កើតនៅ៖ ' : 'Created at: '}
            <span className="font-medium">{new Date(document.createdAt).toLocaleString('km-KH')}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl transition-colors"
          >
            {lang === 'km' ? 'បិទ' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
