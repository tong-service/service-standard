import React, { useState, useMemo } from 'react';
import { 
  Folder, 
  FolderOpen, 
  FileText, 
  Plus, 
  Sparkles, 
  Upload, 
  Clipboard, 
  Printer, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Image as ImageIcon, 
  FileSpreadsheet, 
  Download, 
  Edit3, 
  Trash2, 
  Eye, 
  ChevronRight, 
  Layers, 
  BookOpen, 
  GraduationCap, 
  Users, 
  Building2, 
  Calendar,
  Tag,
  Paperclip,
  Check,
  AlertCircle
} from 'lucide-react';
import { useChrono } from '../context/ChronoContext';
import { useAuth } from '../context/AuthContext';
import { useEvaluation } from '../context/EvaluationContext';
import { STANDARDS_METADATA, ALL_INDICATORS } from '../data/standardsData';
import { ChronoDocument, ChronoDocumentType } from '../types/chrono';
import { DocumentEditorModal } from './DocumentEditorModal';
import { DocumentViewerModal } from './DocumentViewerModal';
import { ImportFileModal } from './ImportFileModal';
import { PasteCodeModal } from './PasteCodeModal';
import { ChronoPrintIndexModal } from './ChronoPrintIndexModal';

export const ChronoManagerView: React.FC = () => {
  const { 
    documents, 
    activeStandard, 
    setActiveStandard,
    activeIndicatorId,
    setActiveIndicatorId,
    filterDocType,
    setFilterDocType,
    filterStatus,
    setFilterStatus,
    searchQuery,
    setSearchQuery,
    folderStats,
    deleteDocument,
    uploadSignedCopy
  } = useChrono();

  const { userProfile } = useAuth();
  const { academicYear, lang } = useEvaluation();

  // Modals state
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingDoc, setEditingDoc] = useState<ChronoDocument | null>(null);

  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewingDoc, setViewingDoc] = useState<ChronoDocument | null>(null);

  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isPasteOpen, setIsPasteOpen] = useState(false);
  const [isPrintIndexOpen, setIsPrintIndexOpen] = useState(false);

  // Selected Standard (defaults to 1 if null)
  const currentStandardNumber = activeStandard || 1;
  const currentStandardMeta = STANDARDS_METADATA.find(s => s.number === currentStandardNumber);

  // Indicators belonging to current standard
  const currentStandardIndicators = useMemo(() => {
    return ALL_INDICATORS.filter(ind => ind.standardNumber === currentStandardNumber);
  }, [currentStandardNumber]);

  // Filtered documents
  const filteredDocuments = useMemo(() => {
    return documents.filter(doc => {
      // Standard filter
      if (activeStandard !== null && doc.standardNumber !== activeStandard) {
        return false;
      }
      // Indicator filter
      if (activeIndicatorId && doc.indicatorId !== activeIndicatorId) {
        return false;
      }
      // Doc Type filter
      if (filterDocType !== 'all' && doc.documentType !== filterDocType) {
        return false;
      }
      // Status filter
      if (filterStatus !== 'all' && doc.status !== filterStatus) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchTitle = doc.titleKh?.toLowerCase().includes(q);
        const matchSummary = doc.summaryKh?.toLowerCase().includes(q);
        const matchCode = doc.indicatorCode?.toLowerCase().includes(q);
        const matchDocNo = doc.documentNumber?.toLowerCase().includes(q);
        return matchTitle || matchSummary || matchCode || matchDocNo;
      }
      return true;
    });
  }, [documents, activeStandard, activeIndicatorId, filterDocType, filterStatus, searchQuery]);

  // Standard icon mapper
  const getStandardIcon = (num: number) => {
    switch (num) {
      case 1: return <GraduationCap className="w-5 h-5" />;
      case 2: return <BookOpen className="w-5 h-5" />;
      case 3: return <Users className="w-5 h-5" />;
      case 4: return <Building2 className="w-5 h-5" />;
      case 5: return <ShieldCheck className="w-5 h-5" />;
      default: return <Folder className="w-5 h-5" />;
    }
  };

  // Document Type Label mapper
  const getDocTypeBadge = (type: ChronoDocumentType) => {
    switch (type) {
      case 'activity_report':
        return <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-semibold">របាយការណ៍សកម្មភាព</span>;
      case 'verification_report':
        return <span className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200 text-[11px] font-semibold">របាយការណ៍ផ្ទៀងផ្ទាត់</span>;
      case 'meeting_minutes':
        return <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-semibold">កំណត់ហេតុប្រជុំ</span>;
      case 'moeys_decision':
        return <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold">សេចក្តីសម្រេច/លិខិត</span>;
      case 'student_list':
        return <span className="px-2 py-0.5 rounded-md bg-teal-50 text-teal-700 border border-teal-200 text-[11px] font-semibold">ស្ថិតិ/លទ្ធផលសិស្ស</span>;
      case 'observation_sheet':
        return <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-semibold">កិច្ចតែងការ/សង្កេត</span>;
      case 'evidence_photo':
        return <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200 text-[11px] font-semibold">រូបភាពភស្តុតាង</span>;
      default:
        return <span className="px-2 py-0.5 rounded-md bg-slate-50 text-slate-700 border border-slate-200 text-[11px] font-semibold">ឯកសារភស្តុតាង</span>;
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* 5 Master Chrono Binders Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <FolderOpen className="w-3.5 h-3.5" />
              <span>រចនាសម្ព័ន្ធក្រូណូទាំង ៥ ស្តង់ដា (5 MoEYS Standard Binders)</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              ប្រព័ន្ធគ្រប់គ្រងក្រូណូ និងឯកសារភស្តុតាងសាលារៀនគំរូ
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              បង្កើត រៀបចំ និងរក្សាទុកឯកសារភស្តុតាងសកម្មភាព របាយការណ៍ផ្ទៀងផ្ទាត់ និងលទ្ធផលសម្រេចតាមក្រូណូនីមួយៗ។ គាំទ្រការ Import ឯកសារ (PDF, Photos, Word, Excel), Paste Text / Code, ជំនួយការ AI និងការទាញយកមកចុះហត្ថលេខា។
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap gap-2 sm:gap-2.5 shrink-0">
            <button
              onClick={() => {
                setEditingDoc(null);
                setIsEditorOpen(true);
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>{lang === 'km' ? 'បង្កើតឯកសារថ្មី' : 'New Document'}</span>
            </button>

            <button
              onClick={() => {
                setEditingDoc(null);
                setIsEditorOpen(true);
              }}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-4 h-4" />
              <span>{lang === 'km' ? '✨ បង្កើតដោយ AI' : 'AI Template'}</span>
            </button>

            <button
              onClick={() => setIsImportOpen(true)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
            >
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>Import File</span>
            </button>

            <button
              onClick={() => setIsPasteOpen(true)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
            >
              <Clipboard className="w-4 h-4 text-amber-400" />
              <span>Paste Code / Text</span>
            </button>
          </div>
        </div>

        {/* 5 Chrono Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-6 mt-6 border-t border-white/10">
          {STANDARDS_METADATA.map(s => {
            const stats = folderStats[s.number] || { totalDocuments: 0, signedDocuments: 0, draftDocuments: 0, verifiedDocuments: 0 };
            const isSelected = activeStandard === s.number;

            return (
              <button
                key={s.number}
                onClick={() => {
                  if (activeStandard === s.number) {
                    setActiveStandard(null);
                    setActiveIndicatorId(null);
                  } else {
                    setActiveStandard(s.number);
                    setActiveIndicatorId(null);
                  }
                }}
                className={`p-4 rounded-2xl text-left transition-all duration-200 border relative overflow-hidden ${
                  isSelected 
                    ? 'bg-white text-slate-900 border-white shadow-xl scale-[1.02] ring-4 ring-indigo-500/40' 
                    : 'bg-white/5 hover:bg-white/10 text-white border-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className={`p-2 rounded-xl ${
                    isSelected ? 'bg-indigo-600 text-white' : 'bg-white/10 text-indigo-300'
                  }`}>
                    {getStandardIcon(s.number)}
                  </div>
                  <span className={`text-[11px] font-extrabold px-2 py-0.5 rounded-md ${
                    isSelected ? 'bg-indigo-100 text-indigo-900' : 'bg-white/10 text-slate-300'
                  }`}>
                    ក្រូណូទី {s.number}
                  </span>
                </div>

                <h4 className={`text-xs font-bold line-clamp-1 ${isSelected ? 'text-slate-900' : 'text-white'}`}>
                  {s.shortKh}
                </h4>
                <p className={`text-[11px] mt-0.5 line-clamp-1 ${isSelected ? 'text-slate-500' : 'text-slate-400'}`}>
                  {s.titleKh.split('៖ ')[1] || s.titleKh}
                </p>

                {/* Doc Stats Counter */}
                <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-200/20 text-[11px]">
                  <span className={isSelected ? 'text-slate-600 font-semibold' : 'text-slate-300'}>
                    {stats.totalDocuments} ឯកសារ
                  </span>
                  {stats.signedDocuments > 0 && (
                    <span className="flex items-center gap-1 font-bold text-emerald-600">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{stats.signedDocuments} ចុះហត្ថលេខា</span>
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace Layout (Sidebar Explorer + Document Grid) */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Left Sidebar: Chrono Folder Tree Explorer */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-xs text-slate-900 flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-indigo-600" />
              <span>{lang === 'km' ? 'រចនាសម្ព័ន្ធសូចនាករ' : 'Indicator Folders'}</span>
            </h3>
            {activeStandard && (
              <button
                onClick={() => {
                  setActiveStandard(null);
                  setActiveIndicatorId(null);
                }}
                className="text-[11px] text-indigo-600 hover:text-indigo-800 font-bold"
              >
                {lang === 'km' ? 'បង្ហាញទាំងអស់' : 'View All'}
              </button>
            )}
          </div>

          {/* Quick All-docs filter */}
          <button
            onClick={() => setActiveIndicatorId(null)}
            className={`w-full p-2.5 rounded-xl text-left text-xs font-bold flex items-center justify-between transition-colors ${
              activeIndicatorId === null 
                ? 'bg-indigo-50 text-indigo-900 border border-indigo-200' 
                : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>{activeStandard ? `ឯកសារទាំងអស់ក្នុងក្រូណូទី ${activeStandard}` : 'ឯកសារទាំងអស់ (All Documents)'}</span>
            </div>
            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px]">
              {activeStandard ? folderStats[activeStandard]?.totalDocuments || 0 : documents.length}
            </span>
          </button>

          {/* Indicator Tree Items */}
          <div className="space-y-1 overflow-y-auto max-h-[500px] pr-1">
            {currentStandardIndicators.map(ind => {
              const indDocsCount = documents.filter(d => d.indicatorId === ind.id).length;
              const isIndSelected = activeIndicatorId === ind.id;

              return (
                <button
                  key={ind.id}
                  onClick={() => {
                    setActiveStandard(ind.standardNumber);
                    setActiveIndicatorId(isIndSelected ? null : ind.id);
                  }}
                  className={`w-full p-2.5 rounded-xl text-left text-xs transition-all flex items-start justify-between gap-2 border ${
                    isIndSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 font-bold shadow-xs'
                      : 'hover:bg-slate-50 text-slate-700 border-transparent'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 font-bold">
                      <span className={`text-[11px] px-1.5 py-0.2 rounded-sm ${isIndSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-800'}`}>
                        {ind.code}
                      </span>
                      <span className="line-clamp-1">{ind.sectionTitleKh.split('. ')[1] || ind.sectionTitleKh}</span>
                    </div>
                    <p className={`text-[11px] line-clamp-1 ${isIndSelected ? 'text-indigo-100' : 'text-slate-500'}`}>
                      {ind.expectedResultKh}
                    </p>
                  </div>

                  <span className={`text-[11px] px-2 py-0.5 rounded-full shrink-0 font-bold ${
                    isIndSelected 
                      ? 'bg-white text-indigo-900' 
                      : indDocsCount > 0 
                        ? 'bg-indigo-100 text-indigo-800' 
                        : 'bg-slate-100 text-slate-400'
                  }`}>
                    {indDocsCount}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Chrono Cover & Index Print Action */}
          <div className="pt-3 border-t border-slate-100">
            <button
              onClick={() => setIsPrintIndexOpen(true)}
              className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-400" />
              <span>{lang === 'km' ? `បោះពុម្ពក្រប & មាតិកាក្រូណូទី ${currentStandardNumber}` : `Print Chrono ${currentStandardNumber} Index`}</span>
            </button>
          </div>
        </div>

        {/* Right Section: Document Hub & Cards Grid */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* Toolbar: Filters & Search */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={lang === 'km' ? 'ស្វែងរកឯកសារតាមចំណងជើង សូចនាករ ឬលេខលិខិត...' : 'Search documents...'}
                className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
              />
            </div>

            {/* Filter Dropdowns */}
            <div className="flex items-center gap-2">
              <select
                value={filterDocType}
                onChange={(e) => setFilterDocType(e.target.value)}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-700"
              >
                <option value="all">គ្រប់ប្រភេទឯកសារ (All Types)</option>
                <option value="activity_report">របាយការណ៍សកម្មភាព</option>
                <option value="verification_report">របាយការណ៍ផ្ទៀងផ្ទាត់</option>
                <option value="meeting_minutes">កំណត់ហេតុប្រជុំ</option>
                <option value="moeys_decision">សេចក្តីសម្រេច/លិខិត</option>
                <option value="student_list">បញ្ជីសិស្ស / ពិន្ទុ</option>
                <option value="observation_sheet">កិច្ចតែងការ / សង្កេត</option>
                <option value="evidence_photo">រូបភាពភស្តុតាង</option>
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 bg-white text-slate-700"
              >
                <option value="all">គ្រប់ស្ថានភាព (All Status)</option>
                <option value="signed_and_filed">បានចុះហត្ថលេខា & ដាក់ក្នុងក្រូណូ</option>
                <option value="ready_for_signature">រង់ចាំចុះហត្ថលេខា</option>
                <option value="verified">បានផ្ទៀងផ្ទាត់</option>
                <option value="draft">ឯកសារព្រាង</option>
              </select>
            </div>

          </div>

          {/* Documents Grid / List */}
          {filteredDocuments.length === 0 ? (
            <div className="bg-white p-12 rounded-2xl border-2 border-dashed border-slate-200 text-center space-y-4">
              <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-800">
                  {lang === 'km' ? 'មិនទាន់មានឯកសារនៅក្នុងផ្នែកនេះនៅឡើយទេ' : 'No documents found in this section'}
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {lang === 'km' ? 'លោកអ្នកអាចបង្កើតឯកសារថ្មី ប្រើ AI បង្កើតគំរូផ្លូវការ Import File (PDF, Photos, Word, Excel) ឬបិទភ្ជាប់អត្ថបទចូលក្នុងក្រូណូ។' : 'Create new documents, use AI generator, or import existing evidence files.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  onClick={() => {
                    setEditingDoc(null);
                    setIsEditorOpen(true);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>បង្កើតឯកសារថ្មី</span>
                </button>

                <button
                  onClick={() => setIsImportOpen(true)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5"
                >
                  <Upload className="w-4 h-4" />
                  <span>Import File</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredDocuments.map(doc => {
                const stdMeta = STANDARDS_METADATA.find(s => s.number === doc.standardNumber);

                return (
                  <div
                    key={doc.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group space-y-4"
                  >
                    
                    {/* Top Row: Chrono tag, Indicator, Type badge */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-900">
                            ក្រូណូទី {doc.standardNumber}
                          </span>
                          <span className="text-[11px] font-semibold text-slate-600">
                            សូចនាករ {doc.indicatorCode}
                          </span>
                          {doc.aiGenerated && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center gap-1">
                              <Sparkles className="w-2.5 h-2.5" />
                              <span>AI</span>
                            </span>
                          )}
                        </div>

                        {/* Status Icon */}
                        {doc.status === 'signed_and_filed' ? (
                          <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>ចុះហត្ថលេខារួច</span>
                          </span>
                        ) : doc.status === 'verified' ? (
                          <span className="text-[11px] font-bold text-blue-700 flex items-center gap-1 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                            <span>ផ្ទៀងផ្ទាត់រួច</span>
                          </span>
                        ) : (
                          <span className="text-[11px] font-bold text-amber-700 flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>រង់ចាំចុះហត្ថលេខា</span>
                          </span>
                        )}
                      </div>

                      {/* Title */}
                      <h4 
                        onClick={() => {
                          setViewingDoc(doc);
                          setIsViewerOpen(true);
                        }}
                        className="font-bold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-2 cursor-pointer"
                      >
                        {doc.titleKh}
                      </h4>

                      {/* Summary */}
                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {doc.summaryKh || doc.contentMarkdown?.substring(0, 100) + '...'}
                      </p>
                    </div>

                    {/* Metadata & Actions */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {getDocTypeBadge(doc.documentType)}
                        {doc.fileType === 'pdf' && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-red-100 text-red-700">PDF</span>
                        )}
                        {doc.fileType === 'image' && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-blue-100 text-blue-700">IMG</span>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setViewingDoc(doc);
                            setIsViewerOpen(true);
                          }}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition-colors"
                          title="មើល / បោះពុម្ព"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            setEditingDoc(doc);
                            setIsEditorOpen(true);
                          }}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition-colors"
                          title="កែប្រែ"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            if (window.confirm('តើអ្នកប្រាកដជាចង់លុបឯកសារនេះចេញពីក្រូណូមែនទេ?')) {
                              deleteDocument(doc.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                          title="លុប"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>

      </div>

      {/* Modals */}
      <DocumentEditorModal
        isOpen={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        initialDocument={editingDoc}
        defaultStandard={activeStandard || 1}
        defaultIndicatorId={activeIndicatorId || undefined}
      />

      <DocumentViewerModal
        isOpen={isViewerOpen}
        onClose={() => setIsViewerOpen(false)}
        document={viewingDoc}
        onEdit={(doc) => {
          setEditingDoc(doc);
          setIsEditorOpen(true);
        }}
      />

      <ImportFileModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        defaultStandard={activeStandard || 1}
        defaultIndicatorId={activeIndicatorId || undefined}
      />

      <PasteCodeModal
        isOpen={isPasteOpen}
        onClose={() => setIsPasteOpen(false)}
        defaultStandard={activeStandard || 1}
        defaultIndicatorId={activeIndicatorId || undefined}
      />

      <ChronoPrintIndexModal
        isOpen={isPrintIndexOpen}
        onClose={() => setIsPrintIndexOpen(false)}
        standardNumber={currentStandardNumber}
      />

    </div>
  );
};
