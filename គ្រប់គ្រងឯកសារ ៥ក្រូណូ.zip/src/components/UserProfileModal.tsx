import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  User, 
  School, 
  MapPin, 
  Phone, 
  Shield, 
  Save, 
  Mail, 
  KeyRound, 
  CheckCircle, 
  AlertCircle,
  Database,
  Building,
  FileCheck,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile, UserRole } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'km' | 'en';
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const { currentUser, userProfile, updateUserProfileData, resetPassword } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [schoolCode, setSchoolCode] = useState('');
  const [province, setProvince] = useState('');
  const [district, setDistrict] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [role, setRole] = useState<UserRole>('director');
  const [bio, setBio] = useState('');
  
  const [autoSaveState, setAutoSaveState] = useState<'saved' | 'saving' | 'error'>('saved');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSendingReset, setIsSendingReset] = useState(false);

  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isInitializedRef = useRef<boolean>(false);

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setSchoolName(userProfile.schoolName || '');
      setSchoolCode(userProfile.schoolCode || '');
      setProvince(userProfile.province || '');
      setDistrict(userProfile.district || '');
      setPhoneNumber(userProfile.phoneNumber || '');
      setRole(userProfile.role || 'director');
      setBio(userProfile.bio || '');
    }
    isInitializedRef.current = true;
  }, [userProfile, isOpen]);

  if (!isOpen) return null;

  const triggerAutoSaveProfile = (updates: Partial<UserProfile>) => {
    setAutoSaveState('saving');
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(async () => {
      try {
        await updateUserProfileData({
          displayName,
          schoolName,
          schoolCode,
          province,
          district,
          phoneNumber,
          role,
          bio,
          ...updates
        });
        setAutoSaveState('saved');
      } catch (err: any) {
        console.error(err);
        setAutoSaveState('error');
      }
    }, 600);
  };

  const handleManualSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    setAutoSaveState('saving');
    setSuccessMsg(null);
    setErrorMsg(null);

    try {
      await updateUserProfileData({
        displayName,
        schoolName,
        schoolCode,
        province,
        district,
        phoneNumber,
        role,
        bio
      });
      setAutoSaveState('saved');
      setSuccessMsg(lang === 'km' ? 'ព័ត៌មានគណនី និងសាលារៀនត្រូវបានរក្សាទុកដោយជោគជ័យក្នុង Firestore' : 'Profile updated successfully in Firestore.');
    } catch (err: any) {
      setErrorMsg(err.message || 'បរាជ័យក្នុងការរក្សាទុក');
      setAutoSaveState('error');
    }
  };

  const handleSendResetPassword = async () => {
    if (!currentUser?.email) return;
    setIsSendingReset(true);
    try {
      await resetPassword(currentUser.email);
      setSuccessMsg(lang === 'km' ? 'តំណភ្ជាប់ប្តូរពាក្យសម្ងាត់ត្រូវបានផ្ញើទៅអ៊ីមែលរបស់អ្នកហើយ' : 'Password reset link sent.');
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setIsSendingReset(false);
    }
  };

  const handleClose = () => {
    handleManualSave();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/30 border border-indigo-400/40 flex items-center justify-center text-white">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold">
                {lang === 'km' ? 'ព័ត៌មានគណនី & ទិន្នន័យសាលារៀន' : 'User Profile & School Info'}
              </h3>
              <p className="text-xs text-slate-300">
                {lang === 'km' ? 'រក្សាទុកសុវត្ថិភាពក្នុង Firebase Cloud Database' : 'Securely synced with Firestore'}
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Auto-Save Status Banner */}
        <div className="px-6 py-2 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            {autoSaveState === 'saving' ? (
              <span className="inline-flex items-center gap-1.5 text-amber-700 font-medium">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-600" />
                <span>{lang === 'km' ? 'កំពុងរក្សាទុកស្វ័យប្រវត្តទៅ Cloud...' : 'Auto-saving profile...'}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{lang === 'km' ? 'បានរក្សាទុកស្វ័យប្រវត្ត (Auto-saved)' : 'Profile changes auto-saved'}</span>
              </span>
            )}
          </div>

          <span className="text-[11px] text-slate-500">
            {lang === 'km' ? 'រក្សាទុកស្វ័យប្រវត្តលើ Firestore' : 'Auto-saved to Firestore'}
          </span>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleManualSave} className="p-6 overflow-y-auto space-y-5 flex-1">
          
          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* User Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'km' ? 'ឈ្មោះពេញអ្នកប្រើប្រាស់' : 'Full Name'} *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => {
                    setDisplayName(e.target.value);
                    triggerAutoSaveProfile({ displayName: e.target.value });
                  }}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'km' ? 'តួនាទី / មុខតំណែង' : 'Role / Position'}
              </label>
              <div className="relative">
                <Shield className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <select
                  value={role}
                  onChange={(e) => {
                    const newRole = e.target.value as UserRole;
                    setRole(newRole);
                    triggerAutoSaveProfile({ role: newRole });
                  }}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
                >
                  <option value="director">នាយកសាលា (Principal)</option>
                  <option value="deputy_director">នាយករង (Deputy Principal)</option>
                  <option value="evaluator">អ្នកវាយតម្លៃ / អធិការអប់រំ (Evaluator / Inspector)</option>
                  <option value="teacher">គ្រូបង្រៀន (Teacher)</option>
                  <option value="committee">គណៈកម្មការ គ.គ.ស (SMC Committee)</option>
                  <option value="admin">អ្នកគ្រប់គ្រងទិន្នន័យ (Data Administrator)</option>
                </select>
              </div>
            </div>

          </div>

          {/* School Details */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <School className="w-4 h-4 text-indigo-600" />
              <span>{lang === 'km' ? 'ព័ត៌មានគ្រឹះស្ថានសិក្សា' : 'School Information'}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {lang === 'km' ? 'ឈ្មោះសាលារៀន' : 'School Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={schoolName}
                  onChange={(e) => {
                    setSchoolName(e.target.value);
                    triggerAutoSaveProfile({ schoolName: e.target.value });
                  }}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {lang === 'km' ? 'កូដសាលា (Code)' : 'School Code'}
                </label>
                <input
                  type="text"
                  value={schoolCode}
                  onChange={(e) => {
                    setSchoolCode(e.target.value);
                    triggerAutoSaveProfile({ schoolCode: e.target.value });
                  }}
                  placeholder="KH-120045"
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {lang === 'km' ? 'ខេត្ត / រាជធានី' : 'Province'}
                </label>
                <input
                  type="text"
                  value={province}
                  onChange={(e) => {
                    setProvince(e.target.value);
                    triggerAutoSaveProfile({ province: e.target.value });
                  }}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  {lang === 'km' ? 'ស្រុក / ខណ្ឌ' : 'District'}
                </label>
                <input
                  type="text"
                  value={district}
                  onChange={(e) => {
                    setDistrict(e.target.value);
                    triggerAutoSaveProfile({ district: e.target.value });
                  }}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                {lang === 'km' ? 'លេខទូរស័ព្ទទាក់ទង' : 'Phone Number'}
              </label>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => {
                  setPhoneNumber(e.target.value);
                  triggerAutoSaveProfile({ phoneNumber: e.target.value });
                }}
                placeholder="012 345 678"
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
              />
            </div>

          </div>

          {/* Bio / Vision */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {lang === 'km' ? 'ទស្សនវិស័យ ឬគោលបំណងអភិវឌ្ឍន៍សាលា' : 'School Vision & Goals'}
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => {
                setBio(e.target.value);
                triggerAutoSaveProfile({ bio: e.target.value });
              }}
              placeholder="ទស្សនវិស័យក្នុងការលើកកម្ពស់គុណភាពអប់រំ និងស្តង់ដាសាលារៀន..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Account Metadata & Security */}
          <div className="pt-3 border-t border-slate-200">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div>
                <p className="font-semibold text-slate-800">
                  {lang === 'km' ? 'អ៊ីមែលគណនី៖' : 'Account Email:'} <span className="font-mono text-slate-600">{currentUser?.email || 'Guest Mode'}</span>
                </p>
                <p className="text-[11px] text-slate-400 font-mono">
                  UID: {currentUser?.uid || 'guest'}
                </p>
              </div>

              {currentUser && !currentUser.isAnonymous && (
                <button
                  type="button"
                  disabled={isSendingReset}
                  onClick={handleSendResetPassword}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-medium text-xs flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                  <span>{isSendingReset ? 'កំពុងផ្ញើ...' : (lang === 'km' ? 'ប្តូរពាក្យសម្ងាត់' : 'Reset Password')}</span>
                </button>
              )}
            </div>
          </div>

        </form>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2.5 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>{lang === 'km' ? 'រក្សាទុកស្វ័យប្រវត្តសកម្ម' : 'Auto-save is active'}</span>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-600/20 transition-colors flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{lang === 'km' ? 'រួចរាល់ (Done)' : 'Done'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
