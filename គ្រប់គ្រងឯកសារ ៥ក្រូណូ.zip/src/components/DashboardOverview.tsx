import React from 'react';
import { 
  Award, 
  CheckCircle2, 
  TrendingUp, 
  BookOpen, 
  GraduationCap, 
  Users, 
  Building2, 
  ShieldCheck, 
  Star,
  Layers,
  ArrowRight,
  Flame
} from 'lucide-react';
import { useEvaluation } from '../context/EvaluationContext';
import { STANDARDS_METADATA } from '../data/standardsData';

interface DashboardOverviewProps {
  lang: 'km' | 'en';
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ lang }) => {
  const { 
    overallPercentage, 
    overallAverage, 
    standardsSummaries, 
    totalCompletedActivities, 
    totalActivitiesCount,
    performanceLevel,
    selectedStandard,
    setSelectedStandard 
  } = useEvaluation();

  const getStandardIcon = (num: number) => {
    switch (num) {
      case 1: return <GraduationCap className="w-5 h-5" />;
      case 2: return <BookOpen className="w-5 h-5" />;
      case 3: return <Users className="w-5 h-5" />;
      case 4: return <Building2 className="w-5 h-5" />;
      case 5: return <ShieldCheck className="w-5 h-5" />;
      default: return <Layers className="w-5 h-5" />;
    }
  };

  const getProgressColor = (pct: number) => {
    if (pct >= 90) return 'bg-emerald-500 text-emerald-700 border-emerald-200';
    if (pct >= 75) return 'bg-blue-500 text-blue-700 border-blue-200';
    if (pct >= 50) return 'bg-amber-500 text-amber-700 border-amber-200';
    return 'bg-rose-500 text-rose-700 border-rose-200';
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Performance Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left: Overall School Score Card */}
        <div className="lg:col-span-7 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-7 shadow-xl relative overflow-hidden border border-slate-800">
          
          {/* Subtle decorative glow */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 flex flex-col justify-between h-full space-y-6">
            
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-semibold mb-2">
                  <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span>{lang === 'km' ? 'ពិន្ទុវាយតម្លៃសរុប (Fire Score)' : 'Total Performance Score'}</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                  {lang === 'km' ? 'វឌ្ឍនភាពស្តង់ដាសាលារៀនគំរូ' : 'School Standards Performance'}
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-md">
                  {lang === 'km' 
                    ? 'ផ្អែកលើការអនុវត្តជាក់ស្តែងនៃសូចនាករ និង ៧១ សកម្មភាពគន្លឹះទូទាំង ៥ ស្តង់ដា'
                    : 'Evaluated across key indicators and 71 action plans across 5 Core Standards.'}
                </p>
              </div>

              {/* Performance Level Badge */}
              <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/20 text-center shrink-0 shadow-lg">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-300 block">
                  {lang === 'km' ? 'កម្រិតសាលារៀន' : 'Evaluation Level'}
                </span>
                <span className="text-sm sm:text-base font-extrabold text-amber-300">
                  {lang === 'km' ? performanceLevel.levelKh : performanceLevel.levelEn}
                </span>
              </div>
            </div>

            {/* Metric Meters */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2 border-t border-white/10">
              
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <span className="text-xs text-slate-400 font-medium block">
                  {lang === 'km' ? 'ភាគរយសរុប' : 'Total Score'}
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black text-white">{overallPercentage}%</span>
                  <span className="text-xs text-slate-400">/ 100%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-indigo-400 to-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${overallPercentage}%` }}
                  ></div>
                </div>
              </div>

              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <span className="text-xs text-slate-400 font-medium block">
                  {lang === 'km' ? 'មធ្យមភាគពិន្ទុ' : 'Average Rating'}
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black text-amber-400">{overallAverage}</span>
                  <span className="text-xs text-slate-400">/ 5.0</span>
                </div>
                <div className="flex items-center gap-0.5 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star 
                      key={star} 
                      className={`w-3.5 h-3.5 ${
                        star <= Math.round(overallAverage) 
                          ? 'text-amber-400 fill-amber-400' 
                          : 'text-slate-600'
                      }`} 
                    />
                  ))}
                </div>
              </div>

              <div className="col-span-2 sm:col-span-1 bg-white/5 rounded-xl p-3 border border-white/10">
                <span className="text-xs text-slate-400 font-medium block">
                  {lang === 'km' ? 'សកម្មភាពសម្រេច' : 'Activities Done'}
                </span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-2xl sm:text-3xl font-black text-emerald-400">{totalCompletedActivities}</span>
                  <span className="text-xs text-slate-400">/ {totalActivitiesCount}</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div 
                    className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.round((totalCompletedActivities / totalActivitiesCount) * 100)}%` }}
                  ></div>
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Right: Quick Standards Matrix Overview */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                <span>{lang === 'km' ? 'សង្ខេបតាមស្តង់ដាទាំង៥' : 'Standards Overview'}</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                {lang === 'km' ? '៥ ស្តង់ដា' : '5 Standards'}
              </span>
            </div>

            <div className="space-y-2.5">
              {standardsSummaries.map((summary) => (
                <div 
                  key={summary.standardNumber}
                  onClick={() => setSelectedStandard(summary.standardNumber === selectedStandard ? null : summary.standardNumber)}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    selectedStandard === summary.standardNumber
                      ? 'bg-indigo-50 border-indigo-300 ring-2 ring-indigo-500/20'
                      : 'hover:bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                      summary.standardNumber === 1 ? 'bg-emerald-100 text-emerald-700' :
                      summary.standardNumber === 2 ? 'bg-blue-100 text-blue-700' :
                      summary.standardNumber === 3 ? 'bg-amber-100 text-amber-700' :
                      summary.standardNumber === 4 ? 'bg-purple-100 text-purple-700' :
                      'bg-rose-100 text-rose-700'
                    }`}>
                      <span className="font-bold text-xs">{summary.standardNumber}</span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {lang === 'km' ? summary.titleKh : summary.titleEn}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {summary.totalIndicators} {lang === 'km' ? 'សូចនាករ' : 'Indicators'} • {summary.totalActivities} {lang === 'km' ? 'សកម្មភាព' : 'Activities'}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-black text-slate-900">{summary.percentageScore}%</span>
                    <p className="text-[10px] font-medium text-slate-500">
                      {summary.averageScore} / 5
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              {lang === 'km' ? 'ចុចលើស្តង់ដាណាមួយដើម្បីចម្រាញ់' : 'Click a standard to filter table'}
            </span>
            {selectedStandard !== null && (
              <button
                onClick={() => setSelectedStandard(null)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                {lang === 'km' ? 'បង្ហាញទាំងអស់' : 'Show All'}
              </button>
            )}
          </div>
        </div>

      </div>

      {/* Standard Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setSelectedStandard(null)}
          className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all shadow-2xs ${
            selectedStandard === null
              ? 'bg-slate-900 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          {lang === 'km' ? 'គ្រប់ស្តង់ដា (ទាំងអស់ ៧១ សកម្មភាព)' : 'All Standards (71 Activities)'}
        </button>

        {STANDARDS_METADATA.map((std) => (
          <button
            key={std.number}
            onClick={() => setSelectedStandard(selectedStandard === std.number ? null : std.number)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 shadow-2xs ${
              selectedStandard === std.number
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            <span>{std.number}.</span>
            <span>{lang === 'km' ? std.shortKh : `Std ${std.number}`}</span>
          </button>
        ))}
      </div>

    </div>
  );
};
