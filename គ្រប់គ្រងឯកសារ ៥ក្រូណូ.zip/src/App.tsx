/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { EvaluationProvider, useEvaluation } from './context/EvaluationContext';
import { ChronoProvider } from './context/ChronoContext';
import { Navbar, AppViewMode } from './components/Navbar';
import { DashboardOverview } from './components/DashboardOverview';
import { StandardsTable } from './components/StandardsTable';
import { ChronoManagerView } from './components/ChronoManagerView';
import { SchoolEventPlannerView } from './components/SchoolEventPlannerView';
import { NationalAssessmentFormView } from './components/NationalAssessmentFormView';
import { IndicatorDetailModal } from './components/IndicatorDetailModal';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { ExportReportModal } from './components/ExportReportModal';
import { IndicatorDefinition } from './types';
import { 
  ShieldCheck, 
  Sparkles, 
  Database, 
  CheckCircle2, 
  Lock, 
  Cloud, 
  HelpCircle,
  BookOpen,
  FolderOpen,
  Table
} from 'lucide-react';

function MainAppContent() {
  const { currentUser, userProfile } = useAuth();
  const { syncStatus } = useEvaluation();

  const [lang, setLang] = useState<'km' | 'en'>('km');
  const [activeView, setActiveView] = useState<AppViewMode>('evaluation');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [selectedIndicator, setSelectedIndicator] = useState<IndicatorDefinition | null>(null);

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans text-slate-900 selection:bg-indigo-500 selection:text-white">
      
      {/* Top Navigation */}
      <Navbar
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        lang={lang}
        setLang={setLang}
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Firebase Security / Cloud Status Notification Banner */}
        {!currentUser && (
          <div className="bg-indigo-900 text-white rounded-2xl p-4 sm:p-5 shadow-lg flex flex-wrap items-center justify-between gap-4 border border-indigo-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/30 flex items-center justify-center shrink-0 border border-indigo-400/30">
                <Database className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  {lang === 'km' ? 'ប្រព័ន្ធបានភ្ជាប់ទៅកាន់ Firebase Authentication & Firestore' : 'Firebase Authentication & Firestore Ready'}
                </h4>
                <p className="text-xs text-indigo-200">
                  {lang === 'km' 
                    ? 'សូមចូលគណនី ឬចុះឈ្មោះដើម្បីគ្រប់គ្រងទម្រង់គណនីអ្នកប្រើប្រាស់ និងរក្សាទុកពិន្ទុ និងឯកសារក្រូណូដោយសុវត្ថិភាពលើ Cloud'
                    : 'Sign in or register to manage your profile, scores and Chrono evidence documents securely in Cloud.'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsAuthOpen(true)}
              className="px-4 py-2 rounded-xl bg-white text-indigo-900 font-bold text-xs hover:bg-indigo-50 transition-colors shadow-md shrink-0"
            >
              {lang === 'km' ? 'ចូលគណនី / ចុះឈ្មោះ' : 'Sign In / Register'}
            </button>
          </div>
        )}

        {/* View Switcher Routing */}
        {activeView === 'national_form' && (
          <NationalAssessmentFormView 
            lang={lang} 
            onClose={() => setActiveView('evaluation')} 
          />
        )}

        {activeView === 'chrono' && (
           <ChronoManagerView />
        )}

        {activeView === 'planner' && (
          <SchoolEventPlannerView lang={lang} />
        )}

        {activeView === 'dashboard' && (
          <div className="space-y-6">
            <DashboardOverview lang={lang} />
            <StandardsTable
              onSelectIndicator={(ind) => setSelectedIndicator(ind)}
              lang={lang}
            />
          </div>
        )}

        {activeView === 'evaluation' && (
          <div className="space-y-6">
            <DashboardOverview lang={lang} />
            <StandardsTable
              onSelectIndicator={(ind) => setSelectedIndicator(ind)}
              lang={lang}
            />
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="no-print border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
              Mo
            </div>
            <span className="font-semibold text-slate-700">
              {lang === 'km' ? 'ស្តង់ដាសាលារៀនគំរូទាំង ៥, ៧១ សកម្មភាព និងប្រព័ន្ធក្រូណូភស្តុតាង' : '5 Model School Standards, 71 Actions & Chrono Binder System'}
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Firebase Firestore Secured</span>
            <span>•</span>
            <span>Gemini AI Document Assistant</span>
            <span>•</span>
            <span>MoEYS Educational Standards</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        lang={lang}
      />

      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        lang={lang}
      />

      <ExportReportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        lang={lang}
      />

      <IndicatorDetailModal
        indicator={selectedIndicator}
        isOpen={selectedIndicator !== null}
        onClose={() => setSelectedIndicator(null)}
        lang={lang}
      />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <EvaluationProvider>
        <ChronoProvider>
          <MainAppContent />
        </ChronoProvider>
      </EvaluationProvider>
    </AuthProvider>
  );
}
