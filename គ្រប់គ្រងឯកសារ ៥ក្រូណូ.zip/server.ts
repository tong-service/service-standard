import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Enable large JSON bodies for document attachments and base64 images
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Helper to get GoogleGenAI client with required User-Agent
function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured in the environment.");
  }
  return new GoogleGenAI({ 
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// Resilient AI generation with retry and multi-model fallback (gemini-3.7-flash -> gemini-flash-latest -> gemini-3.1-flash-lite)
async function generateContentWithFallback(ai: GoogleGenAI, prompt: string): Promise<string | null> {
  const candidateModels = ["gemini-3.7-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  
  for (const model of candidateModels) {
    // Attempt up to 2 tries per model with brief delay on 503/429
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            responseMimeType: "application/json",
          },
        });
        if (response && response.text) {
          return response.text;
        }
      } catch (err: any) {
        console.warn(`[Gemini API] Model ${model} attempt ${attempt} failed:`, err?.message || err);
        const isTransient = err?.message?.includes("503") || 
                            err?.message?.includes("high demand") || 
                            err?.message?.includes("UNAVAILABLE") ||
                            err?.message?.includes("429") ||
                            err?.status === "UNAVAILABLE";
        if (isTransient && attempt === 1) {
          // Wait 600ms before retrying
          await new Promise(resolve => setTimeout(resolve, 600));
        } else if (!isTransient) {
          // Non-transient error, move to next model
          break;
        }
      }
    }
  }
  return null;
}

// Built-in High Quality MoEYS Document Generator Fallback (used when 503 spikes occur)
function generateRichMoEYSFallbackDocument(params: {
  standardNumber: number;
  standardTitleKh?: string;
  indicatorCode?: string;
  indicatorTitleKh?: string;
  activitiesKh?: string[] | string;
  documentType: string;
  schoolName?: string;
  province?: string;
  district?: string;
  academicYear?: string;
  customInstructions?: string;
}) {
  const {
    standardNumber = 1,
    standardTitleKh = "ស្តង់ដាសាលារៀនគំរូ",
    indicatorCode = "១.១",
    indicatorTitleKh = "សូចនាករលទ្ធផល",
    activitiesKh = [],
    documentType = "activity_report",
    schoolName = "សាលារៀនគំរូ",
    province = "រាជធានី-ខេត្ត",
    district = "ស្រុក-ខណ្ឌ",
    academicYear = "២០២៣-២០២៤",
    customInstructions = ""
  } = params;

  const activitiesList = Array.isArray(activitiesKh) ? activitiesKh : [activitiesKh];
  const docTypeLabels: Record<string, string> = {
    activity_report: "របាយការណ៍សកម្មភាពអនុវត្ត",
    verification_report: "របាយការណ៍ផ្ទៀងផ្ទាត់ និងវាយតម្លៃលទ្ធផល",
    action_plan: "ផែនការសកម្មភាពលម្អិត និងកាលវិភាគ",
    meeting_minutes: "កំណត់ហេតុប្រជុំគណៈកម្មការទ្រទ្រង់សាលា គ.គ.ស",
    moeys_decision: "សេចក្តីសម្រេចស្តីពីការចាត់តាំងការងារអនុវត្តស្តង់ដា",
    student_list: "បញ្ជីស្ថិតិ និងលទ្ធផលសិក្សាសិស្ស",
    observation_sheet: "តារាងសង្កេតការបង្រៀន និងកែលម្អការរៀនសូត្រ",
    evidence_summary: "របាយការណ៍សំយោគភស្តុតាងសម្រាប់ក្រូណូ"
  };

  const docTypeName = docTypeLabels[documentType] || "របាយការណ៍ភស្តុតាង";
  const docNumber = `លេខ ${Math.floor(Math.random() * 89 + 10)}/${academicYear.slice(-2)} របក.សរ`;
  const dateKh = new Date().toLocaleDateString("km-KH", { year: "numeric", month: "long", day: "numeric" });
  const titleKh = `${docTypeName} ស្តីពី "${indicatorTitleKh}"`;

  const activitiesMarkdown = activitiesList.length > 0 
    ? activitiesList.map((act, i) => `${i + 1}. **${act}** ៖ បានដំណើរការរៀបចំផែនការ ប្រជុំផ្សព្វផ្សាយ ចុះអនុវត្តជាក់ស្តែង និងតាមដានត្រួតពិនិត្យជាប្រចាំ។`).join("\n")
    : `1. **អនុវត្តសកម្មភាពស្របតាមសូចនាករ ${indicatorCode}** ៖ បានរៀបចំ និងដំណើរការតាមប្រតិទិនការងារ។`;

  const contentMarkdown = `### ព្រះរាជាណាចក្រកម្ពុជា
**ជាតិ សាសនា ព្រះមហាក្សត្រ**
***

**ក្រសួងអប់រំ យុវជន និងកីឡា**  
**មន្ទីរអប់រំ យុវជន និងកីឡា ${province}**  
**ការិយាល័យអប់រំ យុវជន និងកីឡា ${district}**  
**${schoolName}**  
**${docNumber}**

---
# ${titleKh}
### សម្រាប់តម្កល់ក្នុងក្រូណូទី ${standardNumber} (${standardTitleKh}) - សូចនាករ ${indicatorCode}
**ឆ្នាំសិក្សា ${academicYear}**

---

### I. សេចក្តីផ្តើម និងគោលបំណង
អនុវត្តតាមសេចក្តីណែនាំ និងក្របខណ្ឌស្តង់ដាសាលារៀនគំរូទាំង ៥ របស់ក្រសួងអប់រំ យុវជន និងកីឡា ${schoolName} បានរៀបចំចងក្រង និងអនុវត្តសកម្មភាពជាក់ស្តែងដើម្បីឆ្លើយតបទៅនឹងសូចនាករ ${indicatorCode}៖ **"${indicatorTitleKh}"** សំដៅលើកកម្ពស់គុណភាពអប់រំ និងធានាប្រសិទ្ធភាពនៃការគ្រប់គ្រងសាលារៀន។
${customInstructions ? `\n> **កំណត់សម្គាល់ជាក់ស្តែង៖** ${customInstructions}\n` : ""}

### II. ស្ថានភាពជាក់ស្តែង និងសកម្មភាពដែលបានអនុវត្ត
ក្នុងដំណើរការអនុវត្ត គណៈគ្រប់គ្រងសាលា លោកគ្រូ-អ្នកគ្រូ និងគណៈកម្មការ គ.គ.ស បានសហការអនុវត្តសកម្មភាពគន្លឹះដូចខាងក្រោម៖
${activitiesMarkdown}

### III. លទ្ធផលសម្រេចបាន (គិតជាបរិមាណ និងគុណភាព)
1. **លទ្ធផលបរិមាណ៖** សម្រេចបាននូវការអនុវត្តសកម្មភាពគ្រប់ជំហាន ១០០% ស្របតាមកាលវិភាគដែលបានកំណត់ក្នុងផែនការប្រតិបត្តិការប្រចាំឆ្នាំ (AOP)។
2. **លទ្ធផលគុណភាព៖** សិស្សានុសិស្សទទួលបានអត្ថប្រយោជន៍ពេញលេញ លោកគ្រូ-អ្នកគ្រូមានការយល់ដឹងកាន់តែច្បាស់ និងមានការចូលរួមគាំទ្រយ៉ាងសកម្មពីមាតាបិតាសិស្ស និងសហគមន៍។
3. **ការផ្ទៀងផ្ទាត់ភស្តុតាង៖** ឯកសារ រូបថតសកម្មភាព បញ្ជីវត្តមាន និងកំណត់ហេតុត្រូវបានប្រមូលចងក្រង និងតម្កល់ទុកយ៉ាងត្រឹមត្រូវក្នុងក្រូណូទី ${standardNumber}។

### IV. បញ្ហាប្រឈម និងវិធានការដោះស្រាយ
- **បញ្ហាប្រឈម៖** ការកៀរគរពេលវេលា និងការចូលរួមពីភាគីពាក់ព័ន្ធមួយចំនួននៅមានកម្រិតក្នុងរដូវកាលមមាញឹក។
- **ដំណោះស្រាយ៖** បង្កើនការទំនាក់ទំនងតាមប្រព័ន្ធឌីជីថល (Telegram Group) និងរៀបចំកាលវិភាគបត់បែនសមស្រប។

### V. ទិសដៅបន្ត និងសំណូមពរ
- បន្តតាមដាន និងរក្សាស្ថិរភាពនៃលទ្ធផលសម្រេចបានឱ្យកាន់តែល្អប្រសើរ។
- បន្តសហការជិតស្និទ្ធជាមួយការិយាល័យអប់រំ យុវជន និងកីឡាស្រុក និងមន្ទីរអប់រំខេត្ត។

---

| បានពិនិត្យ និងយល់ព្រម<br>**ប្រធានគណៈកម្មការ គ.គ.ស**<br><br><br>*(ហត្ថលេខា)* | បានឃើញ និងឯកភាព<br>**នាយកសាលារៀន**<br><br><br>*(ហត្ថលេខា និងត្រា)* | **${dateKh}**<br><br>រៀបចំដោយ<br>**អ្នកទទួលបន្ទុកស្តង់ដាទី ${standardNumber}**<br><br><br>*(ហត្ថលេខា)* |
|:---:|:---:|:---:|`;

  return {
    titleKh,
    documentNumber: docNumber,
    dateKh,
    summaryKh: `ឯកសារភស្តុតាងផ្លូវការសម្រាប់សូចនាករ ${indicatorCode} នៃស្តង់ដាទី ${standardNumber} ក្នុងក្របខណ្ឌសាលារៀនគំរូ`,
    contentMarkdown,
    suggestedEvidenceItems: ["រូបថតសកម្មភាពអនុវត្ត", "បញ្ជីវត្តមានអ្នកចូលរួម", "កំណត់ហេតុប្រជុំ", "តារាងលទ្ធផលជាក់ស្តែង"],
    targetIndicatorCode: indicatorCode,
    standardNumber
  };
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ 
    status: "ok", 
    hasGeminiKey: !!process.env.GEMINI_API_KEY,
    timestamp: new Date().toISOString() 
  });
});

// API: Generate Official MoEYS Chrono Document
app.post("/api/ai/generate-document", async (req, res) => {
  try {
    const { 
      standardNumber, 
      standardTitleKh, 
      indicatorCode, 
      indicatorTitleKh, 
      activitiesKh, 
      documentType, 
      schoolName, 
      province, 
      district, 
      academicYear, 
      customInstructions 
    } = req.body;

    const docTypeLabels: Record<string, string> = {
      activity_report: "របាយការណ៍សកម្មភាពអនុវត្ត (Activity Implementation Report)",
      verification_report: "របាយការណ៍ផ្ទៀងផ្ទាត់ និងវាយតម្លៃលទ្ធផល (Verification & Assessment Report)",
      action_plan: "ផែនការសកម្មភាពលម្អិត (Detailed Action Plan)",
      meeting_minutes: "កំណត់ហេតុប្រជុំគណៈកម្មការទ្រទ្រង់សាលា គ.គ.ស (Meeting Minutes)",
      moeys_decision: "សេចក្តីសម្រេច/លិខិតបទដ្ឋានផ្ទៃក្នុងសាលា (School Decision / Guideline)",
      student_list: "បញ្ជីស្ថិតិ និងលទ្ធផលសិស្ស (Student Statistics & Results Record)",
      observation_sheet: "តារាងសង្កេតការបង្រៀន និងកិច្ចតែងការ (Lesson Observation & Plan Sheet)",
      evidence_summary: "របាយការណ៍សំយោគភស្តុតាងសម្រាប់ក្រូណូ (Chrono Evidence Synthesis Report)"
    };

    const docTypeKh = docTypeLabels[documentType] || "របាយការណ៍ភស្តុតាងរដ្ឋបាល";

    const prompt = `អ្នកគឺជាអ្នកជំនាញជាន់ខ្ពស់ផ្នែកអភិវឌ្ឍន៍សាលារៀនគំរូ និងរដ្ឋបាលអប់រំ នៃក្រសួងអប់រំ យុវជន និងកីឡា (MoEYS) ប្រទេសកម្ពុជា។

សូមបង្កើតឯកសារគំរូផ្លូវការមួយជាភាសាខ្មែរ សម្រាប់ដាក់ក្នុងក្រូណូភស្តុតាងសាលារៀន (Chrono Binder) ឱ្យបានត្រឹមត្រូវតាមក្បួនខ្នាតរដ្ឋបាលអប់រំ ដូចខាងក្រោម៖

ព័ត៌មានគោល៖
- សាលារៀន៖ ${schoolName || "សាលាបឋមសិក្សា/អនុវិទ្យាល័យគំរូ"}
- ស្រុក/ខណ្ឌ៖ ${district || "ស្រុកប្រតិបត្តិ"}
- ខេត្ត/រាជធានី៖ ${province || "រាជធានី/ខេត្ត"}
- ឆ្នាំសិក្សា៖ ${academicYear || "២០២៣-២០២៤"}
- ស្តង់ដាសាលារៀនគំរូ៖ ស្តង់ដាទី ${standardNumber || 1} (${standardTitleKh || ""})
- សូចនាករ៖ សូចនាករលេខ ${indicatorCode || ""} (${indicatorTitleKh || ""})
- សកម្មភាពអនុវត្តដែលពាក់ព័ន្ធ៖ ${Array.isArray(activitiesKh) ? activitiesKh.join("; ") : (activitiesKh || "សកម្មភាពពាក់ព័ន្ធនឹងសូចនាករ")}
- ប្រភេទឯកសារ៖ ${docTypeKh}
${customInstructions ? `- សេចក្តីណែនាំបន្ថែមពីអ្នកប្រើប្រាស់៖ ${customInstructions}` : ""}

ទម្រង់ឯកសារត្រូវមានរចនាសម្ព័ន្ធរដ្ឋបាលអប់រំកម្ពុជាច្បាស់លាស់៖
1. ក្បាលលិខិតជាតិ៖ "ព្រះរាជាណាចក្រកម្ពុជា / ជាតិ សាសនា ព្រះមហាក្សត្រ"
2. ក្បាលលិខិតអង្គភាព៖ ក្រសួងអប់រំ យុវជន និងកីឡា / មន្ទីរអប់រំ យុវជន និងកីឡា / ការិយាល័យអប់រំ យុវជន និងកីឡា / ឈ្មោះសាលារៀន
3. លេខលិខិត និងកាលបរិច្ឆេទ (ថ្ងៃ... ខែ... ឆ្នាំ... ព.ស.២៥៦... / ត្រូវនឹងថ្ងៃទី...)
4. ចំណងជើងឯកសារ (ច្បាស់លាស់ សមស្របនឹងស្តង់ដា និងសូចនាករ)
5. ខ្លឹមសារលម្អិតចែកជាផ្នែកៗ (Markdown format):
   - I. សេចក្តីផ្តើម និងគោលបំណង
   - II. ស្ថានភាពជាក់ស្តែង និងសកម្មភាពអនុវត្ត (លម្អិតតាមជំហាន)
   - III. លទ្ធផលសម្រេចបាន (គិតជាបរិមាណ គុណភាព និងភាគរយជាក់ស្តែង)
   - IV. បញ្ហាប្រឈម និងដំណោះស្រាយ
   - V. ផែនការបន្ត និងសំណូមពរ
6. ទីកន្លែង កាលបរិច្ឆេទ និងផ្នែកចុះហត្ថលេខាត្រឹមត្រូវតាមលំដាប់លំដោយរដ្ឋបាលជាតិ (៣ ផ្នែកស្មើជួរ)៖
   - ឆ្វេង៖ បានពិនិត្យ និងយល់ព្រម (ប្រធានគណៈកម្មការ គ.គ.ស)
   - កណ្ដាល៖ បានឃើញ និងឯកភាព (នាយកសាលារៀន)
   - ស្ដាំ៖ កាលបរិច្ឆេទចន្ទគតិ-សុរិយគតិ និង រៀបចំដោយ (អ្នកទទួលបន្ទុកស្តង់ដា/អ្នកធ្វើរបាយការណ៍) — ផ្នែកអ្នករៀបចំត្រូវស្ថិតនៅលើ (កាលបរិច្ឆេទ) ឬ ស្មើ (ហត្ថលេខា) មិននៅក្រោមផ្នែកទាំងពីរឡើយ

សូមឆ្លើយតបជា JSON Format ដែលមាន schema ដូចខាងក្រោម៖
{
  "titleKh": "ចំណងជើងឯកសារពេញលេញ",
  "documentNumber": "លេខឯកសារ ឧទាហរណ៍៖ លេខ.../២៤ របក.សរ",
  "dateKh": "កាលបរិច្ឆេទខ្មែរ",
  "summaryKh": "សេចក្តីសង្ខេបខ្លឹមសារខ្លី ២-៣ បន្ទាត់",
  "contentMarkdown": "ខ្លឹមសារឯកសារពេញលេញជាទម្រង់ Markdown ស្អាត រៀបចំតាមផ្នែកនីមួយៗ",
  "suggestedEvidenceItems": ["បញ្ជីឈ្មោះរូបថត ឬឯកសារបន្ទាប់បន្សំដែលត្រូវភ្ជាប់ជាភស្តុតាង"],
  "targetIndicatorCode": "${indicatorCode || ""}",
  "standardNumber": ${standardNumber || 1}
}`;

    let parsedData = null;
    let ai = null;

    try {
      ai = getAIClient();
    } catch (e: any) {
      console.warn("AI client init note:", e.message);
    }

    if (ai) {
      const rawResponseText = await generateContentWithFallback(ai, prompt);
      if (rawResponseText) {
        try {
          parsedData = JSON.parse(rawResponseText);
        } catch (err) {
          console.warn("Failed to parse AI response as JSON, wrapping text");
          parsedData = {
            titleKh: `ឯកសារភស្តុតាង ${docTypeKh} - ស្តង់ដាទី ${standardNumber}`,
            documentNumber: `លេខ.../${academicYear || "២៤"} របក`,
            dateKh: new Date().toLocaleDateString("km-KH"),
            summaryKh: "ឯកសារភស្តុតាងសម្រាប់ក្រូណូស្តង់ដាសាលារៀនគំរូ",
            contentMarkdown: rawResponseText,
            suggestedEvidenceItems: ["រូបថតសកម្មភាព", "បញ្ជីវត្តមាន", "កំណត់ហេតុ"],
            targetIndicatorCode: indicatorCode || "១.១",
            standardNumber: standardNumber || 1
          };
        }
      }
    }

    // If AI is unavailable or hit 503 high-demand spike, use the rich built-in template generator
    if (!parsedData) {
      parsedData = generateRichMoEYSFallbackDocument({
        standardNumber,
        standardTitleKh,
        indicatorCode,
        indicatorTitleKh,
        activitiesKh,
        documentType,
        schoolName,
        province,
        district,
        academicYear,
        customInstructions
      });
    }

    res.json({ success: true, document: parsedData });
  } catch (error: any) {
    console.error("Error in generate-document handler:", error);
    // Even on unexpected error, provide fallback document so user is never blocked
    const fallback = generateRichMoEYSFallbackDocument({
      standardNumber: req.body?.standardNumber || 1,
      standardTitleKh: req.body?.standardTitleKh || "ស្តង់ដាសាលារៀនគំរូ",
      indicatorCode: req.body?.indicatorCode || "១.១",
      indicatorTitleKh: req.body?.indicatorTitleKh || "សូចនាករ",
      activitiesKh: req.body?.activitiesKh || [],
      documentType: req.body?.documentType || "activity_report",
      schoolName: req.body?.schoolName,
      academicYear: req.body?.academicYear
    });
    res.json({ success: true, document: fallback, isFallback: true });
  }
});

// API: Enhance/Polish Pasted Document or Rough Text
app.post("/api/ai/enhance-document", async (req, res) => {
  try {
    const { rawText, standardNumber, indicatorCode, documentType, schoolName } = req.body;

    if (!rawText || rawText.trim() === "") {
      return res.status(400).json({ error: "rawText is required" });
    }

    const prompt = `អ្នកគឺជាអ្នកជំនាញតាក់តែងលិខិតបទដ្ឋានរដ្ឋបាលអប់រំ និងរបាយការណ៍សាលារៀនគំរូនៃក្រសួងអប់រំ យុវជន និងកីឡា។

សូមជួយកែលម្អ (Enhance & Polish) អត្ថបទ ឬទិន្នន័យខាងក្រោមនេះ ឱ្យក្លាយជាឯកសាររដ្ឋបាលអប់រំស្តង់ដា ផ្លូវការ ត្រឹមត្រូវតាមវេយ្យាករណ៍ រចនាបទរដ្ឋបាលអប់រំ និងមានទម្រង់ច្បាស់លាស់៖

អត្ថបទដើមដែលបានបញ្ចូល៖
"""
${rawText}
"""

បរិបទបន្ថែម៖
- សាលារៀន៖ ${schoolName || "សាលារៀន"}
- ស្តង់ដាទី៖ ${standardNumber || 1}
- សូចនាករ៖ ${indicatorCode || ""}
- ប្រភេទឯកសារ៖ ${documentType || "របាយការណ៍ភស្តុតាង"}

សូមរៀបចំទម្រង់ឱ្យមានចំណងជើង ក្បាលលិខិត រចនាសម្ព័ន្ធរដ្ឋបាលត្រឹមត្រូវ (សេចក្តីផ្តើម សកម្មភាពអនុវត្ត លទ្ធផលសម្រេច បញ្ហាប្រឈម ដំណោះស្រាយ ហត្ថលេខា)។

សូមឆ្លើយតបជា JSON Format:
{
  "titleKh": "ចំណងជើងឯកសារដែលបានកែលម្អ",
  "documentNumber": "លេខលិខិត",
  "dateKh": "កាលបរិច្ឆេទ",
  "summaryKh": "សង្ខេបខ្លឹមសារខ្លី",
  "enhancedMarkdown": "ខ្លឹមសារឯកសារពេញលេញជាទម្រង់ Markdown ស្អាត រៀបចំតាមក្បួនរដ្ឋបាលអប់រំ",
  "improvementsMade": ["ចំណុចសំខាន់ៗដែលបានកែលម្អ និងបំពេញបន្ថែម"]
}`;

    let parsedData = null;
    let ai = null;

    try {
      ai = getAIClient();
    } catch (e: any) {
      console.warn("AI client note:", e.message);
    }

    if (ai) {
      const rawResponseText = await generateContentWithFallback(ai, prompt);
      if (rawResponseText) {
        try {
          parsedData = JSON.parse(rawResponseText);
        } catch (err) {
          parsedData = {
            titleKh: "ឯកសារដែលបានកែលម្អ",
            enhancedMarkdown: rawResponseText,
            improvementsMade: ["កែសម្រួលវេយ្យាករណ៍ និងរចនាសម្ព័ន្ធរដ្ឋបាល"]
          };
        }
      }
    }

    // If AI unavailable or 503 spike, generate clean structured markdown
    if (!parsedData) {
      const lines = rawText.split("\n").map((l: string) => l.trim()).filter((l: string) => l.length > 0);
      const title = lines[0] || "របាយការណ៍សកម្មភាព និងភស្តុតាង";
      const body = lines.slice(1).join("\n\n") || rawText;
      parsedData = {
        titleKh: title,
        documentNumber: `លេខ.../២៤ របក`,
        dateKh: new Date().toLocaleDateString("km-KH"),
        summaryKh: "ឯកសារបានរៀបចំទម្រង់រដ្ឋបាលអប់រំ និងក្បាលលិខិតផ្លូវការ",
        enhancedMarkdown: `### ព្រះរាជាណាចក្រកម្ពុជា\n**ជាតិ សាសនា ព្រះមហាក្សត្រ**\n***\n\n**ក្រសួងអប់រំ យុវជន និងកីឡា**  \n**${schoolName || "សាលារៀនគំរូ"}**\n\n---\n# ${title}\n### ក្រូណូទី ${standardNumber || 1} - សូចនាករ ${indicatorCode || "១.១"}\n\n---\n\n${body}\n\n---\n\n| បានឃើញ និងឯកភាព<br>**នាយកសាលារៀន**<br><br>*(ហត្ថលេខា និងត្រា)* | រៀបចំដោយ<br>**អ្នកទទួលបន្ទុក**<br><br>*(ហត្ថលេខា)* |\n|:---:|:---:|`,
        improvementsMade: ["រៀបចំក្បាលលិខិតជាតិ", "រៀបចំរចនាសម្ព័ន្ធរដ្ឋបាល", "បន្ថែមតារាងចុះហត្ថលេខា"]
      };
    }

    res.json({ success: true, result: parsedData });
  } catch (error: any) {
    console.error("Error enhancing document:", error);
    const lines = (req.body?.rawText || "").split("\n").filter((l: string) => l.trim().length > 0);
    const title = lines[0] || "ឯកសាររដ្ឋបាល";
    res.json({ 
      success: true, 
      result: {
        titleKh: title,
        enhancedMarkdown: `### ព្រះរាជាណាចក្រកម្ពុជា\n**ជាតិ សាសនា ព្រះមហាក្សត្រ**\n***\n\n${req.body?.rawText || ""}\n\n---\n**បានឃើញ និងឯកភាព**\n*នាយកសាលារៀន*`,
        improvementsMade: ["រៀបចំទម្រង់រដ្ឋបាលមូលដ្ឋាន"]
      }
    });
  }
});

// Setup Vite middleware or static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Chrono & School Standards Server running on http://localhost:${PORT}`);
  });
}

startServer();
